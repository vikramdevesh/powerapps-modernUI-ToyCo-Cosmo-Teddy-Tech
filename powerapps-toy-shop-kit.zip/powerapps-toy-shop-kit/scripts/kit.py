# Shared builder: Power Apps controls -> pa.yaml + an HTML mock for visual checks.
import math, random, urllib.parse

LBL, BTN, IMG, RECT, GAL = "Label@2.5.1", "Classic/Button@2.2.0", "Image@2.2.3", "Rectangle@2.3.0", "Gallery@2.15.0"
FONTS = {"lato": "Font.'Lato Black'", "segoe": "Font.'Segoe UI'", "serif": "Font.Georgia", "mono": "Font.'Courier New'"}
CSSF = {"lato": '"Lato","Segoe UI Black",Arial Black,sans-serif', "segoe": '"Segoe UI",Arial,sans-serif', "serif": "Georgia,serif", "mono": '"Courier New",monospace'}
W8 = {"normal": ("FontWeight.Normal", 400), "semi": ("FontWeight.Semibold", 600), "bold": ("FontWeight.Bold", 700)}

class C:
    def __init__(s, name, typ, geo, props, pv=None, children=None, variant=None):
        s.name, s.typ, s.geo, s.props, s.pv, s.children, s.variant = name, typ, geo, props, pv or {}, children, variant

def g(v): return v if isinstance(v, tuple) else (str(v), v)
def col(h): return f'ColorValue("#{h}")'
def svgfx(s):
    assert '"' not in s, s[:80]
    return '"data:image/svg+xml;utf8," & EncodeUrl("' + s + '")'

def L(name, geo, text, pv, size, font="lato", weight="normal", color="ffffff", align="Center", valign="Middle", wrap=False, italic=False,
      fill=None, fill_fx=None, visible=None, pvhide=False, color_fx=None, pad=0):
    p = {"Text": text, "Font": FONTS[font], "FontWeight": W8[weight][0], "Size": str(size), "Color": color_fx or col(color),
         "Align": f"Align.{align}", "VerticalAlign": f"VerticalAlign.{valign}", "PaddingLeft": str(pad), "PaddingRight": str(pad), "PaddingTop": "0", "PaddingBottom": "0"}
    if not wrap: p["Wrap"] = "false"
    if italic: p["Italic"] = "true"
    if fill_fx: p["Fill"] = fill_fx
    elif fill: p["Fill"] = col(fill)
    if visible: p["Visible"] = visible
    return C(name, LBL, geo, p, dict(kind="lbl", text=pv, size=size, font=font, w=W8[weight][1], color=color, align=align, valign=valign, wrap=wrap,
                                     italic=italic, fill=fill, hide=pvhide, pad=pad))

def I(name, geo, fx, pvsvg, pos="Fit", visible=None, pvhide=False):
    p = {"Image": fx, "ImagePosition": f"ImagePosition.{pos}", "BorderThickness": "0"}
    if visible: p["Visible"] = visible
    return C(name, IMG, geo, p, dict(kind="img", svg=pvsvg, pos=pos, hide=pvhide))

def HIT(name, geo, onselect, tip, hover="RGBA(255, 255, 255, 0.10)"):
    return C(name, BTN, geo, {"Text": '""', "Fill": "RGBA(0, 0, 0, 0)", "HoverFill": hover, "PressedFill": "RGBA(0, 0, 0, 0.10)",
             "BorderThickness": "0", "FocusedBorderThickness": "0", "RadiusTopLeft": "8", "RadiusTopRight": "8", "RadiusBottomLeft": "8",
             "RadiusBottomRight": "8", "Tooltip": f'"{tip}"', "OnSelect": onselect}, dict(kind="none"))

def B(name, geo, text, pv, fill, color, onselect, size=18, font="lato", weight="normal", radius=None, fill_fx=None, color_fx=None,
      border=None, border_fx=None, bthick="0", extra=None, pvfill=None, pvcolor=None, hover_fx=None, pvborder=None, visible=None, pvhide=False):
    h = g(geo[3])[1]; r = str(radius if radius is not None else int(h // 2))
    p = {"Text": text, "Fill": fill_fx or col(fill), "Color": color_fx or col(color), "HoverFill": hover_fx or "ColorFade(Self.Fill, -0.12)",
         "PressedFill": "ColorFade(Self.Fill, -0.25)", "Font": FONTS[font], "FontWeight": W8[weight][0], "Size": str(size),
         "BorderThickness": bthick, "RadiusTopLeft": r, "RadiusTopRight": r, "RadiusBottomLeft": r, "RadiusBottomRight": r, "OnSelect": onselect}
    if border or border_fx: p["BorderColor"] = border_fx or col(border)
    if visible: p["Visible"] = visible
    if extra: p.update(extra)
    return C(name, BTN, geo, p, dict(kind="btn", text=pv, fill=pvfill or "#" + fill if fill else pvfill, color=pvcolor or "#" + color, size=size,
                                     font=font, w=W8[weight][1], r=int(r), border=pvborder, hide=pvhide))

def GALC(name, geo, items, children, pv, tsize, wrap=1, pad=8, extra=None):
    p = {"Items": items, "WrapCount": str(wrap), "TemplateSize": str(tsize), "TemplatePadding": str(pad), "TemplateFill": "RGBA(0, 0, 0, 0)",
         "Fill": "RGBA(0, 0, 0, 0)", "BorderThickness": "0", "ShowScrollbar": "false", "ShowNavigation": "false"}
    if extra: p.update(extra)
    return C(name, GAL, geo, p, pv, children, "Vertical")

# ---------------- YAML ----------------
def yval(fx, ind):
    s = "=" + fx
    if "\n" in s or ": " in s or "#" in s or s.endswith(":") or "{" in s:
        return "|-\n" + "\n".join(" " * ind + l for l in s.split("\n"))
    return s
def emit(c, ind):
    o = [" " * ind + f"- {c.name}:", " " * (ind + 4) + f"Control: {c.typ}"]
    if c.variant: o.append(" " * (ind + 4) + f"Variant: {c.variant}")
    o.append(" " * (ind + 4) + "Properties:")
    props = dict(c.props)
    for k, v in zip(("X", "Y", "Width", "Height"), c.geo): props[k] = g(v)[0]
    for k, v in props.items(): o.append(" " * (ind + 6) + f"{k}: " + yval(v, ind + 8))
    if c.children:
        o.append(" " * (ind + 4) + "Children:")
        for ch in c.children: o += emit(ch, ind + 6)
    return o
def screen_yaml(name, ctrls, onvis="", fill='ColorValue("#000000")', header=True):
    o = (["Screens:"] if header else []) + [f"  {name}:", "    Properties:", "      Fill: " + yval(fill, 8)]
    if onvis: o.append("      OnVisible: " + yval(onvis, 8))
    o.append("    Children:")
    for c in ctrls: o += emit(c, 6)
    return "\n".join(o) + "\n"
def controls_yaml(ctrls):
    o = []
    for c in ctrls: o += emit(c, 0)
    return "\n".join(o) + "\n"

# ---------------- HTML mock ----------------
def uri(s): return "data:image/svg+xml;utf8," + urllib.parse.quote(s)
def html_ctrl(c):
    pv = c.pv
    if pv.get("hide") or pv.get("kind") == "none": return ""
    x, y, w, h = (g(v)[1] for v in c.geo)
    st = f"position:absolute;left:{x}px;top:{y}px;width:{w}px;height:{h}px;box-sizing:border-box;"
    k = pv["kind"]
    if k == "img":
        fit = {"Fill": "cover", "Fit": "contain", "Stretch": "fill"}[pv["pos"]]
        return f"<img style='{st}object-fit:{fit}' src='{uri(pv['svg'])}'>"
    if k == "rect":
        return f"<div style='{st}background:{pv['fill']}'></div>"
    if k == "lbl":
        ja = {"Left": "flex-start", "Center": "center", "Right": "flex-end"}[pv["align"]]
        va = {"Middle": "center", "Top": "flex-start", "Bottom": "flex-end"}[pv["valign"]]
        bg = f"background:#{pv['fill']};" if pv.get("fill") else ""
        return (f"<div style='{st}{bg}display:flex;align-items:{va};justify-content:{ja};text-align:{pv['align'].lower()};color:#{pv['color']};padding:0 {pv['pad']}px;"
                f"font-family:{CSSF[pv['font']]};font-weight:{pv['w']};font-style:{'italic' if pv['italic'] else 'normal'};font-size:{pv['size']*1.333:.0f}px;"
                f"white-space:{'pre-wrap' if pv['wrap'] else 'pre'};overflow:hidden;line-height:1.2'>{pv['text']}</div>")
    if k == "btn":
        bd = f"border:3px solid {pv['border']};" if pv.get("border") else ""
        return (f"<div style='{st}{bd}background:{pv['fill']};color:{pv['color']};border-radius:{pv['r']}px;display:flex;align-items:center;justify-content:center;"
                f"font-family:{CSSF[pv['font']]};font-weight:{pv['w']};font-size:{pv['size']*1.333:.0f}px;white-space:pre'>{pv['text']}</div>")
    if k == "gal":
        out = f"<div style='{st}overflow:hidden'>"
        for i, it in enumerate(pv["items"]):
            gx = pv["pad"] + (i % pv["wrap"]) * (pv["tw"] + pv["pad"]); gy = pv["pad"] + (i // pv["wrap"]) * (pv["th"] + pv["pad"])
            out += f"<div style='position:absolute;left:{gx}px;top:{gy}px;width:{pv['tw']}px;height:{pv['th']}px'>" + "".join(html_ctrl(ch) for ch in pv["build"](it)) + "</div>"
        return out + "</div>"
    return ""
def mock(ctrls, bg="#000"):
    return ("<html><head><link href='https://fonts.googleapis.com/css2?family=Lato:wght@900&display=block' rel='stylesheet'></head><body style='margin:0'>"
            f"<div style='position:relative;width:1366px;height:768px;overflow:hidden;background:{bg}'>" + "".join(html_ctrl(c) for c in ctrls) + "</div></body></html>")

# ---------------- svg helpers ----------------
def f1(v): return str(int(round(v))) if abs(v) >= 20 else f"{v:.1f}".rstrip("0").rstrip(".")
def circ(x, y, r): return f"M{f1(x-r)},{f1(y)}a{f1(r)},{f1(r)} 0 1,0 {f1(2*r)},0a{f1(r)},{f1(r)} 0 1,0 {f1(-2*r)},0z"
def poly(pts): return " ".join(f"{f1(a)},{f1(b)}" for a, b in pts)
def jag(pts, seed, amp=3.0, step=6.0):
    """subdivide a closed polygon and wobble the points (torn paper edge)"""
    r = random.Random(seed); out = []; off = 0
    for i in range(len(pts)):
        ax, ay = pts[i]; bx, by = pts[(i + 1) % len(pts)]
        L_ = math.hypot(bx - ax, by - ay); n = max(1, int(L_ / step)); nx, ny = -(by - ay) / L_, (bx - ax) / L_
        for k in range(n):
            u = k / n; off = off * 0.55 + (r.random() - 0.5) * amp * 1.4
            out.append((ax + (bx - ax) * u + nx * off, ay + (by - ay) * u + ny * off))
    return out
