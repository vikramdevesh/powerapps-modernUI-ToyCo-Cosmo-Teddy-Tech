# Generates the Power Fx App.Formulas (papercraft SVG assets + toy data) and an HTML preview of the assets.
import json, os, sys
OUT = sys.argv[1]

HATCH = ("<pattern id='h' width='5' height='5' patternUnits='userSpaceOnUse' patternTransform='rotate(45)'>"
         "<rect width='5' height='5' fill='#e3dac6'/><rect width='1.3' height='5' fill='#8c7856' opacity='.55'/></pattern>")
FIBRE = ("<filter id='f' x='0' y='0' width='100%' height='100%'><feTurbulence type='fractalNoise' baseFrequency='1.3' numOctaves='3' seed='9'/>"
         "<feColorMatrix values='0 0 0 0 .42  0 0 0 0 .36  0 0 0 0 .28  -1.5 0 0 0 .84'/></filter>")
LIGHT = ("<linearGradient id='l' x1='0' y1='0' x2='.6' y2='1'><stop offset='0' stop-color='#fff4de' stop-opacity='.35'/>"
         "<stop offset='1' stop-color='#3a2a10' stop-opacity='.14'/></linearGradient>")

# ---------- green self-healing cutting mat on a walnut desk ----------
mat = [
 "<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 1366 768' preserveAspectRatio='xMidYMid slice'><defs>",
 "<pattern id='w' width='1366' height='38' patternUnits='userSpaceOnUse'><rect width='1366' height='38' fill='#a8754c'/><rect y='19' width='1366' height='19' fill='#b07c50'/><path d='M0 6C300 4 700 9 1366 5M0 14C500 16 900 11 1366 15M0 27C400 25 800 30 1366 26' stroke='#4a2810' stroke-opacity='.22' fill='none'/><rect y='36' width='1366' height='2' fill='#2a160a' opacity='.5'/></pattern>",
 "<pattern id='g' width='20' height='20' patternUnits='userSpaceOnUse'><path d='M20 0H0V20' fill='none' stroke='#cde6aa' stroke-opacity='.2'/></pattern>",
 "<pattern id='G' width='100' height='100' patternUnits='userSpaceOnUse'><path d='M100 0H0V100' fill='none' stroke='#deeeb8' stroke-opacity='.42' stroke-width='1.4'/></pattern>",
 "<pattern id='d' width='200' height='200' patternUnits='userSpaceOnUse'><path d='M0 200L200 0' stroke='#deeeb8' stroke-opacity='.2'/></pattern>",
 "<clipPath id='m'><rect x='14' y='14' width='1338' height='734' rx='16'/></clipPath>",
 "<filter id='n' x='0' y='0' width='100%' height='100%'><feTurbulence type='fractalNoise' baseFrequency='.9' numOctaves='2' seed='3'/><feColorMatrix values='0 0 0 0 .6  0 0 0 0 .85  0 0 0 0 .65  1.6 0 0 0 -.78'/></filter>",
 "<filter id='s'><feGaussianBlur stdDeviation='9'/></filter><filter id='o'><feGaussianBlur stdDeviation='1.2'/></filter>",
 "<radialGradient id='L'><stop offset='0' stop-color='#9fd8b4' stop-opacity='.12'/><stop offset='1' stop-color='#9fd8b4' stop-opacity='0'/></radialGradient>",
 "<radialGradient id='D'><stop offset='0' stop-color='#0a2819' stop-opacity='.18'/><stop offset='1' stop-color='#0a2819' stop-opacity='0'/></radialGradient>",
 "<radialGradient id='k' cx='.36' cy='.3' r='.75'><stop offset='0' stop-color='#ffd696' stop-opacity='.16'/><stop offset='.6' stop-color='#ffc88c' stop-opacity='.04'/><stop offset='1' stop-color='#ffc88c' stop-opacity='0'/></radialGradient>",
 "<radialGradient id='v' r='.75'><stop offset='.5' stop-color='#140c04' stop-opacity='0'/><stop offset='1' stop-color='#140c04' stop-opacity='.5'/></radialGradient>",
 "</defs>",
 "<rect width='1366' height='768' fill='url(#w)'/>",
 "<rect x='24' y='28' width='1330' height='732' rx='16' fill='#000' opacity='.55' filter='url(#s)'/>",
 "<rect x='14' y='17' width='1338' height='734' rx='16' fill='#1d4a35'/><rect x='14' y='14' width='1338' height='734' rx='16' fill='#2d6c4e'/>",
 "<g clip-path='url(#m)'>",
 "<circle cx='240' cy='180' r='260' fill='url(#L)'/><circle cx='900' cy='520' r='320' fill='url(#L)'/><circle cx='1200' cy='160' r='220' fill='url(#D)'/><circle cx='520' cy='640' r='240' fill='url(#D)'/><circle cx='700' cy='260' r='180' fill='url(#D)'/>",
 "<rect width='1366' height='768' fill='url(#g)'/><rect width='1366' height='768' fill='url(#G)'/><rect width='1366' height='768' fill='url(#d)'/>",
 "<path d='M90 330H470M760 90V380M980 610H1320M300 520L520 300M1100 420L1260 580M60 700H380M620 40V200' stroke='#aadcb4' stroke-opacity='.16' fill='none'/>",
 "<path d='M180 470H330M840 700L960 580M1220 300V430' stroke='#0f2d1e' stroke-opacity='.22' fill='none'/>",
 "<rect width='1366' height='768' filter='url(#n)' opacity='.35'/>",
 "<g filter='url(#o)' fill='#000' opacity='.35'><polygon points='412,688 436,684 426,700'/><polygon points='1062,92 1092,94 1091,100 1063,99'/><polygon points='642,402 660,396 652,414'/><polygon points='212,612 240,616 238,621 211,618'/><polygon points='1282,676 1300,668 1296,688'/></g>",
 "<polygon points='410,685 434,681 424,697' fill='#ee6b2d'/><polygon points='1060,89 1090,91 1089,97 1061,96' fill='#f4b630'/><polygon points='640,399 658,393 650,411' fill='#2f6db3'/><polygon points='210,609 238,613 236,618 209,615' fill='#e9e2d0'/><polygon points='1280,673 1298,665 1294,685' fill='#d83a2e'/>",
 "<g fill='#d6e8b4' fill-opacity='.75' font-family='Courier New,monospace' font-weight='700' font-size='12' text-anchor='middle'>"
 + "".join(f"<text x='{i*100}' y='741'>{i*5}</text>" for i in range(1, 14))
 + "".join(f"<text x='30' y='{i*100+4}'>{i}</text>" for i in range(1, 8)) + "</g>",
 "</g>",
 "<rect width='1366' height='768' fill='url(#k)'/><rect width='1366' height='768' fill='url(#v)'/></svg>",
]

# ---------- tent card (HDR = header strip colour) ----------
tent = [
 "<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 400 200' preserveAspectRatio='none'><defs>", HATCH,
 "<clipPath id='c'><polygon points='16,18 384,18 396,174 4,174'/></clipPath>",
 "<filter id='s' x='-10%' y='-40%' width='120%' height='180%'><feGaussianBlur stdDeviation='4'/></filter>", FIBRE, LIGHT, "</defs>",
 "<polygon points='20,184 396,184 400,198 14,198' fill='#04140a' opacity='.55' filter='url(#s)'/>",
 "<polygon points='30,4 370,4 384,18 16,18' fill='#cbc1aa'/>",
 "<polygon points='16,18 384,18 396,174 4,174' fill='#f5f0e4'/>",
 "<polygon points='16,18 384,18 386,44 14,44' fill='#HDR'/>",
 "<g clip-path='url(#c)'><rect width='400' height='200' filter='url(#f)' opacity='.7'/></g>",
 "<polygon points='16,18 384,18 396,174 4,174' fill='url(#l)'/>",
 "<line x1='16' y1='18.5' x2='384' y2='18.5' stroke='#3c2d1e' stroke-opacity='.5' stroke-width='1.2' stroke-dasharray='5 4'/>",
 "<polygon points='4,174 396,174 388,188 12,188' fill='url(#h)'/>",
 "<line x1='4' y1='174.5' x2='396' y2='174.5' stroke='#3c2d1e' stroke-opacity='.4' stroke-dasharray='4 3'/>",
 "<polygon points='16,18 384,18 396,174 4,174' fill='none' stroke='#fffaf0' stroke-opacity='.85' stroke-width='1.4'/></svg>",
]

def sheet(W, H, hdr=40, tabs=True, hfold=None, vband=False):
    x0, y0, w, h = 16, 8, W - 32, H - 16
    s = [f"<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 {W} {H}' preserveAspectRatio='none'><defs>", HATCH, FIBRE, LIGHT,
         "<filter id='s' x='-10%' y='-10%' width='130%' height='130%'><feGaussianBlur stdDeviation='5'/></filter>",
         f"<clipPath id='c'><rect x='{x0}' y='{y0}' width='{w}' height='{h}'/></clipPath></defs>",
         f"<rect x='{x0+8}' y='{y0+10}' width='{w}' height='{h-4}' fill='#04140a' opacity='.5' filter='url(#s)'/>"]
    if tabs:
        a, b = y0 + min(32, h * .15), y0 + h - min(32, h * .15)
        s.append(f"<polygon points='{x0},{a} {x0-10},{a+10} {x0-10},{b-10} {x0},{b}' fill='url(#h)'/>")
        s.append(f"<polygon points='{x0+w},{a} {x0+w+10},{a+10} {x0+w+10},{b-10} {x0+w},{b}' fill='url(#h)'/>")
    s.append(f"<rect x='{x0}' y='{y0}' width='{w}' height='{h}' fill='#f5f0e4'/>")
    if vband: s.append(f"<rect x='{x0}' y='{y0}' width='18' height='{h}' fill='#HDR'/>")
    elif hdr: s.append(f"<rect x='{x0}' y='{y0}' width='{w}' height='{hdr}' fill='#HDR'/>")
    s.append(f"<g clip-path='url(#c)'><rect width='{W}' height='{H}' filter='url(#f)' opacity='.7'/></g>")
    s.append(f"<rect x='{x0}' y='{y0}' width='{w}' height='{h}' fill='url(#l)'/>")
    top = y0 + (0 if vband else hdr) + 8
    left = x0 + (26 if vband else 8)
    s.append(f"<rect x='{left}' y='{top}' width='{x0+w-8-left}' height='{y0+h-8-top}' rx='3' fill='none' stroke='#3c2d1e' stroke-opacity='.3' stroke-dasharray='4 3'/>")
    if tabs:
        s.append(f"<path d='M{x0+.5} {a}V{b}M{x0+w-.5} {a}V{b}' stroke='#3c2d1e' stroke-opacity='.45' stroke-dasharray='5 4'/>")
    if hfold:
        s.append(f"<path d='M{x0} {hfold}H{x0+w}' stroke='#3c2d1e' stroke-opacity='.45' stroke-dasharray='6 4'/>")
        s.append(f"<text x='{x0+w-14}' y='{hfold-5}' font-family='Courier New,monospace' font-size='10' font-weight='700' fill='#3c2d1e' fill-opacity='.5' text-anchor='end'>FOLD HERE</text>")
    s.append(f"<text x='{x0+w-12}' y='{y0+h-12}' font-size='13' fill='#3c2d1e' fill-opacity='.5' text-anchor='end'>&#9986;</text>")
    s.append(f"<rect x='{x0}' y='{y0}' width='{w}' height='{h}' fill='none' stroke='#fffaf0' stroke-opacity='.85' stroke-width='1.4'/></svg>")
    return s

card = sheet(300, 280, hdr=26)
detail = sheet(446, 650, hdr=40, hfold=330)
row = sheet(800, 132, tabs=False, vband=True)

strip = [
 "<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 400 80' preserveAspectRatio='none'><defs><filter id='s' x='-5%' y='-30%' width='110%' height='170%'><feGaussianBlur stdDeviation='3.5'/></filter></defs>",
 "<path d='M8 30H324V14L398 46L324 76V60H8Z' fill='#04140a' opacity='.5' filter='url(#s)'/>",
 "<path d='M4 24H320V8L396 40L320 72V56H4Z' fill='#HDR'/>",
 "<g fill='#000' opacity='.17'><rect x='44' y='24' width='40' height='32'/><rect x='124' y='24' width='40' height='32'/><rect x='204' y='24' width='40' height='32'/><rect x='284' y='24' width='36' height='32'/></g>",
 "<g fill='#fff' opacity='.13'><rect x='4' y='24' width='40' height='9'/><rect x='84' y='24' width='40' height='9'/><rect x='164' y='24' width='40' height='9'/><rect x='244' y='24' width='40' height='9'/></g>",
 "<polygon points='320,40 396,40 320,72' fill='#000' opacity='.14'/>",
 "<path d='M44 24V56M84 24V56M124 24V56M164 24V56M204 24V56M244 24V56M284 24V56M320 24V56' stroke='#3c2d1e' stroke-opacity='.35' stroke-dasharray='3 2'/>",
 "<line x1='10' y1='40' x2='314' y2='40' stroke='#fff' stroke-opacity='.55' stroke-dasharray='6 5'/>",
 "<path d='M4 24H320V8L396 40L320 72V56H4Z' fill='none' stroke='#fffaf0' stroke-opacity='.6'/></svg>",
]

flag = [
 "<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 160 200'><defs><filter id='s' x='-40%' y='-100%' width='180%' height='300%'><feGaussianBlur stdDeviation='4'/></filter></defs>",
 "<ellipse cx='84' cy='182' rx='46' ry='9' fill='#04140a' opacity='.5' filter='url(#s)'/>",
 "<polygon points='60,186 37.5,173 37.5,155 60,168' fill='#f4b630' stroke='#fff8ea' stroke-opacity='.8'/>",
 "<polygon points='60,186 82.5,173 82.5,155 60,168' fill='#f4b630' stroke='#fff8ea' stroke-opacity='.8'/><polygon points='60,186 82.5,173 82.5,155 60,168' fill='#1a1408' opacity='.26'/>",
 "<polygon points='60,168 82.5,155 60,142 37.5,155' fill='#f4b630' stroke='#fff8ea' stroke-opacity='.8'/><polygon points='60,168 82.5,155 60,142 37.5,155' fill='#fff3dc' opacity='.24'/>",
 "<rect x='57' y='24' width='6' height='132' fill='#d6b585'/><rect x='60' y='24' width='3' height='132' fill='#1a1408' opacity='.2'/>",
 "<path d='M63 28L146 34L144 92L63 86Z' fill='#HDR' stroke='#fff8ea' stroke-opacity='.8' stroke-width='1.2'/>",
 "<path d='M104 31L146 34L144 92L104 89Z' fill='#000' opacity='.14'/>",
 "<path d='M104 31V89' stroke='#3c2d1e' stroke-opacity='.4' stroke-dasharray='3 2.5'/>",
 "<g transform='translate(104 60)'><path d='MARK' stroke='#fff' stroke-width='7' stroke-linecap='round' stroke-linejoin='round' fill='none'/></g>",
 "<circle cx='60' cy='22' r='5' fill='#d6b585' stroke='#fff8ea' stroke-opacity='.8'/></svg>",
]

net = [
 "<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 300 220'><defs>", HATCH,
 "<filter id='s' x='-10%' y='-10%' width='130%' height='130%'><feGaussianBlur stdDeviation='5'/></filter></defs>",
 "<g transform='rotate(-6 150 110)'>",
 "<rect x='24' y='18' width='262' height='192' fill='#04140a' opacity='.5' filter='url(#s)'/>",
 "<rect x='14' y='8' width='266' height='196' fill='#f7f4ec'/>",
 "<rect x='22' y='16' width='250' height='180' fill='none' stroke='#282828' stroke-opacity='.45' stroke-dasharray='3 2'/>",
 "<text x='30' y='32' font-family='Courier New,monospace' font-weight='700' font-size='10' fill='#282828' fill-opacity='.75'>PART C &#183; CUBE</text>",
 "<polygon points='80,78 70,86 70,102 80,110' fill='url(#h)'/><polygon points='164,74 170,66 190,66 196,74' fill='url(#h)'/><polygon points='160,118 170,126 170,146 160,154' fill='url(#h)'/><polygon points='120,158 112,164 112,184 120,190' fill='url(#h)'/>",
 "<path d='M120 34H160V74H200V114H160V194H120V114H80V74H120Z' fill='#f4b630'/>",
 "<rect x='120' y='74' width='40' height='40' fill='#fff3dc' opacity='.25'/>",
 "<path d='M120 74H160M120 114H160M120 154H160M120 74V114M160 74V114' stroke='#5a3a00' stroke-opacity='.55' stroke-dasharray='3 2.5'/>",
 "<path d='M120 34H160V74H200V114H160V194H120V114H80V74H120Z' fill='none' stroke='#fffaf0' stroke-opacity='.8' stroke-width='1.3'/>",
 "<text x='140' y='103' font-family='Arial Rounded MT Bold,Verdana,sans-serif' font-weight='700' font-size='28' fill='#22252d' text-anchor='middle'>?</text>",
 "<text x='262' y='194' font-size='14' fill='#282828' fill-opacity='.6' text-anchor='middle'>&#9986;</text>",
 "</g></svg>",
]

ruler = [
 "<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 720 70'><defs>",
 "<linearGradient id='m' x1='0' y1='0' x2='0' y2='1'><stop offset='0' stop-color='#e4e8eb'/><stop offset='.5' stop-color='#b8bec4'/><stop offset='1' stop-color='#d4d8db'/></linearGradient>",
 "<pattern id='t' x='20' y='16' width='7' height='40' patternUnits='userSpaceOnUse'><rect width='.8' height='7' fill='#191920'/></pattern>",
 "<pattern id='T' x='20' y='16' width='35' height='40' patternUnits='userSpaceOnUse'><rect width='.9' height='11' fill='#191920'/></pattern>",
 "<pattern id='U' x='20' y='16' width='70' height='40' patternUnits='userSpaceOnUse'><rect width='1.1' height='16' fill='#191920'/></pattern>",
 "<filter id='s' x='-5%' y='-40%' width='110%' height='180%'><feGaussianBlur stdDeviation='4'/></filter></defs>",
 "<g transform='rotate(-1.5 360 35)'>",
 "<rect x='16' y='24' width='700' height='34' rx='2' fill='#04140a' opacity='.5' filter='url(#s)'/>",
 "<rect x='8' y='16' width='700' height='34' rx='2' fill='url(#m)'/>",
 "<rect x='18' y='16' width='684' height='34' fill='url(#t)'/><rect x='18' y='16' width='684' height='34' fill='url(#T)'/><rect x='18' y='16' width='684' height='34' fill='url(#U)'/>",
 "<g font-family='Arial,sans-serif' font-weight='700' font-size='10' fill='#191920' text-anchor='middle'>"
 + "".join(f"<text x='{20+i*70}' y='42'>{i}</text>" for i in range(1, 10)) + "</g>",
 "<text x='684' y='44' font-family='Arial,sans-serif' font-size='8' fill='#191920' fill-opacity='.6'>cm</text>",
 "<rect x='8' y='16' width='700' height='34' rx='2' fill='none' stroke='#fff' stroke-opacity='.6'/></g></svg>",
]

# ---------- low-poly papercraft toy models (HEXA main colour, HEXB accent) ----------
ART_HEAD = ("<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 200 200'><style>.a{fill:#HEXA}.b{fill:#HEXB}.c{fill:#f5f0e4}.g{fill:#2e9a57}"
 ".e{stroke:#fff8ea;stroke-opacity:.8;stroke-width:1.2;stroke-linejoin:round}.r{fill:#1a1408;opacity:.26}.t{fill:#fff3dc;opacity:.24}"
 ".d{fill:none;stroke:#3c2d1e;stroke-opacity:.45;stroke-dasharray:3 2.5}.x{font-family:Arial Rounded MT Bold,Verdana,sans-serif;font-weight:700;font-size:24px;fill:#fff;text-anchor:middle}</style>"
 "<defs><pattern id='h' width='4' height='4' patternUnits='userSpaceOnUse' patternTransform='rotate(45)'><rect width='4' height='4' fill='#e3dac6'/><rect width='1' height='4' fill='#8c7856' opacity='.6'/></pattern>"
 "<filter id='s' x='-30%' y='-80%' width='160%' height='260%'><feGaussianBlur stdDeviation='5'/></filter></defs>")

def face(cls, pts, shade=None):
    s = f"<polygon class='{cls} e' points='{pts}'/>"
    if shade: s += f"<polygon class='{shade}' points='{pts}'/>"
    return s

robot = [
 "<ellipse cx='122' cy='172' rx='76' ry='20' fill='#04140a' opacity='.45' filter='url(#s)'/>",
 "<polygon points='152,150 160,144 160,96 152,90' fill='url(#h)'/>",
 face('a', '100,180 48,150 48,90 100,120'), face('a', '100,180 152,150 152,90 100,120', 'r'), face('a', '100,120 152,90 100,60 48,90', 't'),
 "<g transform='matrix(.866 .5 0 1 48 90)'><rect x='7' y='8' width='46' height='26' rx='4' class='c'/><circle cx='17' cy='21' r='5' class='b'/><circle cx='30' cy='21' r='5' fill='#f4b630'/><circle cx='43' cy='21' r='5' class='b'/><path d='M17 21l3-3M30 21l-3-3M43 21l2 3' stroke='#22252d' stroke-width='1.4'/><rect x='14' y='42' width='32' height='5' rx='2' fill='#22252d'/><rect x='0' y='53' width='60' height='7' fill='#3c4249'/></g>",
 "<g transform='matrix(.866 -.5 0 1 100 120)'><g fill='#22252d' opacity='.35'><rect x='12' y='14' width='30' height='3'/><rect x='12' y='21' width='30' height='3'/><rect x='12' y='28' width='30' height='3'/></g><rect x='0' y='53' width='60' height='7' fill='#3c4249'/></g>",
 "<path class='d' d='M100 120V180M100 120L152 90M100 120L48 90'/>",
 "<polygon points='106,116 144,94 106,72 68,94' fill='#1a1408' opacity='.22'/>",
 face('c', '100,112 62,90 62,50 100,72'), face('c', '100,112 138,90 138,50 100,72', 'r'), face('c', '100,72 138,50 100,28 62,50', 't'),
 "<g transform='matrix(.866 .5 0 1 62 50)'><rect x='4' y='5' width='36' height='30' rx='6' fill='#d8e5f1' stroke='#2f6db3' stroke-width='1.2'/><circle cx='14' cy='17' r='6' fill='#fff' stroke='#22252d' stroke-width='1.2'/><circle cx='30' cy='17' r='6' fill='#fff' stroke='#22252d' stroke-width='1.2'/><circle cx='15.5' cy='18' r='3' fill='#22252d'/><circle cx='31.5' cy='18' r='3' fill='#22252d'/><rect x='15' y='26' width='14' height='5' rx='2' class='b'/></g>",
 "<g transform='matrix(.866 -.5 0 1 100 72)'><circle cx='22' cy='20' r='8' class='b'/><circle cx='22' cy='20' r='3.5' class='c'/></g>",
 "<path class='d' d='M100 72V112M100 72L138 50M100 72L62 50'/>",
 "<path d='M100 50V25' stroke='#9aa1a8' stroke-width='2.5'/><circle cx='100' cy='22' r='5.5' fill='#d83a2e' class='e'/>",
 "</svg>",
]
critter = [
 "<ellipse cx='120' cy='172' rx='70' ry='19' fill='#04140a' opacity='.45' filter='url(#s)'/>",
 "<polygon points='143,155 150,150 150,116 143,111' fill='url(#h)'/>",
 face('a', '100,180 57,155 57,111 100,136'), face('a', '100,180 143,155 143,111 100,136', 'r'), face('a', '100,136 143,111 100,86 57,111', 't'),
 "<g transform='matrix(.866 .5 0 1 57 111)'><ellipse cx='25' cy='25' rx='14' ry='12' fill='#f7e6c8'/><ellipse cx='12' cy='41' rx='8' ry='3.5' class='b' opacity='.85'/><ellipse cx='38' cy='41' rx='8' ry='3.5' class='b' opacity='.85'/></g>",
 "<path class='d' d='M100 136V180M100 136L143 111M100 136L57 111'/>",
 "<polygon points='106,137 144,115 106,93 68,115' fill='#1a1408' opacity='.22'/>",
 face('a', '100,133 62,111 62,71 100,93'), face('a', '100,133 138,111 138,71 100,93', 'r'), face('a', '100,93 138,71 100,49 62,71', 't'),
 "<ellipse cx='77' cy='60' rx='10' ry='11' class='a e'/><ellipse cx='77' cy='61' rx='5' ry='6' fill='#e9798d'/>",
 "<ellipse cx='123' cy='60' rx='10' ry='11' class='a e'/><ellipse cx='123' cy='60' rx='10' ry='11' class='r'/><ellipse cx='123' cy='61' rx='5' ry='6' fill='#e9798d' opacity='.8'/>",
 "<g transform='matrix(.866 .5 0 1 62 71)'><circle cx='13' cy='15' r='3.4' fill='#22252d'/><circle cx='31' cy='15' r='3.4' fill='#22252d'/><circle cx='14.2' cy='13.8' r='1.1' fill='#fff'/><circle cx='32.2' cy='13.8' r='1.1' fill='#fff'/><ellipse cx='22' cy='27' rx='9' ry='7' fill='#f7e6c8'/><ellipse cx='22' cy='24' rx='3.6' ry='2.6' fill='#22252d'/><path d='M22 26.5v3M18.5 30.5q3.5 2.5 7 0' stroke='#22252d' stroke-width='1.2' fill='none'/><ellipse cx='7' cy='25' rx='3.5' ry='2.2' fill='#e9798d' opacity='.7'/><ellipse cx='37' cy='25' rx='3.5' ry='2.2' fill='#e9798d' opacity='.7'/></g>",
 "<path class='d' d='M100 93V133M100 93L138 71M100 93L62 71'/></svg>",
]
vehicle = [
 "<ellipse cx='112' cy='166' rx='84' ry='20' fill='#04140a' opacity='.45' filter='url(#s)'/>",
 "<polygon points='158,154 165,149 165,131 158,126' fill='url(#h)'/>",
 face('a', '120,176 47,134 47,106 120,148'), face('a', '120,176 158,154 158,126 120,148', 'r'), face('a', '120,148 158,126 85,84 47,106', 't'),
 "<g transform='matrix(.866 .5 0 1 47 106)'><rect x='0' y='9' width='84' height='5' class='b'/><circle cx='18' cy='28' r='11' fill='#3c4249' class='e'/><circle cx='18' cy='28' r='4.5' fill='#c3c8cd'/><circle cx='66' cy='28' r='11' fill='#3c4249' class='e'/><circle cx='66' cy='28' r='4.5' fill='#c3c8cd'/></g>",
 "<g transform='matrix(.866 -.5 0 1 120 148)'><circle cx='7' cy='9' r='3.5' fill='#f4b630'/><circle cx='37' cy='9' r='3.5' fill='#f4b630'/><rect x='14' y='12' width='16' height='6' rx='1' fill='#22252d' opacity='.55'/></g>",
 "<path class='d' d='M120 148V176M120 148L158 126M120 148L47 106'/>",
 "<polygon points='110,139 141,121 107,101 76,119' fill='#1a1408' opacity='.22'/>",
 face('a', '104,135 70,115 70,91 104,111'), face('a', '104,135 135,117 135,93 104,111', 'r'), face('a', '104,111 135,93 101,73 70,91', 't'),
 "<g transform='matrix(.866 .5 0 1 70 91)'><rect x='4' y='5' width='14' height='12' rx='2' fill='#bcd9ee' stroke='#22252d' stroke-opacity='.5'/><rect x='22' y='5' width='14' height='12' rx='2' fill='#bcd9ee' stroke='#22252d' stroke-opacity='.5'/></g>",
 "<g transform='matrix(.866 -.5 0 1 104 111)'><rect x='4' y='4' width='28' height='12' rx='2' fill='#bcd9ee' stroke='#22252d' stroke-opacity='.5'/></g>",
 "<path class='d' d='M104 111V135M104 111L135 93M104 111L70 91'/></svg>",
]
def letter(x, y, ch):
    return (f"<g transform='matrix(.866 .5 0 1 {x} {y})'><rect x='4' y='4' width='32' height='32' rx='3' fill='none' stroke='#fff' stroke-opacity='.6' stroke-width='1.5'/>"
            f"<text x='20' y='29' class='x'>{ch}</text></g>")
blocks = [
 "<ellipse cx='118' cy='170' rx='80' ry='19' fill='#04140a' opacity='.45' filter='url(#s)'/>",
 "<polygon points='174.6,154 181,149 181,119 174.6,114' fill='url(#h)'/>",
 face('b', '140,174 105.4,154 105.4,114 140,134'), face('b', '140,174 174.6,154 174.6,114 140,134', 'r'), face('b', '140,134 174.6,114 140,94 105.4,114', 't'),
 letter(105.4, 114, 'B'), "<path class='d' d='M140 134V174M140 134L174.6 114M140 134L105.4 114'/>",
 face('a', '78,182 43.4,162 43.4,122 78,142'), face('a', '78,182 112.6,162 112.6,122 78,142', 'r'),
 letter(43.4, 122, 'A'), "<path class='d' d='M78 142V182'/>",
 face('g', '78,142 43.4,122 43.4,82 78,102'), face('g', '78,142 112.6,122 112.6,82 78,102', 'r'), face('g', '78,102 112.6,82 78,62 43.4,82', 't'),
 letter(43.4, 82, 'C'), "<path class='d' d='M78 102V142M78 102L112.6 82M78 102L43.4 82'/></svg>",
]

TOYS = [
 (1, "Tin-Bot 3000", "Robot", "Robots", "2f6db3", "ee6b2d", 899, "6+", "R-01", 24, 5, "Fold-up tin robot with turning chest dials and a bright red antenna."),
 (2, "Sparky", "Robot", "Robots", "ee6b2d", "2f6db3", 749, "5+", "R-02", 20, 4, "A cheerful helper bot. The head clicks onto the body with one glue tab."),
 (3, "Mint Mech", "Robot", "Robots", "279c8e", "f4b630", 999, "8+", "R-03", 31, 5, "Teal workshop mech with printed vent panels and yellow dial lights."),
 (4, "Honey Bear", "Critter", "Critters", "ea8a39", "b9581a", 649, "4+", "C-01", 16, 5, "Chunky ginger bear with a cream belly and a printed button nose."),
 (5, "Polar Pal", "Critter", "Critters", "e6e1d6", "8fa3b8", 649, "4+", "C-02", 16, 4, "Snow-white bear cub. A perfect first fold for little hands."),
 (6, "Berry Bear", "Critter", "Critters", "e9798d", "7b4fb0", 699, "4+", "C-03", 18, 4, "Pink bear with purple paws and a fold-flat display stand."),
 (7, "Road Racer", "Vehicle", "Vehicles", "d83a2e", "f5f0e4", 799, "6+", "V-01", 22, 5, "Low red racer with printed spoked wheels and a racing stripe."),
 (8, "City Cab", "Vehicle", "Vehicles", "f4b630", "22252d", 749, "5+", "V-02", 21, 4, "Yellow taxi with checker trim. Windows are pre-scored for easy folding."),
 (9, "Parcel Van", "Vehicle", "Vehicles", "2f6db3", "f4b630", 849, "6+", "V-03", 26, 4, "Roomy delivery van. The roof folds open to stash tiny paper parcels."),
 (10, "ABC Blocks", "Blocks", "Blocks", "ee6b2d", "2f6db3", 499, "3+", "B-01", 12, 5, "Three stacking letter cubes printed on extra-thick cardstock."),
 (11, "Tower Trio", "Blocks", "Blocks", "279c8e", "e9798d", 549, "3+", "B-02", 12, 4, "Teal and pink stacking cubes with crisp scored fold lines."),
 (12, "Primary Stack", "Blocks", "Blocks", "d83a2e", "f4b630", 549, "3+", "B-03", 12, 4, "Red, yellow and green cubes: the classic starter stack."),
]

def fx_str(parts, indent="    "):
    # split into Power Fx string chunks joined with &
    out = []
    for p in parts:
        assert '"' not in p, p[:60]
        while len(p) > 700:
            cut = p.rfind('>', 0, 700) + 1 or 700
            out.append(p[:cut]); p = p[cut:]
        if p: out.append(p)
    return (" &\n" + indent).join('"' + c + '"' for c in out)

F = []
F.append("// ================= PAPER TOY CO. : App.Formulas =================\n// Papercraft visual kit: cutting mat, tent cards, template sheets, strip arrows, flags and low-poly toy models.\n")
F.append('SvgUri = "data:image/svg+xml;utf8,";\n')
F.append("// green self-healing cutting mat on a walnut desk (screen background)\nMatBg = SvgUri & EncodeUrl(\n    " + fx_str(mat) + ");\n")
F.append("// templates: HDR / HEXA / HEXB / MARK are placeholders swapped with Substitute()\nTentTpl =\n    " + fx_str(tent) + ";\n")
F.append("CardTpl =\n    " + fx_str(card) + ";\n")
F.append("SheetTpl =\n    " + fx_str(detail) + ";\n")
F.append("RowTpl =\n    " + fx_str(row) + ";\n")
F.append("StripTpl =\n    " + fx_str(strip) + ";\n")
F.append("FlagTpl =\n    " + fx_str(flag) + ";\n")
for n, c in [("Blue", "2f6db3"), ("Orange", "ee6b2d"), ("Red", "d83a2e"), ("Yellow", "f4b630"), ("Green", "2e9a57"), ("Teal", "279c8e"), ("Gray", "9b917c")]:
    F.append(f'Tent{n} = SvgUri & EncodeUrl(Substitute(TentTpl, "HDR", "{c}"));\n')
for n, c in [("Orange", "ee6b2d"), ("Green", "2e9a57"), ("Yellow", "f4b630")]:
    F.append(f'Strip{n} = SvgUri & EncodeUrl(Substitute(StripTpl, "HDR", "{c}"));\n')
F.append('FlagRed = SvgUri & EncodeUrl(Substitute(Substitute(FlagTpl, "HDR", "d83a2e"), "MARK", "M-13 -13L13 13M13 -13L-13 13"));\n')
F.append('FlagGreen = SvgUri & EncodeUrl(Substitute(Substitute(FlagTpl, "HDR", "2e9a57"), "MARK", "M-15 1L-5 11L15 -11"));\n')
F.append("NetArt = SvgUri & EncodeUrl(\n    " + fx_str(net) + ");\n")
F.append("RulerArt = SvgUri & EncodeUrl(\n    " + fx_str(ruler) + ");\n")
F.append("// low-poly toy models: left face lit by the warm key light, right face shaded, dotted fold lines, glue tabs\nArtHead =\n    " + fx_str([ART_HEAD]) + ";\n")
for n, body in [("ArtRobot", robot), ("ArtCritter", critter), ("ArtVehicle", vehicle), ("ArtBlocks", blocks)]:
    F.append(f"{n} = ArtHead &\n    " + fx_str(body) + ";\n")
rows = ",\n        ".join(
    f'{{Id: {t[0]}, Name: "{t[1]}", Kind: "{t[2]}", Cat: "{t[3]}", HexA: "{t[4]}", HexB: "{t[5]}", Price: {t[6]}, Age: "{t[7]}", Part: "{t[8]}", Pieces: {t[9]}, Rating: {t[10]}, Blurb: "{t[11]}"}}'
    for t in TOYS)
F.append("// the catalogue (Art column = ready-to-use SVG image for each kit)\nToys = AddColumns(\n    Table(\n        " + rows + "\n    ),\n"
         "    Art, SvgUri & EncodeUrl(Substitute(Substitute(\n        Switch(Kind, \"Robot\", ArtRobot, \"Critter\", ArtCritter, \"Vehicle\", ArtVehicle, ArtBlocks),\n"
         "        \"HEXA\", HexA), \"HEXB\", HexB))\n);\n")
open(os.path.join(OUT, "ToyShop_App_Formulas.txt"), "w").write("\n".join(F))

# ---------- preview of every asset ----------
def S(parts, **sub):
    s = "".join(parts)
    for k, v in sub.items(): s = s.replace(k, v)
    return s
tiles = [("mat", S(mat), 683, 384), ("tent", S(tent, HDR="2f6db3"), 400, 200), ("card", S(card, HDR="ee6b2d"), 300, 280),
         ("sheet", S(detail, HDR="2e9a57"), 223, 325), ("row", S(row, HDR="d83a2e"), 800, 132), ("strip", S(strip, HDR="ee6b2d"), 300, 60),
         ("flagR", S(flag, HDR="d83a2e", MARK="M-13 -13L13 13M13 -13L-13 13"), 160, 200), ("flagG", S(flag, HDR="2e9a57", MARK="M-15 1L-5 11L15 -11"), 160, 200),
         ("net", S(net), 300, 220), ("ruler", S(ruler), 720, 70)]
for t in TOYS:
    body = {"Robot": robot, "Critter": critter, "Vehicle": vehicle, "Blocks": blocks}[t[2]]
    tiles.append((t[1], (ART_HEAD + "".join(body)).replace("HEXA", t[4]).replace("HEXB", t[5]), 200, 200))
import urllib.parse
html = "<body style='background:#2d6c4e;margin:0;display:flex;flex-wrap:wrap;gap:8px;padding:8px'>" + "".join(
    f"<div style='background:{'#2d6c4e'}'><img width='{w}' height='{h}' src='data:image/svg+xml;utf8,{urllib.parse.quote(s)}'><div style='color:#fff;font:12px monospace'>{n}</div></div>"
    for n, s, w, h in tiles) + "</body>"
open(os.path.join(OUT, "preview.html"), "w").write(html)
print("ok", sum(len(x) for x in F))
