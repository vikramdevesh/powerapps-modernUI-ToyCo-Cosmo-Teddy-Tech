"""Standalone app builders: each visual style as its own self-contained Power Apps app.

  cosmo-kits          SpaceHomeScreen, SpaceShopScreen, SpaceCartScreen   (own cart: colCosmoCart)
  toys-that-made-us   StoryHomeScreen, StoryArchiveScreen, StoryQuizScreen (+ App.Formulas: Stories)
  spark-cube          LaunchScreen, LaunchSpecsScreen, LaunchBagScreen    (own bag: colSparkBag)

Every builder returns (screens: {name: [controls], ...}, onvisible: {name: formula}, fills: {name: formula}).
"""
import copy
from kit import *
import space as SP
import story as ST
import launch as LA


# ---------------------------------------------------------------- helpers
def tweak(ctrls, drop=(), repl=(), move=None):
    """Copy a control tree, dropping controls by name, replacing text in formulas/previews and moving controls."""
    out = []
    for c in ctrls:
        if c.name in drop: continue
        c = copy.copy(c)
        c.props = {k: _r(v, repl) for k, v in c.props.items()}
        c.pv = dict(c.pv)
        if "text" in c.pv and isinstance(c.pv["text"], str): c.pv["text"] = _r(c.pv["text"], repl)
        if move and c.name in move: c.geo = move[c.name]
        if c.children: c.children = tweak(c.children, drop, repl, move)
        if c.pv.get("kind") == "gal":
            b = c.pv["build"]; c.pv["build"] = lambda it, b=b: tweak(b(it), drop, repl, move)
        out.append(c)
    return out

def _r(v, repl):
    if not isinstance(v, str): return v
    for a, b in repl: v = v.replace(a, b)
    return v

def svgsub(svg, pairs):
    """Power Fx expression for an SVG data URI with placeholder substitutions: pairs = [(token, fx), ...]."""
    e = f'"{svg}"'
    for tok, fx in pairs: e = f'Substitute({e}, "{tok}", {fx})'
    return f'"data:image/svg+xml;utf8," & EncodeUrl({e})'

def line(name, geo, fx, pv):
    return L(name, geo, '""', "", 1, fill_fx=fx, fill=pv)

FULL = (0, 0, ("Parent.Width", 1366), ("Parent.Height", 768))


# ================================================================ COSMO KITS
def cosmo():
    R = [("colCart", "colCosmoCart"), ("Navigate(CartScreen", "Navigate(SpaceCartScreen"), ("gOrdered", "gCosmoOrdered"), ("Kit box", "Cargo bay"), ("kit box", "cargo bay")]
    h = tweak(SP.home(), drop={"SpBack"}, repl=R, move={"SpCart": (1134, 36, 186, 44)})
    s, s_on = SP.shop(); s = tweak(s, repl=R)
    c = cosmo_cart()
    return ({"SpaceHomeScreen": h, "SpaceShopScreen": s, "SpaceCartScreen": c},
            {"SpaceHomeScreen": 'If(IsBlank(gSpaceCat), Set(gSpaceCat, "All"))', "SpaceShopScreen": s_on, "SpaceCartScreen": ""},
            {})

def cosmo_cart():
    from space import sky, planet, robot, dotted, glow, spark, text_sh, SVG, PANEL, YEL, INKC, PINK, ARTS, KITS, art_rocket
    CART, SUB = "colCosmoCart", "Sum(colCosmoCart, Price * Qty)"
    bg = sky(55, planet(1250, 700, 210, "coral", 0.28) + planet(70, 720, 40, "moon") + planet(780, 40, 22, "teal", 0.25))
    hdr = SVG("0 0 520 90", text_sh(2, 64, "Cargo Bay", 60, "#ffffff"))
    ROW = SVG("0 0 780 104", "<defs><linearGradient id='rg' x1='0' y1='0' x2='1' y2='.4'><stop offset='0' stop-color='#2a1f72'/><stop offset='1' stop-color='#120d3f'/></linearGradient>"
              "<radialGradient id='rr' cx='.08' cy='.5' r='.35'><stop offset='0' stop-color='#HEX' stop-opacity='.5'/><stop offset='1' stop-color='#HEX' stop-opacity='0'/></radialGradient></defs>"
              "<rect x='5' y='8' width='772' height='94' rx='26' fill='#05041c' fill-opacity='.45'/><rect x='1' y='2' width='772' height='94' rx='26' fill='url(#rg)'/>"
              "<rect x='1' y='2' width='772' height='94' rx='26' fill='url(#rr)'/><rect x='130' y='9' width='140' height='6' rx='3' fill='#fff' fill-opacity='.14'/>"
              "<circle cx='700' cy='22' r='1.6' fill='#fff' fill-opacity='.6'/><circle cx='420' cy='84' r='1.3' fill='#fff' fill-opacity='.45'/>", "none")
    bot = SVG("0 0 300 330", robot(150, 200, 70, happy=True))
    ok = SVG("0 0 800 600", "<defs><linearGradient id='og' x1='0' y1='0' x2='.3' y2='1'><stop offset='0' stop-color='#241a62' stop-opacity='.95'/><stop offset='1' stop-color='#0d0a33' stop-opacity='.97'/></linearGradient></defs>"
             "<rect x='8' y='12' width='786' height='584' rx='40' fill='#05041c' fill-opacity='.5'/><rect x='2' y='2' width='786' height='584' rx='40' fill='url(#og)'/>"
             + glow(400, 170, 260, "#ff8d3f", 0.3) + planet(690, 500, 70, "magenta", 0.25) + planet(110, 120, 26, "moon")
             + dotted("M120,520C260,500 300,330 380,250", "#7ff0ff", 8, ((380, 250), -0.95), 0.75)
             + spark(600, 110, 10) + spark(180, 300, 7) + spark(700, 250, 6), "none")
    rocket = art_rocket()
    sample = [dict(name=k[1], part=f"S-0{k[0]-100}", hexa=k[3], art=ARTS[k[0]], price=k[4], qty=q) for k, q in ((KITS[0], 1), (KITS[2], 2), (KITS[4], 1))]
    TW, TH = 780, 104
    TRANS = dict(fill_fx="RGBA(255, 255, 255, 0.14)", pvfill="rgba(255,255,255,.14)")

    def row(it):
        return [
            I("ScRowBg", (0, 0, ("Parent.TemplateWidth", TW), ("Parent.TemplateHeight", TH)), svgsub(ROW, [("HEX", "ThisItem.HexA")]), ROW.replace("HEX", it["hexa"]), "Stretch"),
            I("ScRowArt", (16, 4, 96, 96), "ThisItem.Art", it["art"]),
            L("ScRowName", (128, 18, 300, 34), "ThisItem.Name", it["name"], 19, align="Left"),
            L("ScRowPart", (128, 56, 300, 26), 'ThisItem.Part & "  ·  ₹" & Text(ThisItem.Price, "#,##0") & " each"', f"{it['part']}  ·  ₹{it['price']:,} each", 12, "segoe", "semi", "bfe9ff", "Left"),
            B("ScMinus", (440, 30, 44, 44), '"–"', "–", "ffffff", "ffffff", f"If(\n    ThisItem.Qty <= 1,\n    Remove({CART}, ThisItem),\n    Patch({CART}, ThisItem, {{Qty: ThisItem.Qty - 1}})\n)", 20, **TRANS),
            L("ScQty", (488, 30, 50, 44), "ThisItem.Qty", str(it["qty"]), 20),
            B("ScPlus", (542, 30, 44, 44), '"+"', "+", "ffffff", "ffffff", f"Patch({CART}, ThisItem, {{Qty: ThisItem.Qty + 1}})", 20, **TRANS),
            L("ScLine", (594, 28, 136, 48), '"₹" & Text(ThisItem.Price * ThisItem.Qty, "#,##0")', f"₹{it['price']*it['qty']:,}", 21, color=YEL, align="Right"),
            B("ScDel", (738, 35, 34, 34), '"✕"', "✕", "ffffff", "bfe9ff", f"Remove({CART}, ThisItem)", 13, fill_fx="RGBA(0, 0, 0, 0)", hover_fx="RGBA(255, 93, 143, 0.35)", pvfill="transparent", pvcolor="#bfe9ff"),
        ]

    EMPTY, NOTDONE = f"IsEmpty({CART}) && !gCosmoOrdered", "!gCosmoOrdered"
    ship = f'With({{s: {SUB}}}, If(s = 0 || s >= 1999, 0, 99))'
    total = f'With({{s: {SUB}}}, s + If(s = 0 || s >= 1999, 0, 99))'
    cs = [I("ScBg", FULL, svgfx(bg), bg, "Fill"),
          I("ScTitle", (40, 22, 520, 90), svgfx(hdr), hdr),
          B("ScHome", (902, 36, 196, 44), '"Mission control"', "Mission control", "ffffff", "ffffff", "Navigate(SpaceHomeScreen, ScreenTransition.UnCover)", 14, **TRANS),
          B("ScBack", (1110, 36, 210, 44), '"←  Launch Pad"', "←  Launch Pad", "ffffff", "ffffff", "Navigate(SpaceShopScreen, ScreenTransition.UnCover)", 15, **TRANS),
          L("ScCount", (46, 112, 760, 30), f'"Kits on board: " & Sum({CART}, Qty)', "Kits on board: 4", 15, "segoe", "semi", "bfe9ff", "Left"),
          GALC("ScList", (32, 148, 806, 610), CART, row(sample[0]), dict(kind="gal", items=sample, tw=TW, th=TH, wrap=1, pad=10, build=row), TH, 1, 10),
          L("ScEmpty", (60, 300, 750, 50), '"Your cargo bay is empty."', "Your cargo bay is empty.", 28, visible=EMPTY, pvhide=True),
          L("ScEmptySub", (60, 352, 750, 30), '"Pick a kit on the Launch Pad to start your mission."', "Pick a kit on the Launch Pad to start your mission.", 15, "segoe", "semi", "bfe9ff", visible=EMPTY, pvhide=True),
          B("ScEmptyBtn", (305, 404, 260, 58), '"Browse kits  →"', "Browse kits  →", YEL, INKC, "Navigate(SpaceShopScreen, ScreenTransition.Cover)", 20, visible=EMPTY, pvhide=True),
          # summary panel
          I("ScPanel", (850, 112, 480, 640), svgfx(PANEL), PANEL, "Stretch"),
          I("ScBot", (862, 120, 170, 190), svgfx(bot), bot),
          L("ScSumTitle", (1040, 150, 270, 40), '"Mission summary"', "Mission summary", 22, align="Left"),
          L("ScSumSub", (1040, 192, 270, 50), '"Free shipping on orders over ₹1,999"', "Free shipping on orders over ₹1,999", 13, "segoe", "semi", "bfe9ff", "Left", "Top", wrap=True)]
    for i, (lab, fx, pv) in enumerate((("Kits on board", f"Sum({CART}, Qty)", "4"),
                                       ("Subtotal", f'"₹" & Text({SUB}, "#,##0")', "₹5,796"),
                                       ("Shipping", f'If({ship} = 0, "FREE", "₹" & {ship})', "FREE"))):
        y = 330 + i * 46
        cs += [L(f"ScK{i}", (884, y, 220, 36), f'"{lab}"', lab, 16, "segoe", "semi", "bfe9ff", "Left"),
               L(f"ScV{i}", (1104, y, 200, 36), fx, pv, 18, align="Right")]
    cs += [line("ScDiv", (884, 472, 420, 2), "RGBA(255, 255, 255, 0.22)", "3b3480"),
           L("ScTotK", (884, 492, 200, 44), '"Total"', "Total", 20, align="Left"),
           L("ScTotV", (1004, 484, 300, 60), f'"₹" & Text({total}, "#,##0")', "₹5,796", 38, color=YEL, align="Right"),
           B("ScLaunch", (884, 620, 420, 66), '"Launch order  ✦"', "Launch order  ✦", YEL, INKC,
             f"Set(gCosmoTotal, {total});\nSet(gCosmoOrdered, true);\nClear({CART})", 22,
             extra={"DisplayMode": f"If(IsEmpty({CART}), DisplayMode.Disabled, DisplayMode.Edit)", "DisabledFill": "RGBA(255, 255, 255, 0.14)", "DisabledColor": col("8f8ac0")}),
           L("ScNote", (884, 694, 420, 40), '"Ships in 3 days in a reusable rocket box"', "Ships in 3 days in a reusable rocket box", 12, "segoe", "semi", "bfe9ff"),
           # order launched
           I("ScOkBg", (32, 148, 800, 600), svgfx(ok), ok, "Stretch", visible="gCosmoOrdered", pvhide=True),
           I("ScOkArt", (330, 190, 210, 210), svgfx(rocket), rocket, visible="gCosmoOrdered", pvhide=True),
           L("ScOkTitle", (60, 420, 740, 64), '"Order launched!"', "Order launched!", 44, color=YEL, visible="gCosmoOrdered", pvhide=True),
           L("ScOkSub", (60, 486, 740, 34), '"Lift-off in 3 days.  Total: ₹" & Text(gCosmoTotal, "#,##0")', "Lift-off in 3 days.  Total: ₹5,796", 18, visible="gCosmoOrdered", pvhide=True),
           B("ScOkBtn", (300, 560, 270, 58), '"Explore more kits  →"', "Explore more kits  →", YEL, INKC,
             "Set(gCosmoOrdered, false);\nNavigate(SpaceShopScreen, ScreenTransition.Cover)", 19, visible="gCosmoOrdered", pvhide=True)]
    return cs


# ================================================================ THE TOYS THAT MADE US
def story_formulas():
    rows = ",\n    ".join(f'{{Idx: {s[0]}, Year: "{s[1]}", Kicker: "{s[2]}", Title: "{s[3]}", Deck: "{s[4]}", Key: "{s[5]}", '
                           f'Art: {svgfx(ST.print_svg(s[6], 200 + s[0], 330, 250, rot=(s[0] % 2) * 2 - 1))}}}' for s in ST.STORIES)
    return ("// ================= THE TOYS THAT MADE US : App.Formulas =================\n"
            "// The archive entries. Edit STORIES in scripts/story.py and rebuild, or edit the text fields here.\n\n"
            f"Stories = Table(\n    {rows}\n);\n")

def story():
    from story import strip, INK, CARD
    quiz = strip("POP QUIZ  →", 200, 46, CARD, INK, 16, font=ST.OSW, size=24)
    h = tweak(ST.home(), drop={"StBack", "StBackHit"})
    h += [I("StQuiz", (1130, 6, 240, 86), svgfx(quiz), quiz),
          HIT("StQuizHit", (1150, 26, 200, 46), "Navigate(StoryQuizScreen, ScreenTransition.Cover)", "Take the quiz", "RGBA(26, 24, 22, 0.08)")]
    a, _ = ST.archive()
    a_on = "ClearCollect(colStories, Stories);\nIf(IsBlank(gStoryIdx) || gStoryIdx < 1, Set(gStoryIdx, 1))"
    q, q_on = story_quiz()
    f = 'ColorValue("#f0e9d9")'
    return ({"StoryHomeScreen": h, "StoryArchiveScreen": a, "StoryQuizScreen": q},
            {"StoryHomeScreen": "", "StoryArchiveScreen": a_on, "StoryQuizScreen": q_on},
            {"StoryHomeScreen": f, "StoryArchiveScreen": f, "StoryQuizScreen": f})

def story_quiz():
    from story import (strip, paperpoly, torn_rect, tape, marker_ring, paper_bg, print_svg, SVG, FIB, INK, RED, CARD, NEWS, KRAFT, OSW, STORIES)
    Q = "Index(colQuiz, gQuizRound)"
    OPTS = ("With(\n    {q: Index(colQuiz, gQuizRound), o: FirstN(Shuffle(Filter(Stories, Idx <> Index(colQuiz, gQuizRound).Idx)), 2)},\n"
            "    ClearCollect(colQuizOpts, Shuffle(Table({Y: q.Year}, {Y: First(o).Year}, {Y: Last(o).Year})))\n)")
    START = f"ClearCollect(colQuiz, Shuffle(Stories));\nSet(gQuizRound, 1);\nSet(gQuizScore, 0);\nSet(gQuizPick, Blank());\nSet(gQuizDone, false);\n{OPTS}"
    kraft = paperpoly(torn_rect(18, 104, 560, 430, 27, (1, 1, 1, 1), 7), KRAFT, 0.5) + tape(520, 116, 90, 26, 30, 28) + tape(60, 520, 90, 26, -18, 29)
    red = paperpoly(torn_rect(-20, 600, 640, 220, 37, (1, 0, 0, 0), 7), RED, 0.55)
    bg = paper_bg(kraft + red, 8)
    back = strip("←  THE TOYS THAT MADE US", 330, 46, CARD, INK, 113, font=OSW, size=24)
    title = strip("POP QUIZ", 260, 70, CARD, INK, 121, hl=True)
    score = strip("SCORE 0/6", 220, 56, INK, "#f3efe5", 122, font=OSW, size=34)
    qpanel = SVG("0 0 900 330", f"<defs>{FIB}</defs>" + paperpoly(torn_rect(20, 16, 850, 290, 123, (1, 0, 1, 1), 5), NEWS, 0.8)
                 + f"<rect x='44' y='66' width='800' height='2' fill='{INK}'/><rect x='44' y='71' width='800' height='.8' fill='{INK}'/>" + tape(450, 18, 120, 30, -3, 124), "none")
    opt = strip("YEAR", 200, 96, INK, "#f3efe5", 125, size=82)
    ring = SVG("0 0 280 150", marker_ring(140, 75, 128, 62, 4.4, RED, 7), "none")
    cross = SVG("0 0 220 120", f"<path d='M28,22 L104,64 L190,100' fill='none' stroke='{RED}' stroke-width='9' stroke-linecap='round' stroke-opacity='.9'/>"
                f"<path d='M188,18 L110,58 L34,104' fill='none' stroke='{RED}' stroke-width='9' stroke-linecap='round' stroke-opacity='.9'/>", "none")
    nxt = strip("NEXT  →", 150, 50, INK, "#f3efe5", 126, font=OSW, size=28)
    again = strip("PLAY AGAIN", 200, 50, INK, "#f3efe5", 127, font=OSW, size=28)
    arch = strip("READ THE ARCHIVE  →", 300, 50, CARD, INK, 128, font=OSW, size=28)
    done = SVG("0 0 900 420", f"<defs>{FIB}</defs>" + paperpoly(torn_rect(20, 20, 850, 370, 129, (1, 1, 1, 1), 6), NEWS, 0.85)
               + tape(120, 26, 110, 30, -12, 130) + tape(760, 30, 110, 30, 10, 131), "none")
    s1, s2 = STORIES[1], STORIES[3]
    sample_years = ["1959", s1[1], "1974"]
    picked = "!IsBlank(gQuizPick)"
    cs = [I("QzBg", FULL, svgfx(bg), bg, "Fill"),
          I("QzBack", (10, 4, 370, 86), svgfx(back), back),
          HIT("QzBackHit", (30, 24, 330, 46), "Navigate(StoryHomeScreen, ScreenTransition.UnCover)", "Back to the cover", "RGBA(26, 24, 22, 0.08)"),
          I("QzTitle", (520, 6, 300, 110), svgfx(title), title),
          I("QzScore", (1086, 14, 260, 96), svgsub(score, [("0/6", 'gQuizScore & "/" & CountRows(colQuiz)')]), score),
          I("QzPrint", (40, 120, 520, 394), f"{Q}.Art", print_svg(s1[6], 202, 330, 250, rot=1)),
          I("QzPanel", (596, 116, 750, 250), svgfx(qpanel), qpanel, "Stretch"),
          L("QzKick", (640, 146, 640, 24), f'"QUESTION " & gQuizRound & " OF " & CountRows(colQuiz)', "QUESTION 2 OF 6", 12, "segoe", "bold", "1a1816", "Left"),
          L("QzHead", (640, 190, 670, 50), f"{Q}.Title", s1[3], 28, "serif", "bold", "1a1816", "Left"),
          L("QzAsk", (640, 246, 670, 40), '"In which year did this happen?"', "In which year did this happen?", 18, "serif", color="2a2622", align="Left", italic=True)]
    for n in (1, 2, 3):
        x = 606 + (n - 1) * 246; O = f"Index(colQuizOpts, {n}).Y"
        pick = (f"If(\n    IsBlank(gQuizPick),\n    Set(gQuizPick, {O});\n    If({O} = {Q}.Year, Set(gQuizScore, gQuizScore + 1))\n)")
        cs += [I(f"QzOpt{n}", (x, 372, 240, 136), svgsub(opt, [("YEAR", O)]), opt.replace("YEAR", sample_years[n - 1])),
               HIT(f"QzOptHit{n}", (x + 20, 392, 200, 96), pick, "Pick this year", "RGBA(255, 226, 38, 0.18)"),
               I(f"QzRing{n}", (x - 20, 364, 280, 150), svgfx(ring), ring, "Stretch", visible=f"{picked} && {O} = {Q}.Year", pvhide=n != 2),
               I(f"QzCross{n}", (x + 10, 382, 220, 120), svgfx(cross), cross, "Stretch", visible=f"gQuizPick = {O} && {O} <> {Q}.Year", pvhide=n != 1)]
    cs += [L("QzVerdict", (612, 524, 720, 44), f'If(gQuizPick = {Q}.Year, "Right! It was " & {Q}.Year & ".", "Not quite. It was " & {Q}.Year & ".")',
             f"Not quite. It was {s1[1]}.", 26, "serif", "bold", "1a1816", "Left", visible=picked),
           L("QzKey", (612, 578, 520, 40), f"{Q}.Key", s1[5], 17, "serif", "bold", "1a1816", "Left", fill_fx="RGBA(255, 226, 38, 0.78)", pad=10, visible=picked),
           L("QzDeck", (40, 530, 520, 70), f"{Q}.Deck", s1[4], 13, "serif", color="2a2622", align="Left", valign="Top", wrap=True, italic=True, visible=picked),
           I("QzNext", (1150, 628, 190, 90), svgfx(nxt), nxt, visible=f"{picked} && !gQuizDone"),
           HIT("QzNextHit", (1170, 648, 150, 50), f"If(\n    gQuizRound >= CountRows(colQuiz),\n    Set(gQuizDone, true),\n    Set(gQuizRound, gQuizRound + 1);\n    Set(gQuizPick, Blank());\n    {OPTS}\n)",
               "Next question", "RGBA(255, 255, 255, 0.12)")]
    cs[-1].props["Visible"] = f"{picked} && !gQuizDone"
    # final score card
    D = "gQuizDone"
    cs += [I("QzDone", (233, 150, 900, 420), svgfx(done), done, "Stretch", visible=D, pvhide=True),
           L("QzDoneKick", (300, 214, 760, 26), '"FINAL SCORE"', "FINAL SCORE", 14, "segoe", "bold", "1a1816", visible=D, pvhide=True),
           L("QzDoneNum", (300, 246, 760, 100), 'gQuizScore & " / " & CountRows(colQuiz)', "5 / 6", 66, color="1a1816", visible=D, pvhide=True),
           L("QzDoneMsg", (300, 352, 760, 40), 'If(gQuizScore >= 5, "A true toy historian.", gQuizScore >= 3, "Nicely played. Read the archive to get them all.", "Read the archive, then try again.")',
             "A true toy historian.", 20, "serif", color="2a2622", italic=True, visible=D, pvhide=True),
           I("QzAgain", (380, 420, 240, 90), svgfx(again), again, visible=D, pvhide=True),
           HIT("QzAgainHit", (400, 440, 200, 50), START, "Play again", "RGBA(255, 255, 255, 0.12)"),
           I("QzArch", (650, 420, 340, 90), svgfx(arch), arch, visible=D, pvhide=True),
           HIT("QzArchHit", (670, 440, 300, 50), "Set(gStoryIdx, 1);\nNavigate(StoryArchiveScreen, ScreenTransition.Cover)", "Read the archive", "RGBA(26, 24, 22, 0.08)")]
    cs[-3].props["Visible"] = D; cs[-1].props["Visible"] = D
    return cs, START


# ================================================================ SPARK CUBE
def spark():
    R = [("colCart", "colSparkBag"), ("Navigate(CartScreen", "Navigate(LaunchBagScreen"), ("gOrdered", "gSparkOrdered"),
         ("your kit box", "your bag"), ("View kit box", "View bag"), ("Paper Toy Co.", "Spark Labs")]
    l = tweak(LA.launch(), drop={"LaBack"}, repl=R)
    s, s_on = LA.specs(); s = tweak(s, repl=R)
    b = spark_bag()
    return ({"LaunchScreen": l, "LaunchSpecsScreen": s, "LaunchBagScreen": b},
            {"LaunchScreen": "", "LaunchSpecsScreen": s_on, "LaunchBagScreen": ""},
            {"LaunchScreen": 'ColorValue("#030304")', "LaunchSpecsScreen": 'ColorValue("#f4f4f7")', "LaunchBagScreen": 'ColorValue("#f4f4f7")'})

def spark_bag():
    from launch import bg_white, hero_white, ICON, SVG
    BAG, SUB = "colSparkBag", "Sum(colSparkBag, Price * Qty)"
    bw, hero = bg_white(), hero_white("Violet")
    tile = SVG("0 0 400 200", "<rect x='1' y='1' width='398' height='198' rx='22' fill='#fff' stroke='#e2e2e7'/>", "none")
    TW, TH = 780, 128
    sample = [dict(name=f"Spark Cube · {f}", price=4999, qty=q) for f, q in (("Graphite", 1), ("Violet", 2))]
    BLUE = dict(fill_fx="RGBA(0, 0, 0, 0)", hover_fx="RGBA(0, 102, 204, 0.08)", pvfill="transparent", pvcolor="#0066cc")
    STEP = dict(fill_fx=col("f5f5f7"), pvfill="#f5f5f7", hover_fx=col("e8e8ed"))

    def row(it):
        return [
            I("LbRowBg", (0, 0, ("Parent.TemplateWidth", TW), ("Parent.TemplateHeight", TH)), svgfx(tile), tile, "Stretch"),
            I("LbRowIcon", (16, 14, 100, 100), "ThisItem.Art", ICON),
            L("LbRowName", (140, 20, 400, 34), "ThisItem.Name", it["name"], 19, "segoe", "semi", "1d1d1f", "Left"),
            L("LbRowShip", (140, 54, 400, 24), '"Ships in time for the holidays"', "Ships in time for the holidays", 13, "segoe", "normal", "6e6e73", "Left"),
            B("LbMinus", (140, 84, 36, 32), '"–"', "–", "f5f5f7", "1d1d1f", f"If(\n    ThisItem.Qty <= 1,\n    Remove({BAG}, ThisItem),\n    Patch({BAG}, ThisItem, {{Qty: ThisItem.Qty - 1}})\n)", 16, "segoe", "semi", **STEP),
            L("LbQty", (180, 84, 40, 32), "ThisItem.Qty", str(it["qty"]), 15, "segoe", "semi", "1d1d1f"),
            B("LbPlus", (224, 84, 36, 32), '"+"', "+", "f5f5f7", "1d1d1f", f"Patch({BAG}, ThisItem, {{Qty: ThisItem.Qty + 1}})", 16, "segoe", "semi", **STEP),
            B("LbRemove", (276, 84, 100, 32), '"Remove"', "Remove", "000000", "0066cc", f"Remove({BAG}, ThisItem)", 14, "segoe", "semi", radius=8, **BLUE),
            L("LbRowPrice", (TW - 236, 40, 210, 44), '"₹" & Text(ThisItem.Price * ThisItem.Qty, "#,##0")', f"₹{it['price']*it['qty']:,}", 22, "segoe", "bold", "1d1d1f", "Right"),
        ]

    EMPTY, OK = f"IsEmpty({BAG}) && !gSparkOrdered", "gSparkOrdered"
    cs = [I("LbBg", FULL, svgfx(bw), bw, "Fill"),
          B("LbBack", (24, 22, 210, 40), '"‹  Spark Cube"', "‹  Spark Cube", "000000", "0066cc", "Navigate(LaunchSpecsScreen, ScreenTransition.Fade)", 15, "segoe", "semi", **BLUE),
          L("LbTag", (1080, 22, 262, 40), '"Spark Labs  ·  Bag"', "Spark Labs  ·  Bag", 14, "segoe", "semi", "6e6e73", "Right"),
          L("LbHead", (60, 72, 760, 64), '"Review your bag."', "Review your bag.", 38, "segoe", "bold", "1d1d1f", "Left"),
          L("LbSub", (62, 134, 760, 30), f'"Free delivery.  " & Sum({BAG}, Qty) & If(Sum({BAG}, Qty) = 1, " item", " items")', "Free delivery.  3 items", 16, "segoe", "normal", "6e6e73", "Left"),
          GALC("LbList", (50, 176, 800, 560), BAG, row(sample[0]), dict(kind="gal", items=sample, tw=TW, th=TH, wrap=1, pad=10, build=row), TH, 1, 10),
          L("LbEmpty", (60, 250, 760, 50), '"Your bag is empty."', "Your bag is empty.", 26, "segoe", "bold", "1d1d1f", "Left", visible=EMPTY, pvhide=True),
          B("LbEmptyBtn", (60, 312, 240, 48), '"Choose a finish  ›"', "Choose a finish  ›", "0071e3", "ffffff", "Navigate(LaunchSpecsScreen, ScreenTransition.Fade)", 16, "segoe", "semi", visible=EMPTY, pvhide=True),
          I("LbSumBg", (876, 176, 440, 420), svgfx(tile), tile, "Stretch"),
          L("LbSumTitle", (904, 200, 384, 34), '"Order summary"', "Order summary", 20, "segoe", "semi", "1d1d1f", "Left"),
          L("LbSubK", (904, 254, 200, 30), '"Subtotal"', "Subtotal", 16, "segoe", "normal", "6e6e73", "Left"),
          L("LbSubV", (1088, 254, 200, 30), f'"₹" & Text({SUB}, "#,##0")', "₹14,997", 16, "segoe", "semi", "1d1d1f", "Right"),
          L("LbShipK", (904, 292, 200, 30), '"Delivery"', "Delivery", 16, "segoe", "normal", "6e6e73", "Left"),
          L("LbShipV", (1088, 292, 200, 30), '"Free"', "Free", 16, "segoe", "semi", "1d1d1f", "Right"),
          line("LbDiv", (904, 338, 384, 1), col("e2e2e7"), "e2e2e7"),
          L("LbTotK", (904, 360, 180, 44), '"Total"', "Total", 20, "segoe", "semi", "1d1d1f", "Left"),
          L("LbTotV", (1048, 352, 240, 56), f'"₹" & Text({SUB}, "#,##0")', "₹14,997", 32, "segoe", "bold", "7c4dff", "Right"),
          B("LbCheckout", (904, 434, 384, 52), '"Check out"', "Check out", "0071e3", "ffffff",
            f"Set(gSparkTotal, {SUB});\nSet(gSparkOrdered, true);\nClear({BAG})", 17, "segoe", "semi",
            extra={"DisplayMode": f"If(IsEmpty({BAG}), DisplayMode.Disabled, DisplayMode.Edit)", "DisabledFill": col("d2d2d7"), "DisabledColor": col("ffffff")}),
          L("LbFine", (904, 500, 384, 70), '"Pre-orders ship in time for the holidays. Free delivery on every order."',
            "Pre-orders ship in time for the holidays. Free delivery on every order.", 12, "segoe", "normal", "6e6e73", "Left", "Top", wrap=True),
          # order placed
          I("LbOkBg", FULL, svgfx(bw), bw, "Fill", visible=OK, pvhide=True),
          I("LbOkHero", (40, 110, 620, 560), svgfx(hero), hero, visible=OK, pvhide=True),
          L("LbOkHead", (720, 220, 600, 80), '"You’re in."', "You’re in.", 54, "segoe", "bold", "1d1d1f", "Left", visible=OK, pvhide=True),
          L("LbOkSub", (722, 308, 560, 90), '"Spark Cube ships in time for the holidays. Order total: ₹" & Text(gSparkTotal, "#,##0") & "."',
            "Spark Cube ships in time for the holidays. Order total: ₹14,997.", 18, "segoe", "normal", "6e6e73", "Left", "Top", wrap=True, visible=OK, pvhide=True),
          B("LbOkBtn", (720, 420, 240, 48), '"Back to overview  ›"', "Back to overview  ›", "0071e3", "ffffff",
            "Set(gSparkOrdered, false);\nNavigate(LaunchScreen, ScreenTransition.Fade)", 16, "segoe", "semi", visible=OK, pvhide=True)]
    return cs
