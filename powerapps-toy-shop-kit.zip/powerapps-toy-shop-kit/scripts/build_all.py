"""Rebuild every app in the kit as paste-ready Power Apps YAML.

Usage:  python scripts/build_all.py [OUT_DIR] [--mocks]

Writes one folder per app to OUT_DIR (default: ./build):
  paper-toy-co/        papercraft kit shop (3 screens + App.Formulas.txt)
  cosmo-kits/          space science toy store (3 screens)
  toys-that-made-us/   toy-history museum guide with a quiz (3 screens + App.Formulas.txt)
  spark-cube/          product launch and pre-order (3 screens)
  all-in-one/          the original combined toy shop: all 4 styles in one app (9 screens)
Each folder holds one <ScreenName>.pa.yaml per screen. With --mocks it also writes
mock_<Screen>.html files, rough HTML renders for checking layout before pasting.

Edit the data tables to customise the content:
  gen.py    TOYS     base catalogue (name, category, colours, price, age, description)
  space.py  KITS     Cosmo Kits products and their "Did you know?" facts
  story.py  STORIES  toy-history entries for The Toys That Made Us
  launch.py          Spark Cube copy, price and finishes
"""
import os, re, sys, subprocess, shutil

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
args = [a for a in sys.argv[1:] if not a.startswith("--")]
MOCKS = "--mocks" in sys.argv
OUT = os.path.abspath(args[0] if args else "build")
TMP = os.path.join(OUT, "_work")
os.makedirs(TMP, exist_ok=True)

# 1) base pack: App.Formulas + HomeScreen / CatalogScreen / CartScreen (gen.py runs inside screens.py)
subprocess.run([sys.executable, os.path.join(HERE, "screens.py"), TMP], check=True, cwd=HERE)

from kit import screen_yaml, controls_yaml, mock, I, L, HIT  # noqa: E402
import space, story, launch  # noqa: E402

def split(text):
    lines = text.split("\n")[1:]
    idx = [i for i, l in enumerate(lines) if re.match(r"^  [A-Za-z0-9]+:$", l)]
    return {lines[i].strip()[:-1]: "Screens:\n" + "\n".join(lines[i:(idx[k + 1] if k + 1 < len(idx) else len(lines))]).rstrip("\n") + "\n"
            for k, i in enumerate(idx)}

screens = {n: open(os.path.join(TMP, n + ".pa.yaml"), encoding="utf-8").read() for n in ("HomeScreen", "CatalogScreen", "CartScreen")}
base = dict(screens)
mocks = {}

# 2) Cosmo Kits (Flat-Vector Science)
h = space.home(); s, onvis = space.shop()
screens.update(split(screen_yaml("SpaceHomeScreen", h, 'If(IsBlank(gSpaceCat), Set(gSpaceCat, "All"))')
                     + screen_yaml("SpaceShopScreen", s, onvis, header=False)))
mocks.update(SpaceHomeScreen=mock(h), SpaceShopScreen=mock(s))

# 3) The Toys That Made Us (Editorial Essay Collage)
h = story.home(); a, aon = story.archive()
screens.update(split(screen_yaml("StoryHomeScreen", h, "", 'ColorValue("#f0e9d9")')
                     + screen_yaml("StoryArchiveScreen", a, aon, 'ColorValue("#f0e9d9")', header=False)))
mocks.update(StoryHomeScreen=mock(h), StoryArchiveScreen=mock(a))

# 4) Spark Cube (Product Launch Reveal)
l = launch.launch(); p, pon = launch.specs()
screens.update(split(screen_yaml("LaunchScreen", l, "", 'ColorValue("#030304")')
                     + screen_yaml("LaunchSpecsScreen", p, pon, 'ColorValue("#f4f4f7")', header=False)))
mocks.update(LaunchScreen=mock(l), LaunchSpecsScreen=mock(p))

# 5) nav tents on HomeScreen that open each style pack
nav = []
for i, (nm, tent, txt, scr) in enumerate([("Space", "TentTeal", "SPACE KITS", "SpaceHomeScreen"),
                                          ("Story", "TentRed", "TOY STORIES", "StoryHomeScreen"),
                                          ("Launch", "TentGray", "NEW: SPARK CUBE", "LaunchScreen")]):
    x = 770 + i * 136
    nav.append(I(f"HomeNav{nm}Tent", (x, 10, 130, 66), tent, "", "Stretch"))
    nav.append(L(f"HomeNav{nm}Txt", (x + 6, 28, 118, 36), f'"{txt}"', txt, 11, "lato", color="22252d"))
    nav.append(HIT(f"HomeNav{nm}Btn", (x, 10, 130, 66), f"Navigate({scr}, ScreenTransition.Cover)", f"Open {txt.title()}", "RGBA(255, 248, 230, 0.14)"))
navy = "\n".join(("      " + ln) if ln else ln for ln in controls_yaml(nav).rstrip("\n").split("\n"))
screens["HomeScreen"] = screens["HomeScreen"].rstrip("\n") + "\n" + navy + "\n"

# write + validate
try:
    import yaml
except ImportError:
    yaml = None
FORMULAS = open(os.path.join(TMP, "ToyShop_App_Formulas.txt"), encoding="utf-8").read()
base_mocks = {n: open(os.path.join(TMP, f"mock_{n}.html"), encoding="utf-8").read() for n in base}

def write_app(folder, scr, formulas=None, mk=None):
    d = os.path.join(OUT, folder); os.makedirs(d, exist_ok=True)
    for name, y in scr.items():
        if yaml: yaml.safe_load(y)
        open(os.path.join(d, name + ".pa.yaml"), "w", encoding="utf-8").write(y)
    if formulas: open(os.path.join(d, "App.Formulas.txt"), "w", encoding="utf-8").write(formulas)
    if MOCKS and mk:
        for n, m in mk.items(): open(os.path.join(d, f"mock_{n}.html"), "w", encoding="utf-8").write(m)
    return len(scr)

import standalone  # noqa: E402
def build_standalone(fn):
    ctrls, onv, fills = fn()
    ys = {n: screen_yaml(n, c, onv.get(n, ""), fills.get(n, 'ColorValue("#000000")')) for n, c in ctrls.items()}
    return ys, {n: mock(c) for n, c in ctrls.items()}

n = write_app("all-in-one", screens, FORMULAS, {**base_mocks, **mocks})
n += write_app("paper-toy-co", base, FORMULAS, base_mocks)
for folder, fn, frm in (("cosmo-kits", standalone.cosmo, None), ("toys-that-made-us", standalone.story, standalone.story_formulas()),
                        ("spark-cube", standalone.spark, None)):
    ys, mk = build_standalone(fn)
    n += write_app(folder, ys, frm, mk)
shutil.rmtree(TMP)
print(f"Wrote {n} screen files in 5 app folders to {OUT}" + ("" if yaml else " (install pyyaml to validate)"))
