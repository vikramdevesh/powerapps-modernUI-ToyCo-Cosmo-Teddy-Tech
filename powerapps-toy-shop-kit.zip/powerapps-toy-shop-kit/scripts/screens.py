# Builds the three Power Apps screens as paste-able YAML, plus an HTML mock of each screen for a visual check.
import sys, os, urllib.parse
OUT = sys.argv[1]
sys.argv = ['gen', OUT]
import gen
from gen import mat, tent, card, detail, row, strip, flag, net, ruler, ART_HEAD, robot, critter, vehicle, blocks, TOYS

LBL, BTN, IMG, RECT, GAL, TXT = "Label@2.5.1", "Classic/Button@2.2.0", "Image@2.2.3", "Rectangle@2.3.0", "Gallery@2.15.0", "Classic/TextInput@2.3.2"
INK, CARD, MATTXT = "22252d", "f5f0e4", "d6e8b4"
HEX = {"Blue": "2f6db3", "Orange": "ee6b2d", "Red": "d83a2e", "Yellow": "f4b630", "Green": "2e9a57", "Teal": "279c8e", "Gray": "9b917c"}

def S(parts, **sub):
    s = "".join(parts)
    for k, v in sub.items(): s = s.replace(k, v)
    return s
def art(t):
    body = {"Robot": robot, "Critter": critter, "Vehicle": vehicle, "Blocks": blocks}[t[2]]
    return (ART_HEAD + "".join(body)).replace("HEXA", t[4]).replace("HEXB", t[5])
PV = {"MatBg": S(mat), "RulerArt": S(ruler), "NetArt": S(net),
      "FlagRed": S(flag, HDR="d83a2e", MARK="M-13 -13L13 13M13 -13L-13 13"), "FlagGreen": S(flag, HDR="2e9a57", MARK="M-15 1L-5 11L15 -11")}
for n, c in HEX.items():
    PV["Tent" + n] = S(tent, HDR=c); PV["Strip" + n] = S(strip, HDR=c)
TOY = {t[0]: t for t in TOYS}

# ---------------- control model ----------------
class C:
    def __init__(s, name, typ, geo, props, pv=None, children=None, variant=None):
        s.name, s.typ, s.geo, s.props, s.pv, s.children, s.variant = name, typ, geo, props, pv or {}, children, variant

def g(v):  # geometry value -> (formula, preview number)
    return v if isinstance(v, tuple) else (str(v), v)
def col(h): return f'ColorValue("#{h}")'
FONT = {"lato": "Font.'Lato Black'", "mono": "Font.'Courier New'", "segoe": "Font.'Segoe UI'"}

def lbl(name, geo, text, pvtext, size, font="lato", color=INK, align="Center", valign="Middle", visible=None, pvhide=False, fill=None, wrap=False, color_fx=None, pvcolor=None):
    p = {"Text": text, "Font": FONT[font], "FontWeight": "FontWeight.Bold" if font == "mono" else ("FontWeight.Semibold" if font == "segoe" else "FontWeight.Normal"),
         "Size": str(size), "Color": color_fx or col(color), "Align": f"Align.{align}", "VerticalAlign": f"VerticalAlign.{valign}",
         "PaddingLeft": "0", "PaddingRight": "0", "PaddingTop": "0", "PaddingBottom": "0"}
    if not wrap: p["Wrap"] = "false"
    if fill: p["Fill"] = col(fill)
    if visible: p["Visible"] = visible
    return C(name, LBL, geo, p, {"kind": "lbl", "text": pvtext, "size": size, "font": font, "color": pvcolor or color, "align": align, "valign": valign, "hide": pvhide, "fill": fill, "wrap": wrap})

def img(name, geo, fx, pvsvg, pos="Fit", visible=None, pvhide=False):
    p = {"Image": fx, "ImagePosition": f"ImagePosition.{pos}", "BorderThickness": "0"}
    if visible: p["Visible"] = visible
    return C(name, IMG, geo, p, {"kind": "img", "svg": pvsvg, "pos": pos, "hide": pvhide})

def hit(name, geo, onselect, tip):
    return C(name, BTN, geo, {"Text": '""', "Fill": "RGBA(0, 0, 0, 0)", "HoverFill": "RGBA(255, 248, 230, 0.14)", "PressedFill": "RGBA(0, 0, 0, 0.10)",
             "BorderThickness": "0", "FocusedBorderThickness": "2", "FocusedBorderColor": col("fffaf0"), "RadiusTopLeft": "6", "RadiusTopRight": "6",
             "RadiusBottomLeft": "6", "RadiusBottomRight": "6", "Tooltip": f'"{tip}"', "OnSelect": onselect}, {"kind": "none"})

def rect(name, geo, fill_fx, pvfill, visible=None, extra=None, pvhide=False, pvborder=None):
    p = {"Fill": fill_fx}
    if visible: p["Visible"] = visible
    if extra: p.update(extra)
    return C(name, RECT, geo, p, {"kind": "rect", "fill": pvfill, "hide": pvhide, "border": pvborder})

def btn(name, geo, text, pvtext, fill_fx, pvfill, onselect, size=18, color_fx=None, pvcolor="#fff", extra=None):
    p = {"Text": text, "Fill": fill_fx, "Color": color_fx or col("ffffff"), "HoverFill": "ColorFade(Self.Fill, -0.12)", "PressedFill": "ColorFade(Self.Fill, -0.25)",
         "BorderThickness": "0", "Font": FONT["lato"], "FontWeight": "FontWeight.Normal", "Size": str(size),
         "RadiusTopLeft": "6", "RadiusTopRight": "6", "RadiusBottomLeft": "6", "RadiusBottomRight": "6", "OnSelect": onselect}
    if extra: p.update(extra)
    return C(name, BTN, geo, p, {"kind": "btn", "text": pvtext, "fill": pvfill, "color": pvcolor, "size": size})

def tent_label(prefix, x, y, w, h, colour, hdr_text, pvhdr, body_fx, pvbody, body_size, onselect=None, tip="", hdr_ink=False, body_font="lato", img_fx=None, pvimg=None, geo_y=None):
    """A printed tent card: image + header strip text + body text (+ optional hit button)."""
    yy = geo_y or (str(y), y)
    def gy(off):
        return (f"{yy[0]} + {off}" if geo_y else str(y + off), y + off) if geo_y else y + off
    out = [img(prefix + "Tent", (x, yy if geo_y else y, w, h), img_fx or "Tent" + colour, pvimg or PV["Tent" + colour], "Stretch")]
    hs, he = h * 18 / 200, h * 44 / 200
    if hdr_text and he - hs >= 12:
        out.append(lbl(prefix + "Hdr", (x + 12, gy(round(hs)), w - 24, round(he - hs)), hdr_text, pvhdr, max(9, min(15, round((he - hs) * 0.62))), "mono", INK if hdr_ink else "ffffff"))
    out.append(lbl(prefix + "Txt", (x + 10, gy(round(he + 2)), w - 20, round(h * 174 / 200 - he - 4)), body_fx, pvbody, body_size, body_font))
    if onselect: out.append(hit(prefix + "Btn", (x, yy if geo_y else y, w, h), onselect, tip))
    return out

ADD = lambda X: (f"If(\n    IsBlank(LookUp(colCart, Id = {X}.Id)),\n"
                 f"    Collect(colCart, {{Id: {X}.Id, Name: {X}.Name, Part: {X}.Part, HexA: {X}.HexA, Art: {X}.Art, Price: {X}.Price, Qty: 1}}),\n"
                 f"    Patch(colCart, LookUp(colCart, Id = {X}.Id), {{Qty: LookUp(colCart, Id = {X}.Id).Qty + 1}})\n);\nSet(gOrdered, false)")
LIGHTS = '(HEXVAL = "f4b630" || HEXVAL = "e6e1d6")'
def ink_or_white(hexfx): return f'If({LIGHTS.replace("HEXVAL", hexfx)}, {col(INK)}, {col("ffffff")})'

def cart_tent(prefix):
    return tent_label(prefix, 1176, 12, 170, 90, "Yellow", '"KIT BOX"', "KIT BOX", 'Sum(colCart, Qty) & " in box"', "3 in box", 24,
                      "Navigate(CartScreen, ScreenTransition.Cover)", "Open your kit box", hdr_ink=True)

# ================= HOME =================
home = [img("HomeMat", (0, 0, ("Parent.Width", 1366), ("Parent.Height", 768)), "MatBg", PV["MatBg"], "Fill"),
        img("HomeRuler", (40, 676, 720, 70), "RulerArt", PV["RulerArt"]),
        img("HomeNet", (1090, 596, 220, 160), "NetArt", PV["NetArt"]),
        img("HomeCar", (760, 390, 300, 300), "LookUp(Toys, Id = 7).Art", art(TOY[7])),
        img("HomeBear", (1080, 330, 270, 270), "LookUp(Toys, Id = 4).Art", art(TOY[4])),
        img("HomeBlocks", (1150, 112, 190, 190), "LookUp(Toys, Id = 10).Art", art(TOY[10])),
        img("HomeRobot", (820, 60, 360, 360), "LookUp(Toys, Id = 1).Art", art(TOY[1]))]
home += tent_label("HomeNew", 806, 176, 124, 70, "Red", '"TAG"', "TAG", '"NEW!"', "NEW!", 24)
home += [img("HomeTitleTent", (50, 56, 680, 290), "TentBlue", PV["TentBlue"], "Stretch"),
         lbl("HomeKit", (90, 84, 600, 34), '"KIT No.07  ·  CUT  ·  FOLD  ·  PLAY"', "KIT No.07  ·  CUT  ·  FOLD  ·  PLAY", 15, "mono", "ffffff"),
         lbl("HomeTitle", (80, 128, 620, 92), '"Paper Toy Co."', "Paper Toy Co.", 64),
         lbl("HomeSub", (80, 220, 620, 40), '"Cut-out kits that fold into real toys"', "Cut-out kits that fold into real toys", 22, "segoe", "4a4d56"),
         rect("HomeUnderline", (290, 268, 200, 5), col(HEX["Orange"]), "#" + HEX["Orange"]),
         lbl("HomePartNo", (70, 284, 80, 20), '"T1"', "T1", 12, "mono", "8c7f6a", "Left"),
         lbl("HomePick", (60, 362, 500, 28), '"PICK A KIT BOX  ↓"', "PICK A KIT BOX  ↓", 16, "mono", MATTXT, "Left")]
for i, (cat, colour, box) in enumerate([("Robots", "Blue", "A"), ("Critters", "Orange", "B"), ("Vehicles", "Red", "C"), ("Blocks", "Teal", "D")]):
    x, y = 54 + i * 174, 398
    n = sum(1 for t in TOYS if t[3] == cat)
    home += [img(f"Home{cat}Tent", (x, y, 160, 106), "Tent" + colour, PV["Tent" + colour], "Stretch"),
             lbl(f"Home{cat}Hdr", (x + 12, y + 10, 136, 13), f'"BOX {box}"', f"BOX {box}", 10, "mono", "ffffff"),
             lbl(f"Home{cat}Name", (x + 8, y + 30, 144, 40), f'"{cat}"', cat, 24),
             lbl(f"Home{cat}Count", (x + 8, y + 68, 144, 22), f'CountRows(Filter(Toys, Cat = "{cat}")) & " kits"', f"{n} kits", 14, "segoe", "5a5d66"),
             hit(f"Home{cat}Btn", (x, y, 160, 106), f'Set(gCat, "{cat}");\nNavigate(CatalogScreen, ScreenTransition.Cover)', f"Browse {cat}")]
home += [img("HomeStrip", (54, 548, 300, 60), "StripOrange", PV["StripOrange"], "Stretch")]
home += tent_label("HomeCta", 366, 520, 368, 116, "Green", '"START HERE"', "START HERE", '"Open the kit shelf  →"', "Open the kit shelf  →", 26,
                   'Set(gCat, "All");\nNavigate(CatalogScreen, ScreenTransition.Cover)', "Open the kit shelf")
home += cart_tent("HomeCart")

# ================= CATALOG =================
cat_s = [img("CatMat", (0, 0, ("Parent.Width", 1366), ("Parent.Height", 768)), "MatBg", PV["MatBg"], "Fill")]
cat_s += tent_label("CatBack", 20, 14, 190, 84, "Gray", '"BACK"', "BACK", '"← Workbench"', "← Workbench", 20, "Navigate(HomeScreen, ScreenTransition.UnCover)", "Back to the workbench")
cat_s += tent_label("CatTitle", 222, 8, 420, 96, "Blue", '"SHELF 02  ·  " & If(gCat = "All", "ALL KITS", Upper(gCat))', "SHELF 02  ·  ALL KITS", '"The Kit Shelf"', "The Kit Shelf", 34)
cat_s += [rect("CatSearchShadow", (666, 40, 290, 50), "RGBA(4, 20, 10, 0.45)", "rgba(4,20,10,.45)"),
          C("CatSearch", TXT, (660, 32, 290, 50), {"Default": '""', "HintText": '"Search kits…"', "Fill": col(CARD), "Color": col(INK),
            "BorderColor": "RGBA(60, 45, 30, 0.55)", "BorderStyle": "BorderStyle.Dashed", "BorderThickness": "2", "FocusedBorderThickness": "2",
            "Font": FONT["segoe"], "Size": "18", "PaddingLeft": "14", "RadiusTopLeft": "4", "RadiusTopRight": "4", "RadiusBottomLeft": "4", "RadiusBottomRight": "4"},
            {"kind": "txt", "text": "Search kits…"})]
cat_s += cart_tent("CatCart")
for i, (cat, colour) in enumerate([("All", "Orange"), ("Robots", "Blue"), ("Critters", "Orange"), ("Vehicles", "Red"), ("Blocks", "Teal")]):
    x = 20 + i * 166; sel = cat == "All"; name = "All kits" if cat == "All" else cat
    yfx = (f'If(gCat = "{cat}", 108, 118)', 108 if sel else 118)
    ly = (f'If(gCat = "{cat}", 130, 140)', 130 if sel else 140)
    cat_s += [img(f"CatF{cat}Tent", (x, yfx, 158, 74), f'If(gCat = "{cat}", Tent{colour}, TentGray)', PV["Tent" + (colour if sel else "Gray")], "Stretch"),
              lbl(f"CatF{cat}Txt", (x + 6, ly, 146, 36), f'"{name}"', name, 20, color_fx=f'If(gCat = "{cat}", {col(INK)}, {col("7a7264")})', pvcolor=INK if sel else "7a7264"),
              hit(f"CatF{cat}Btn", (x, yfx, 158, 74), f'Set(gCat, "{cat}")', f"Show {name}")]

TW, TH = 285, 282
def kit_item(t):
    TWf = lambda d: (f"Parent.TemplateWidth - {d}", TW - d)
    light = t[4] in ("f4b630", "e6e1d6")
    return [
        img("KitCard", (0, 0, ("Parent.TemplateWidth", TW), ("Parent.TemplateHeight", TH)), 'SvgUri & EncodeUrl(Substitute(CardTpl, "HDR", ThisItem.HexA))', S(card, HDR=t[4]), "Stretch"),
        rect("KitSelected", (20, 40, TWf(40), (f"Parent.TemplateHeight - 56", TH - 56)), "RGBA(0, 0, 0, 0)", "transparent", "ThisItem.Id = gSel.Id",
             {"BorderColor": col(HEX["Orange"]), "BorderStyle": "BorderStyle.Dashed", "BorderThickness": "3"}, pvhide=t[0] != 1, pvborder="#ee6b2d"),
        lbl("KitStrip", (22, 9, TWf(44), 24), 'ThisItem.Part & "  ·  " & Upper(ThisItem.Cat) & "  ·  AGE " & ThisItem.Age', f"{t[8]}  ·  {t[3].upper()}  ·  AGE {t[7]}",
            12, "mono", align="Left", color_fx=ink_or_white("ThisItem.HexA"), pvcolor=INK if light else "ffffff"),
        img("KitArt", (18, 40, 150, 150), "ThisItem.Art", art(t)),
        lbl("KitName", (166, 46, TWf(186), 62), "ThisItem.Name", t[1], 18, align="Left", valign="Top", wrap=True),
        lbl("KitMeta", (166, 110, TWf(186), 22), 'ThisItem.Pieces & " pieces  " & Rept("★", ThisItem.Rating)', f"{t[9]} pieces  " + "★" * t[10], 13, "segoe", "5a5d66", "Left"),
        img("KitPriceTent", (162, 134, 108, 60), "TentYellow", PV["TentYellow"], "Stretch"),
        lbl("KitPrice", (166, 148, 100, 40), '"₹" & Text(ThisItem.Price, "#,##0")', f"₹{t[6]:,}", 20),
        hit("KitSelect", (0, 0, ("Parent.TemplateWidth", TW), 196), "Set(gSel, ThisItem)", "Show kit details"),
        rect("KitAddShadow", (30, 212, TWf(56), 44), "RGBA(60, 40, 20, 0.28)", "rgba(60,40,20,.28)",
             ),
        btn("KitAdd", (26, 206, TWf(56), 44), '"+  Add to kit box"', "+  Add to kit box", 'ColorValue("#" & ThisItem.HexA)', "#" + t[4],
            ADD("ThisItem") + ";\nSet(gSel, ThisItem)", 17, ink_or_white("ThisItem.HexA"), "#" + (INK if light else "ffffff")),
    ]
cat_items = [TOY[i] for i in range(1, 7)]
gal = C("CatGallery", GAL, (14, 196, 880, 566), {
    "Items": 'Filter(\n    Toys,\n    (gCat = "All" || Cat = gCat) && (IsBlank(CatSearch.Text) || CatSearch.Text in Name)\n)',
    "WrapCount": "3", "TemplateSize": str(TH), "TemplatePadding": "6", "TemplateFill": "RGBA(0, 0, 0, 0)", "Fill": "RGBA(0, 0, 0, 0)",
    "BorderThickness": "0", "ShowScrollbar": "true", "ShowNavigation": "false"},
    {"kind": "gal", "items": cat_items, "tw": TW, "th": TH, "wrap": 3, "pad": 6, "build": kit_item}, kit_item(TOY[1]), "Vertical")
cat_s.append(gal)
sel = TOY[1]
cat_s += [img("CatSheet", (906, 112, 446, 650), 'SvgUri & EncodeUrl(Substitute(SheetTpl, "HDR", gSel.HexA))', S(detail, HDR=sel[4]), "Stretch"),
          lbl("CatDetHdr", (936, 122, 386, 36), '"PART " & gSel.Part & "  ·  " & Upper(gSel.Cat) & " KIT  ·  " & gSel.Pieces & " PIECES"',
              f"PART {sel[8]}  ·  {sel[3].upper()} KIT  ·  {sel[9]} PIECES", 14, "mono", align="Left", color_fx=ink_or_white("gSel.HexA"), pvcolor="ffffff"),
          img("CatDetArt", (962, 168, 334, 270), "gSel.Art", art(sel))]
cat_s += tent_label("CatAge", 1226, 172, 100, 62, "Red", '"AGE"', "AGE", 'gSel.Age', sel[7], 22)
cat_s += [lbl("CatDetName", (940, 452, 380, 48), "gSel.Name", sel[1], 32, align="Left"),
          lbl("CatDetMeta", (940, 500, 380, 24), 'Rept("★", gSel.Rating) & Rept("☆", 5 - gSel.Rating) & "   ·   " & gSel.Pieces & " printed pieces"',
              "★" * sel[10] + "☆" * (5 - sel[10]) + f"   ·   {sel[9]} printed pieces", 15, "segoe", "5a5d66", "Left"),
          lbl("CatDetBlurb", (940, 528, 380, 70), "gSel.Blurb", sel[11], 16, "segoe", "3a3d46", "Left", "Top", wrap=True),
          lbl("CatDetPrice", (940, 604, 180, 64), '"₹" & Text(gSel.Price, "#,##0")', f"₹{sel[6]:,}", 40, align="Left"),
          rect("CatDetAddShadow", (1134, 618, 186, 54), "RGBA(60, 40, 20, 0.28)", "rgba(60,40,20,.28)",
               ),
          btn("CatDetAdd", (1128, 612, 186, 54), '"Add to box  +"', "Add to box  +", 'ColorValue("#" & Coalesce(gSel.HexA, "2f6db3"))', "#" + sel[4], ADD("gSel"), 20,
              ink_or_white("gSel.HexA"), "#fff"),
          lbl("CatDetInBox", (940, 676, 380, 26), '"IN YOUR KIT BOX: " & Coalesce(LookUp(colCart, Id = gSel.Id).Qty, 0)', "IN YOUR KIT BOX: 1", 13, "mono", HEX["Green"], "Left")]

# ================= CART =================
cart_items = [(TOY[1], 1), (TOY[4], 2), (TOY[8], 1)]
sub = sum(t[6] * q for t, q in cart_items)
SUB = "Sum(colCart, Price * Qty)"
cart = [img("CartMat", (0, 0, ("Parent.Width", 1366), ("Parent.Height", 768)), "MatBg", PV["MatBg"], "Fill")]
cart += tent_label("CartBack", 20, 14, 220, 84, "Gray", '"BACK"', "BACK", '"← Keep shopping"', "← Keep shopping", 19, "Navigate(CatalogScreen, ScreenTransition.UnCover)", "Back to the kit shelf")
cart += tent_label("CartTitle", 252, 8, 440, 96, "Green", '"ORDER SHEET  ·  No. 0042"', "ORDER SHEET  ·  No. 0042", '"Your Kit Box"', "Your Kit Box", 34)
cart += tent_label("CartCount", 704, 14, 150, 84, "Yellow", '"KITS"', "KITS", 'Sum(colCart, Qty) & " kits"', f"{sum(q for _, q in cart_items)} kits", 24, hdr_ink=True)
RW, RH = 808, 132
def row_item(tq):
    t, q = tq
    return [
        img("RowCard", (0, 0, ("Parent.TemplateWidth", RW), ("Parent.TemplateHeight", RH)), 'SvgUri & EncodeUrl(Substitute(RowTpl, "HDR", ThisItem.HexA))', S(row, HDR=t[4]), "Stretch"),
        img("RowArt", (40, 10, 112, 112), "ThisItem.Art", art(t)),
        lbl("RowName", (160, 24, 300, 40), "ThisItem.Name", t[1], 24, align="Left"),
        lbl("RowPart", (160, 64, 300, 24), '"PART " & ThisItem.Part & "  ·  ₹" & Text(ThisItem.Price, "#,##0") & " each"', f"PART {t[8]}  ·  ₹{t[6]:,} each", 13, "mono", "5a5d66", "Left"),
        btn("RowMinus", (470, 42, 48, 48), '"–"', "–", col("e8e0cf"), "#e8e0cf",
            "If(\n    ThisItem.Qty <= 1,\n    Remove(colCart, ThisItem),\n    Patch(colCart, ThisItem, {Qty: ThisItem.Qty - 1})\n)", 26, col(INK), "#" + INK,
            {"BorderThickness": "1", "BorderColor": "RGBA(60, 45, 30, 0.5)", "BorderStyle": "BorderStyle.Dashed", "Tooltip": '"One less"'}),
        lbl("RowQty", (522, 42, 60, 48), "ThisItem.Qty", str(q), 26, fill="ffffff"),
        btn("RowPlus", (586, 42, 48, 48), '"+"', "+", col("e8e0cf"), "#e8e0cf", "Patch(colCart, ThisItem, {Qty: ThisItem.Qty + 1})", 26, col(INK), "#" + INK,
            {"BorderThickness": "1", "BorderColor": "RGBA(60, 45, 30, 0.5)", "BorderStyle": "BorderStyle.Dashed", "Tooltip": '"One more"'}),
        lbl("RowLine", (640, 36, 140, 60), '"₹" & Text(ThisItem.Price * ThisItem.Qty, "#,##0")', f"₹{t[6]*q:,}", 24, align="Right"),
    ]
cart.append(C("CartGallery", GAL, (16, 118, 820, 640), {"Items": "colCart", "WrapCount": "1", "TemplateSize": str(RH), "TemplatePadding": "6",
              "TemplateFill": "RGBA(0, 0, 0, 0)", "Fill": "RGBA(0, 0, 0, 0)", "BorderThickness": "0", "ShowScrollbar": "true", "ShowNavigation": "false"},
              {"kind": "gal", "items": cart_items, "tw": RW, "th": RH, "wrap": 1, "pad": 6, "build": row_item}, row_item(cart_items[0]), "Vertical"))
cart += [img("CartNet", (200, 210, 420, 300), "NetArt", PV["NetArt"], visible="IsEmpty(colCart)", pvhide=True),
         lbl("CartEmpty", (40, 520, 760, 90), 'If(gOrdered, "All packed! Fold another kit?", "Your kit box is empty. Pick a kit from the shelf.")', "", 26, color=CARD, visible="IsEmpty(colCart)", pvhide=True),
         img("CartStrip", (836, 370, 72, 44), "StripGreen", PV["StripGreen"], "Stretch", visible="!IsEmpty(colCart)"),
         img("CartSheet", (900, 112, 446, 650), 'SvgUri & EncodeUrl(Substitute(SheetTpl, "HDR", "2e9a57"))', S(detail, HDR="2e9a57"), "Stretch"),
         lbl("CartRcHdr", (930, 122, 390, 36), '"RECEIPT  ·  CUT ALONG THE DOTTED LINE"', "RECEIPT  ·  CUT ALONG THE DOTTED LINE", 13, "mono", "ffffff", "Left")]
lines = [("Kits in box", "Sum(colCart, Qty)", str(sum(q for _, q in cart_items))),
         ("Subtotal", f'"₹" & Text({SUB}, "#,##0")', f"₹{sub:,}"),
         ("Shipping", f'If({SUB} >= 1499 || IsEmpty(colCart), "FREE", "₹99")', "FREE"),
         ("Gift wrap (paper, obviously)", '"FREE"', "FREE")]
for i, (k, v, pv) in enumerate(lines):
    y = 176 + i * 36
    cart += [lbl(f"CartK{i}", (936, y, 270, 32), f'"{k}"', k, 17, "segoe", "3a3d46", "Left"),
             lbl(f"CartV{i}", (1196, y, 120, 32), v, pv, 20, align="Right")]
TOTAL = f'If(gOrdered && IsEmpty(colCart), gOrderTotal, {SUB} + If({SUB} >= 1499 || IsEmpty(colCart), 0, 99))'
cart += [rect("CartRule", (936, 326, 380, 2), "RGBA(34, 37, 45, 0.35)", "rgba(34,37,45,.35)"),
         lbl("CartTotK", (936, 336, 200, 24), '"TOTAL"', "TOTAL", 15, "mono", align="Left"),
         lbl("CartTotV", (936, 358, 270, 80), f'"₹" & Text({TOTAL}, "#,##0")', f"₹{sub:,}", 60, align="Left"),
         img("CartFlag", (1212, 296, 110, 140), "If(gOrdered, FlagGreen, FlagRed)", PV["FlagRed"], visible="IsEmpty(colCart)", pvhide=True)]
STAT_C = '(If(gOrdered && IsEmpty(colCart), TentGreen, IsEmpty(colCart), TentRed, TentYellow))'
cart += tent_label("CartStatus", 936, 456, 380, 92, "Yellow", '"STATUS"', "STATUS",
                   'If(gOrdered && IsEmpty(colCart), "Order #0042 folded & packed!", IsEmpty(colCart), "Nothing to pack yet", "Ready to fold & ship")',
                   "Ready to fold & ship", 22, hdr_ink=False, img_fx=STAT_C[1:-1])
cart += [rect("CartPlaceShadow", (946, 574, 380, 68), "RGBA(4, 20, 10, 0.35)", "rgba(60,40,20,.28)",
              ),
         btn("CartPlace", (940, 566, 380, 68), '"Place order  ✓"', "Place order  ✓", col(HEX["Green"]), "#" + HEX["Green"],
             f"Set(gOrderTotal, {SUB} + If({SUB} >= 1499, 0, 99));\nSet(gOrdered, true);\nClear(colCart)", 26,
             extra={"DisplayMode": "If(IsEmpty(colCart), DisplayMode.Disabled, DisplayMode.Edit)", "DisabledFill": col("9b917c"), "DisabledColor": col("e8e0cf"),
                    "RadiusTopLeft": "8", "RadiusTopRight": "8", "RadiusBottomLeft": "8", "RadiusBottomRight": "8"}),
         lbl("CartFine", (940, 652, 380, 56), '"Free shipping on kit boxes over ₹1,499" & Char(10) & "Scissors and glue not included"',
             "Free shipping on kit boxes over ₹1,499\nScissors and glue not included", 12, "mono", "6b6458", "Left", "Top", wrap=True)]

SCREENS = [("HomeScreen", home, 'If(IsBlank(gCat), Set(gCat, "All"))'),
           ("CatalogScreen", cat_s, 'If(IsBlank(gCat), Set(gCat, "All"));\nIf(IsBlank(gSel), Set(gSel, First(Toys)))'),
           ("CartScreen", cart, "")]

# ---------------- YAML ----------------
def yval(fx, ind):
    s = "=" + fx
    if "\n" in s or ": " in s or " #" in s or "#" in s or s.endswith(":"):
        return "|-\n" + "\n".join(" " * ind + l for l in s.split("\n"))
    return s
def emit(c, ind):
    o = [" " * ind + f"- {c.name}:", " " * (ind + 4) + f"Control: {c.typ}"]
    if c.variant: o.append(" " * (ind + 4) + f"Variant: {c.variant}")
    o.append(" " * (ind + 4) + "Properties:")
    props = dict(c.props)
    for k, v in zip(("X", "Y", "Width", "Height"), c.geo): props[k] = g(v)[0]
    for k, v in props.items(): o.append(" " * (ind + 6) + f"{k}: " + yval(v, ind + 8))
    if c.children:
        o.append(" " * (ind + 4) + "Children:")
        for ch in c.children: o += emit(ch, ind + 6)
    return o
for name, ctrls, onvis in SCREENS:
    o = ["Screens:", f"  {name}:", "    Properties:", '      Fill: =ColorValue("#2a1a0e")']
    if onvis: o.append("      OnVisible: " + yval(onvis, 8))
    o.append("    Children:")
    for c in ctrls: o += emit(c, 6)
    open(os.path.join(OUT, f"{name}.pa.yaml"), "w").write("\n".join(o) + "\n")

# ---------------- HTML mock ----------------
FF = {"lato": "'Lato',Arial Black,sans-serif;font-weight:900", "mono": "'Courier New',monospace;font-weight:700", "segoe": "'Segoe UI',Arial,sans-serif;font-weight:600"}
def uri(s): return "data:image/svg+xml;utf8," + urllib.parse.quote(s)
def html_ctrl(c, ox=0, oy=0):
    pv = c.pv
    if pv.get("hide") or pv.get("kind") == "none": return ""
    x, y, w, h = (g(v)[1] for v in c.geo)
    x += ox; y += oy
    st = f"position:absolute;left:{x}px;top:{y}px;width:{w}px;height:{h}px;"
    k = pv["kind"]
    if k == "img":
        fit = {"Fill": "cover", "Fit": "contain", "Stretch": "fill"}[pv["pos"]]
        return f"<img style='{st}object-fit:{fit}' src='{uri(pv['svg'])}'>"
    if k == "rect":
        b = f"border:3px dashed {pv['border']};box-sizing:border-box;" if pv.get("border") else ""
        return f"<div style='{st}background:{pv['fill']};{b}border-radius:4px'></div>"
    if k == "lbl":
        ja = {"Left": "flex-start", "Center": "center", "Right": "flex-end"}[pv["align"]]
        va = {"Middle": "center", "Top": "flex-start"}[pv["valign"]]
        bg = f"background:#{pv['fill']};" if pv.get("fill") else ""
        ws = "pre-wrap" if pv["wrap"] else "pre"
        return (f"<div style='{st}{bg}display:flex;align-items:{va};justify-content:{ja};text-align:{pv['align'].lower()};color:#{pv['color']};"
                f"font-size:{pv['size']*1.333:.0f}px;font-family:{FF[pv['font']]};white-space:{ws};overflow:hidden;line-height:1.15'>{pv['text']}</div>")
    if k == "btn":
        return (f"<div style='{st}background:{pv['fill']};color:{pv['color']};border-radius:6px;display:flex;align-items:center;justify-content:center;"
                f"font-size:{pv['size']*1.333:.0f}px;font-family:{FF['lato']}'>{pv['text']}</div>")
    if k == "txt":
        return (f"<div style='{st}background:#f5f0e4;border:2px dashed rgba(60,45,30,.55);box-sizing:border-box;border-radius:4px;padding-left:14px;display:flex;"
                f"align-items:center;color:#8a8478;font:600 24px Segoe UI,Arial'>{pv['text']}</div>")
    if k == "gal":
        out = f"<div style='{st}overflow:hidden'>"
        for i, it in enumerate(pv["items"]):
            gx = pv["pad"] + (i % pv["wrap"]) * (pv["tw"] + pv["pad"]); gy = pv["pad"] + (i // pv["wrap"]) * (pv["th"] + pv["pad"])
            out += f"<div style='position:absolute;left:{gx}px;top:{gy}px;width:{pv['tw']}px;height:{pv['th']}px'>" + "".join(html_ctrl(ch) for ch in pv["build"](it)) + "</div>"
        return out + "</div>"
    return ""
for name, ctrls, _ in SCREENS:
    body = "".join(html_ctrl(c) for c in ctrls)
    open(os.path.join(OUT, f"mock_{name}.html"), "w").write(
        "<html><head><link href='https://fonts.googleapis.com/css2?family=Lato:wght@900&display=block' rel='stylesheet'></head>"
        f"<body style='margin:0'><div style='position:relative;width:1366px;height:768px;overflow:hidden;background:#2a1a0e'>{body}</div></body></html>")
print("yaml ok")
