# Product Launch Reveal style: "Spark Cube" keynote launch - 2 screens
import math, random
from kit import *

SANS = "Inter, Segoe UI, Helvetica Neue, Arial, sans-serif"
GV = ["#b69cff", "#e879f9", "#ff9a4d"]
U = [0]
def uid(p): U[0] += 1; return f"{p}{U[0]}"
def SVG(vb, body, par="xMidYMid meet"): return f"<svg xmlns='http://www.w3.org/2000/svg' viewBox='{vb}' preserveAspectRatio='{par}'>{body}</svg>"
def lin(i, x1, y1, x2, y2, stops, units="userSpaceOnUse"):
    return f"<linearGradient id='{i}' gradientUnits='{units}' x1='{f1(x1)}' y1='{f1(y1)}' x2='{f1(x2)}' y2='{f1(y2)}'>" + "".join(f"<stop offset='{o}' stop-color='{c}' stop-opacity='{a}'/>" for o, c, a in stops) + "</linearGradient>"

def cam(cx, cy, s, yaw, pitch):
    cyw, syw, cp, sp, D = math.cos(yaw), math.sin(yaw), math.cos(pitch), math.sin(pitch), 7
    F = s * 1900
    def P(x, y, z):
        X, Z = x * cyw - z * syw, x * syw + z * cyw; up, dep = y * cp - Z * sp, Z * cp + y * sp; k = F / (D - dep)
        return (cx + X * k, cy - up * k, dep)
    def N(nx, nz): return (nx * cyw - nz * syw, nx * syw + nz * cyw)
    return P, N, F / D
def rr(a, r, seg):
    pts = []; cs = [(a - r, a - r), (-(a - r), a - r), (-(a - r), -(a - r)), (a - r, -(a - r))]
    for k, (cx, cz) in enumerate(cs):
        for i in range(seg + 1):
            an = k * math.pi / 2 + i / seg * math.pi / 2; pts.append((cx + r * math.cos(an), cz + r * math.sin(an), an))
    return pts
OUT, DIE = rr(1, .27, 7), rr(.66, .12, 4)
BOLT = {(4, 0), (3, 1), (4, 1), (2, 2), (3, 2), (2, 3), (3, 3), (4, 3), (5, 3), (4, 4), (5, 4), (3, 5), (4, 5), (3, 6), (2, 7)}

FIN = {"Graphite": (0.96, 0.98, 1.05), "Silver": (1.35, 1.36, 1.4), "Violet": (1.05, 0.85, 1.55)}
def slab(cx, cy, s, yaw, pitch, white=False, finish="Graphite", hover=0.3, ring=True):
    """returns svg body for the hero object (floor shadow, reflection, side walls, glass top, LED die, glow ring)"""
    P, N, unit = cam(cx, cy, s, yaw, pitch); TH = .12; yT, yB = hover + TH / 2, hover - TH / 2; tint = FIN[finish]
    top = [P(p[0], yT, p[1]) for p in OUT]; bot = [P(p[0], yB, p[1]) for p in OUT]
    b = ""
    # contact shadow + coloured spill
    gi = uid("sh")
    b += (f"<radialGradient id='{gi}'><stop offset='0' stop-color='#000' stop-opacity='{.32 if white else .75}'/><stop offset='.6' stop-color='#000' stop-opacity='{.1 if white else .3}'/>"
          f"<stop offset='1' stop-color='#000' stop-opacity='0'/></radialGradient><ellipse cx='{f1(cx)}' cy='{f1(cy)}' rx='{f1(unit*1.45)}' ry='{f1(unit*1.45*max(.18, math.sin(pitch)*.8))}' fill='url(#{gi})'/>")
    if ring and not white:
        gi = uid("sp"); b += (f"<radialGradient id='{gi}'><stop offset='0' stop-color='#aa6eff' stop-opacity='.2'/><stop offset='.5' stop-color='#ff825a' stop-opacity='.06'/><stop offset='1' stop-color='#000' stop-opacity='0'/></radialGradient>"
                              f"<ellipse cx='{f1(cx)}' cy='{f1(cy)}' rx='{f1(unit*1.9)}' ry='{f1(unit*1.9*max(.18, math.sin(pitch)*.8))}' fill='url(#{gi})' style='mix-blend-mode:screen'/>")
    def walls(mirror):
        o = ""
        tp = [P(p[0], -yT if mirror else yT, p[1]) for p in OUT]; bt = [P(p[0], -yB if mirror else yB, p[1]) for p in OUT]
        n = len(OUT)
        for i in range(n):
            j = (i + 1) % n; a1, a2 = OUT[i][2], OUT[j][2]
            nx, nz = math.cos(a1) + math.cos(a2), math.sin(a1) + math.sin(a2); l = math.hypot(nx, nz) or 1; NX, NZ = N(nx / l, nz / l)
            if NZ < -0.03: continue
            lam = max(0, NX * -.6 + NZ * .8); sd = max(0, NX * -.25 + NZ * .97); spec = sd ** 18; sheen = sd ** 4; rim = max(0, NX) ** 3
            v = 14 + lam * 62 + min(1, spec * .85 + sheen * .3) * 140 + rim * 120 + (40 if white else 0)
            if mirror: v *= .9
            cc = lambda m: f"rgb({min(255, int(v*tint[0]*m))},{min(255, int(v*tint[1]*m))},{min(255, int(v*tint[2]*m+3))})"
            tm = ((tp[i][0] + tp[j][0]) / 2, (tp[i][1] + tp[j][1]) / 2); bm = ((bt[i][0] + bt[j][0]) / 2, (bt[i][1] + bt[j][1]) / 2)
            gid = uid("w")
            stops = [(0, cc(.5), 1), (.45, cc(1), 1), (1, cc(1.2), 1)] if mirror else [(0, cc(1.32), 1), (.3, cc(1.05), 1), (.52, cc(.62), 1), (.74, cc(.82), 1), (1, cc(.42), 1)]
            o += lin(gid, tm[0], tm[1], bm[0], bm[1], stops)
            o += f"<polygon points='{poly([tp[j][:2], tp[i][:2], bt[i][:2], bt[j][:2]])}' fill='url(#{gid})' stroke='url(#{gid})' stroke-width='.9'/>"
        return o, tp, bt
    # floor reflection
    mid = uid("rm"); gid = uid("rg")
    rw, _, rb = walls(True)
    b += (lin(gid, 0, cy, 0, cy + unit * .75, [(0, "#fff", 1), (1, "#fff", 0)]) + f"<mask id='{mid}'><rect x='0' y='{f1(cy)}' width='1366' height='{f1(unit*.75)}' fill='url(#{gid})'/></mask>"
          f"<g mask='url(#{mid})' opacity='{.16 if white else .3}'>{rw}<polygon points='{poly([q[:2] for q in rb])}' fill='{'#d8d8de' if white else '#060608'}'/></g>")
    ww, tp, bt = walls(False); b += ww
    b += "".join(f"<line x1='{f1(bt[i][0])}' y1='{f1(bt[i][1])}' x2='{f1(bt[(i+1)%len(bt)][0])}' y2='{f1(bt[(i+1)%len(bt)][1])}' stroke='#000' stroke-opacity='.6' stroke-width='1.2'/>" for i in range(len(bt)) if N(math.cos(OUT[i][2]), math.sin(OUT[i][2]))[1] > 0)
    # glass top
    ys = [q[1] for q in tp]; gid, cid = uid("gt"), uid("gc")
    b += lin(gid, 0, min(ys), 0, max(ys), [(0, "#2a2c33" if white else "#1d2028", 1), (1, "#08090c", 1)]) + f"<clipPath id='{cid}'><polygon points='{poly([q[:2] for q in tp])}'/></clipPath>"
    b += f"<polygon points='{poly([q[:2] for q in tp])}' fill='url(#{gid})'/><g clip-path='url(#{cid})'>"
    g2 = uid("sb"); b += lin(g2, 0, min(ys), 0, max(ys), [(0, "#fff", .16), (.35, "#fff", .035), (1, "#fff", 0)]) + f"<rect x='0' y='{f1(min(ys))}' width='1366' height='{f1(max(ys)-min(ys))}' fill='url(#{g2})'/>"
    A, Bq = P(-1.1, yT, .6), P(.6, yT, -1.1); g3 = uid("st")
    b += lin(g3, A[0], A[1], Bq[0], Bq[1], [(0, "#fff", 0), (.3, "#fff", 0), (.46, "#fff", .13), (.5, "#fff", .06), (.66, "#fff", 0), (1, "#fff", 0)]) + f"<rect x='0' y='{f1(min(ys))}' width='1366' height='{f1(max(ys)-min(ys))}' fill='url(#{g3})'/>"
    die = [P(p[0], yT, p[1])[:2] for p in DIE]
    b += f"<polygon points='{poly(die)}' fill='#04050a' fill-opacity='.92'/>"
    # LED grid (8x8), the lit cells form a lightning bolt
    lid = uid("led"); fid = uid("lf")
    b += f"<filter id='{fid}' x='-50%' y='-50%' width='200%' height='200%'><feGaussianBlur stdDeviation='{f1(unit*.025)}'/></filter>"
    leds, glowl = "", ""
    for i in range(8):
        for j in range(8):
            x, z = -.49 + i * .14, -.49 + j * .14; q = P(x, yT, z); r_ = unit * .022
            if (i, j) in BOLT:
                c = GV[0] if j < 3 else GV[1] if j < 5 else GV[2]
                leds += f"<circle cx='{f1(q[0])}' cy='{f1(q[1])}' r='{f1(r_*1.25)}' fill='{c}'/>"; glowl += f"<circle cx='{f1(q[0])}' cy='{f1(q[1])}' r='{f1(r_*3)}' fill='{c}'/>"
            else: leds += f"<circle cx='{f1(q[0])}' cy='{f1(q[1])}' r='{f1(r_)}' fill='#d7d7eb' fill-opacity='.18'/>"
    b += f"<g filter='url(#{fid})' opacity='.8'>{glowl}</g>{leds}"
    b += "</g>"
    if ring:
        g4 = uid("rgd"); bb = [q[0] for q in die]
        b += lin(g4, min(bb), 0, max(bb), 0, [(0, "#b69cff", 1), (.3, "#e879f9", 1), (.55, "#ff9a4d", 1), (.8, "#5eead4", 1), (1, "#6d7cff", 1)])
        fg = uid("rf"); b += f"<filter id='{fg}' x='-30%' y='-30%' width='160%' height='160%'><feGaussianBlur stdDeviation='{f1(unit*.035)}'/></filter>"
        b += f"<polygon points='{poly(die)}' fill='none' stroke='url(#{g4})' stroke-width='{f1(unit*.03)}' filter='url(#{fg})'/>"
        b += f"<polygon points='{poly(die)}' fill='none' stroke='url(#{g4})' stroke-width='{f1(unit*.009)}'/><polygon points='{poly(die)}' fill='none' stroke='#fff' stroke-opacity='.5' stroke-width='.8'/>"
    # top chamfer edge highlights
    n = len(OUT)
    for i in range(n):
        j = (i + 1) % n; a1, a2 = OUT[i][2], OUT[j][2]
        nx, nz = math.cos(a1) + math.cos(a2), math.sin(a1) + math.sin(a2); l = math.hypot(nx, nz) or 1; NX, NZ = N(nx / l, nz / l)
        a = min(1, max(0, -NZ) ** 1.2 * .95 + max(0, NX * -.6 + NZ * .8) * .45 + .06)
        b += f"<line x1='{f1(tp[i][0])}' y1='{f1(tp[i][1])}' x2='{f1(tp[j][0])}' y2='{f1(tp[j][1])}' stroke='#ebeeff' stroke-opacity='{a:.2f}' stroke-width='1.5'/>"
    return b, P, unit, yT

def stage_dark():
    r = random.Random(404); s = "<rect width='1366' height='768' fill='#030304'/>"
    s += ("<radialGradient id='kl' gradientUnits='userSpaceOnUse' cx='683' cy='380' r='820'><stop offset='0' stop-color='#2c2f3c' stop-opacity='.9'/><stop offset='.45' stop-color='#14151c' stop-opacity='.8'/>"
          "<stop offset='1' stop-color='#030304' stop-opacity='0'/></radialGradient><rect width='1366' height='768' fill='url(#kl)'/>"
          "<radialGradient id='fp'><stop offset='0' stop-color='#464a5c' stop-opacity='.42'/><stop offset='1' stop-color='#464a5c' stop-opacity='0'/></radialGradient>"
          "<ellipse cx='683' cy='560' rx='560' ry='134' fill='url(#fp)'/>")
    for i in range(6):
        bx, by, rad = r.uniform(0, 1366), r.uniform(.05, .5) * 768, r.uniform(40, 110); hue = r.choice(["#786eff", "#ff8c5a", "#5ac8ff"]); a = r.uniform(.03, .06)
        s += f"<radialGradient id='bk{i}'><stop offset='0' stop-color='{hue}' stop-opacity='{a:.3f}'/><stop offset='.6' stop-color='{hue}' stop-opacity='{a*.6:.3f}'/><stop offset='1' stop-color='{hue}' stop-opacity='0'/></radialGradient><circle cx='{bx:.0f}' cy='{by:.0f}' r='{rad:.0f}' fill='url(#bk{i})'/>"
    return s
def finish(white):
    s = "" if white else ("<radialGradient id='vg' cx='.5' cy='.5' r='.75'><stop offset='.4' stop-color='#000' stop-opacity='0'/><stop offset='1' stop-color='#000' stop-opacity='.55'/></radialGradient>"
                          "<rect width='1366' height='768' fill='url(#vg)'/>")
    return s + (f"<filter id='gn' x='0' y='0' width='100%' height='100%'><feTurbulence type='fractalNoise' baseFrequency='.9' numOctaves='1' seed='3'/><feColorMatrix type='saturate' values='0'/></filter>"
                f"<rect width='1366' height='768' filter='url(#gn)' opacity='{.04 if white else .06}' style='mix-blend-mode:soft-light'/>")
def callout(pts, lab, sub, side, ink="#fff"):
    (ax, ay) = pts[0]; E = pts[-1]
    s = (f"<circle cx='{f1(ax)}' cy='{f1(ay)}' r='3.6' fill='{ink}'/><circle cx='{f1(ax)}' cy='{f1(ay)}' r='11' fill='none' stroke='{ink}' stroke-opacity='.35'/>"
         f"<polyline points='{poly(pts)}' fill='none' stroke='{ink}' stroke-opacity='.7' stroke-width='1'/>")
    tx = E[0] + 14 if side == "r" else E[0] - 14; an = "start" if side == "r" else "end"
    s += f"<text x='{f1(tx)}' y='{f1(E[1]+10)}' font-family='{SANS}' font-weight='600' font-size='28' fill='{ink}' text-anchor='{an}'>{lab}</text>"
    if sub: s += f"<text x='{f1(tx)}' y='{f1(E[1]+40)}' font-family='{SANS}' font-size='21' fill='#a1a1a6' text-anchor='{an}'>{sub}</text>"
    return s
def gradtext(x, y, txt, size, w, stops, anchor="middle", glow=False, ls=0, id_="gtx", x0=None, x1=None):
    gi = uid(id_)
    s = lin(gi, x0 if x0 is not None else x - 300, 0, x1 if x1 is not None else x + 300, 0, [(i / (len(stops) - 1), c, 1) for i, c in enumerate(stops)])
    t = f"x='{f1(x)}' y='{f1(y)}' font-family='{SANS}' font-weight='{w}' font-size='{size}' text-anchor='{anchor}' letter-spacing='{ls}'"
    if glow:
        fi = uid("tg"); s += f"<filter id='{fi}' x='-20%' y='-40%' width='140%' height='180%'><feGaussianBlur stdDeviation='22'/></filter><text {t} fill='url(#{gi})' filter='url(#{fi})' opacity='.75'>{txt}</text>"
    return s + f"<text {t} fill='url(#{gi})'>{txt}</text>"

def hero_dark():
    b = stage_dark()
    body, P, unit, yT = slab(683, 560, .74, -.42, .4)
    b += body
    b += gradtext(683, 96, "Introducing", 26, 600, GV, x0=600, x1=770)
    b += f"<text x='683' y='184' font-family='{SANS}' font-weight='800' font-size='92' fill='#f5f5f7' text-anchor='middle' letter-spacing='-3'>Spark Cube.</text>"
    a1 = P(-.49, yT, -.07)[:2]; a2 = P(DIE[3][0], yT, DIE[3][1])[:2]; a3 = P(.55, yT - .14, 1.0)[:2]
    b += callout([a1, (a1[0] - 60, 300), (330, 300)], "64 RGB LEDs", "Lights up every move", "l")
    b += callout([a2, (a2[0] + 50, 290), (1040, 290)], "Edge-lit glass", "Glows violet to orange", "r")
    b += callout([a3, (a3[0] + 40, 600), (1040, 600)], "Codes with blocks", "120 puzzles built in", "r")
    b += finish(False)
    return SVG("0 0 1366 768", b, "xMidYMid slice")

def hero_white(finish_name):
    b = ("<radialGradient id='ws' gradientUnits='userSpaceOnUse' cx='310' cy='240' r='760'><stop offset='0' stop-color='#fff'/><stop offset='.55' stop-color='#f4f4f7'/><stop offset='1' stop-color='#dcdce2'/></radialGradient>"
         "")
    body, P, unit, yT = slab(310, 400, .62, .3, .36, white=True, finish=finish_name)
    return SVG("0 0 620 560", b + body)

def bg_white():
    return SVG("0 0 1366 768", "<radialGradient id='wb' gradientUnits='userSpaceOnUse' cx='420' cy='200' r='1100'><stop offset='0' stop-color='#ffffff'/><stop offset='.55' stop-color='#f4f4f7'/>"
               "<stop offset='1' stop-color='#dcdce2'/></radialGradient><rect width='1366' height='768' fill='url(#wb)'/>" + finish(True), "xMidYMid slice")

ICON = SVG("0 0 200 200", "<rect width='200' height='200' rx='40' fill='#0b0b10'/>" + slab(100, 140, .36, -.42, .45)[0].replace("1366", "200"))

def launch():
    hd = hero_dark()
    cs = [I("LaBg", (0, 0, ("Parent.Width", 1366), ("Parent.Height", 768)), svgfx(hd), hd, "Fill"),
          B("LaBack", (24, 22, 170, 40), '"‹  Workbench"', "‹  Workbench", "000000", "a1a1a6", "Navigate(HomeScreen, ScreenTransition.UnCover)", 15, "segoe", "semi",
            fill_fx="RGBA(0, 0, 0, 0)", hover_fx="RGBA(255, 255, 255, 0.08)", pvfill="transparent", pvcolor="#a1a1a6"),
          L("LaTag", (1080, 22, 262, 40), '"Paper Toy Co.  ·  New"', "Paper Toy Co.  ·  New", 14, "segoe", "semi", "6e6e73", "Right"),
          L("LaPrice", (483, 652, 400, 30), '"From ₹4,999  ·  Ships in time for the holidays"', "From ₹4,999  ·  Ships in time for the holidays", 15, "segoe", "normal", "a1a1a6"),
          B("LaBuy", (503, 690, 170, 48), '"Pre-order"', "Pre-order", "f5f5f7", "1d1d1f", "Navigate(LaunchSpecsScreen, ScreenTransition.Fade)", 17, "segoe", "semi"),
          B("LaSpecs", (693, 690, 190, 48), '"See the specs  ›"', "See the specs  ›", "000000", "2997ff", "Navigate(LaunchSpecsScreen, ScreenTransition.Fade)", 17, "segoe", "semi",
            fill_fx="RGBA(0, 0, 0, 0)", hover_fx="RGBA(41, 151, 255, 0.10)", pvfill="transparent", pvcolor="#2997ff")]
    return cs

def specs():
    bw = bg_white(); fins = {f: hero_white(f) for f in FIN}
    tag = SVG("0 0 640 100", f"<text x='0' y='74' font-family='{SANS}' font-weight='800' font-size='70' fill='#1d1d1f' letter-spacing='-2'>Play. Code. </text>"
              + gradtext(392, 74, "Glow.", 70, 800, ["#7c4dff", "#d946ef", "#ff7a2f"], anchor="start", ls=-2, x0=392, x1=600))
    num = SVG("-50 -30 520 230", gradtext(4, 140, "8 hrs", 150, 800, GV, anchor="start", glow=True, ls=-5, x0=0, x1=400))
    tiles = SVG("0 0 640 120", "".join(f"<rect x='{2+i*214}' y='2' width='196' height='112' rx='22' fill='#fff' stroke='#e2e2e7'/>" for i in range(3)), "none")
    fx = 'Switch(gFinish, "Silver", ' + svgfx(fins["Silver"]) + ', "Violet", ' + svgfx(fins["Violet"]) + ', ' + svgfx(fins["Graphite"]) + ')'
    ADD = ('If(\n    IsBlank(LookUp(colCart, Id = 200 + gFinishIdx)),\n'
           '    Collect(colCart, {Id: 200 + gFinishIdx, Name: "Spark Cube · " & gFinish, Part: "L-0" & gFinishIdx, HexA: "7c4dff", Art: ' + svgfx(ICON) + ', Price: 4999, Qty: 1}),\n'
           '    Patch(colCart, LookUp(colCart, Id = 200 + gFinishIdx), {Qty: LookUp(colCart, Id = 200 + gFinishIdx).Qty + 1})\n);\nSet(gOrdered, false);\nSet(gPreordered, true)')
    cs = [I("LsBg", (0, 0, ("Parent.Width", 1366), ("Parent.Height", 768)), svgfx(bw), bw, "Fill"),
          I("LsHero", (30, 120, 640, 578), fx, fins["Graphite"]),
          B("LsBack", (24, 22, 170, 40), '"‹  Overview"', "‹  Overview", "000000", "0066cc", "Navigate(LaunchScreen, ScreenTransition.Fade)", 15, "segoe", "semi",
            fill_fx="RGBA(0, 0, 0, 0)", hover_fx="RGBA(0, 102, 204, 0.08)", pvfill="transparent", pvcolor="#0066cc"),
          L("LsName", (700, 70, 500, 34), '"Spark Cube"', "Spark Cube", 20, "segoe", "semi", "6e6e73", "Left"),
          I("LsTag", (696, 102, 640, 100), svgfx(tag), tag),
          I("LsNum", (646, 184, 520, 230), svgfx(num), num),
          L("LsNumCap", (704, 384, 500, 30), '"of play on a single charge"', "of play on a single charge", 17, "segoe", "normal", "6e6e73", "Left"),
          I("LsTiles", (700, 428, 640, 120), svgfx(tiles), tiles, "Stretch")]
    for i, (n, cap) in enumerate((("64", "RGB LEDs"), ("120", "puzzles built in"), ("6+", "ages"))):
        x = 702 + i * 214 * 640 / 640
        cs += [L(f"LsT{i}", (x + 20, 440, 170, 54), f'"{n}"', n, 32, "segoe", "bold", "1d1d1f", "Left"),
               L(f"LsC{i}", (x + 20, 496, 170, 30), f'"{cap}"', cap, 14, "segoe", "normal", "6e6e73", "Left")]
    cs.append(L("LsFin", (700, 566, 400, 30), '"Finish  —  " & gFinish', "Finish  —  Graphite", 16, "segoe", "semi", "1d1d1f", "Left"))
    for i, (f, c) in enumerate((("Graphite", "3a3a40"), ("Silver", "d9dadf"), ("Violet", "6d4cff"))):
        cs.append(B(f"LsSw{f}", (700 + i * 58, 604, 44, 44), '""', "", c, "ffffff", f'Set(gFinish, "{f}");\nSet(gFinishIdx, {i+1});\nSet(gPreordered, false)', 12,
                    bthick=f'If(gFinish = "{f}", 3, 1)', border_fx=f'If(gFinish = "{f}", {col("0071e3")}, {col("c7c7cc")})', pvborder="#0071e3" if i == 0 else "#c7c7cc", hover_fx=col(c)))
    cs += [L("LsPrice", (900, 604, 160, 44), '"₹4,999"', "₹4,999", 26, "segoe", "bold", "1d1d1f", "Left"),
           B("LsBuy", (1070, 600, 220, 52), '"Pre-order"', "Pre-order", "0071e3", "ffffff", ADD, 17, "segoe", "semi"),
           B("LsDone", (700, 672, 520, 40), '"Added to your kit box ✓   View kit box  ›"', "Added to your kit box ✓   View kit box  ›", "000000", "0066cc",
             "Navigate(CartScreen, ScreenTransition.Cover)", 15, "segoe", "semi", radius=8, fill_fx="RGBA(0, 0, 0, 0)", hover_fx="RGBA(0, 102, 204, 0.08)",
             pvfill="transparent", pvcolor="#0066cc", visible="gPreordered", pvhide=True, extra={"Align": "Align.Left"})]
    onvis = 'If(IsBlank(gFinish), Set(gFinish, "Graphite"); Set(gFinishIdx, 1));\nSet(gPreordered, false)'
    return cs, onvis
