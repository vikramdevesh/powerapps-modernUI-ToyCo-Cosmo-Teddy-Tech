# Flat-Vector Science style: "Cosmo Kits" (space science toys) - 2 screens
import math, random
from kit import *

FF = "Nunito, Segoe UI Black, Arial Rounded MT Bold, Arial, sans-serif"
LX, LY = math.cos(-2.25), math.sin(-2.25)
UID = [0]
def uid(p="u"): UID[0] += 1; return f"{p}{UID[0]}"
def mix(a, b, t):
    A = [int(a[i:i+2], 16) for i in (1, 3, 5)]; Bb = [int(b[i:i+2], 16) for i in (1, 3, 5)]
    return "#" + "".join(f"{int(A[i] + (Bb[i] - A[i]) * t):02x}" for i in range(3))

def glow(cx, cy, r, colr, a):
    i = uid("g")
    return (f"<radialGradient id='{i}'><stop offset='0' stop-color='{colr}' stop-opacity='{a}'/><stop offset='.35' stop-color='{colr}' stop-opacity='{a*0.4:.3f}'/>"
            f"<stop offset='1' stop-color='{colr}' stop-opacity='0'/></radialGradient><circle cx='{f1(cx)}' cy='{f1(cy)}' r='{f1(r)}' fill='url(#{i})'/>")

def ball(cx, cy, r, cols, sh=0.3, sha=0.5, rima=0.42, inner=""):
    gi, ci = uid("b"), uid("c")
    c0, c1, c2 = cols
    s = (f"<linearGradient id='{gi}' gradientUnits='userSpaceOnUse' x1='{f1(cx+LX*r)}' y1='{f1(cy+LY*r)}' x2='{f1(cx-LX*r)}' y2='{f1(cy-LY*r)}'>"
         f"<stop offset='0' stop-color='{c0}'/><stop offset='.45' stop-color='{c1}'/><stop offset='1' stop-color='{mix(c1, c2, 0.6)}'/></linearGradient>"
         f"<clipPath id='{ci}'><circle cx='{f1(cx)}' cy='{f1(cy)}' r='{f1(r)}'/></clipPath>"
         f"<circle cx='{f1(cx)}' cy='{f1(cy)}' r='{f1(r)}' fill='url(#{gi})'/>")
    if inner: s += f"<g clip-path='url(#{ci})'>{inner}</g>"
    box = f"M{f1(cx-r-2)},{f1(cy-r-2)}h{f1(2*r+4)}v{f1(2*r+4)}h{f1(-2*r-4)}z"
    def cres(dx, dy, fill, op):
        return f"<path clip-path='url(#{ci})' fill-rule='evenodd' fill='{fill}' fill-opacity='{op:.3f}' d='{box}{circ(cx+dx, cy+dy, r*1.02)}'/>"
    s += cres(LX*r*sh, LY*r*sh, c2, sha) + cres(LX*r*sh*2.2, LY*r*sh*2.2, c2, sha*0.45) + cres(-LX*r*0.075, -LY*r*0.075, "#ffffff", rima)
    return s

def spark(cx, cy, r, colr="#ffffff", op=0.95):
    return (f"<path fill='{colr}' fill-opacity='{op}' d='M{f1(cx)},{f1(cy-r)}Q{f1(cx)},{f1(cy)} {f1(cx+r)},{f1(cy)}Q{f1(cx)},{f1(cy)} {f1(cx)},{f1(cy+r)}"
            f"Q{f1(cx)},{f1(cy)} {f1(cx-r)},{f1(cy)}Q{f1(cx)},{f1(cy)} {f1(cx)},{f1(cy-r)}z'/>")

PL = {
    "magenta": dict(c=("#ffa0c4", "#de4b93", "#4e1670"), glow="#ff5fa8", tilt=-0.18,
                    bands=[(-0.62, -0.48, "#ffc1d8", 0.55), (-0.2, -0.02, "#b5307e", 0.6), (0.06, 0.14, "#ffd0e2", 0.4), (0.36, 0.58, "#9a2775", 0.55)],
                    ring=dict(rx=1.75, ry=0.5, tilt=-0.2, bands=[(1.18, 1.32, "#ffd27a", 0.95), (1.34, 1.5, "#ff9f5a", 0.9), (1.53, 1.6, "#ffe7b0", 0.8)])),
    "coral": dict(c=("#ffd29a", "#ff7a4a", "#7a1f4f"), glow="#ff8a50", tilt=0.1,
                  bands=[(-0.7, -0.5, "#ffe2b8", 0.5), (-0.32, -0.12, "#e8553a", 0.6), (0.05, 0.22, "#ffb27a", 0.5), (0.4, 0.62, "#c43c46", 0.55)]),
    "teal": dict(c=("#9ff3ff", "#3a9be0", "#1d2f86"), glow="#4fc9ff", tilt=-0.12,
                 bands=[(-0.5, -0.36, "#c6f8ff", 0.5), (-0.05, 0.1, "#2f74c9", 0.55), (0.32, 0.5, "#7fdcff", 0.4)]),
    "moon": dict(c=("#e8e6ff", "#a7a2d8", "#4a3f8c"), craters=True),
}
def bands_svg(cx, cy, r, B, tilt):
    s = f"<g transform='translate({f1(cx)} {f1(cy)}) rotate({f1(math.degrees(tilt))})'>"
    for v0, v1, c, a in B:
        pts = [(u * r * 1.1, (v0 + 0.13 * (1 - u * u)) * r) for u in [i / 10 - 1 for i in range(21)]]
        pts += [(u * r * 1.1, (v1 + 0.13 * (1 - u * u)) * r) for u in reversed([i / 10 - 1 for i in range(21)])]
        s += f"<polygon fill='{c}' fill-opacity='{a}' points='{poly(pts)}'/>"
    return s + "</g>"
def ellpath(rx, ry): return f"M{f1(-rx)},0a{f1(rx)},{f1(ry)} 0 1,0 {f1(2*rx)},0a{f1(rx)},{f1(ry)} 0 1,0 {f1(-2*rx)},0z"
def ring_svg(cx, cy, R, half):
    ci = uid("rc"); m = max(b[1] for b in R["bands"]) * 1.05
    y0 = -R["ry"] * m if half == "back" else 0
    s = (f"<g transform='translate({f1(cx)} {f1(cy)}) rotate({f1(math.degrees(R['tilt']))})'><clipPath id='{ci}'><rect x='{f1(-R['rx']*m)}' y='{f1(y0)}' "
         f"width='{f1(R['rx']*m*2)}' height='{f1(R['ry']*m)}'/></clipPath><g clip-path='url(#{ci})'>")
    for f0, f1_, c, a in R["bands"]:
        s += f"<path fill-rule='evenodd' fill='{c}' fill-opacity='{a*(0.75 if half=='back' else 1):.2f}' d='{ellpath(R['rx']*f1_, R['ry']*f1_)}{ellpath(R['rx']*f0, R['ry']*f0)}'/>"
    return s + "</g></g>"
def planet(cx, cy, r, name, glowA=0.32):
    P = PL[name]; s = ""
    if P.get("glow"): s += glow(cx, cy, r * 1.7, P["glow"], glowA)
    R = None
    if P.get("ring"): R = dict(rx=P["ring"]["rx"] * r, ry=P["ring"]["ry"] * r, tilt=P["ring"]["tilt"], bands=P["ring"]["bands"]); s += ring_svg(cx, cy, R, "back")
    inner = ""
    if P.get("bands"): inner += bands_svg(cx, cy, r, P["bands"], P["tilt"])
    if P.get("craters"):
        q = random.Random(5)
        for _ in range(5):
            a = q.uniform(0, 6.28); d = q.uniform(0.1, 0.65) * r; cr = q.uniform(0.1, 0.2) * r
            inner += f"<circle cx='{f1(cx+math.cos(a)*d)}' cy='{f1(cy+math.sin(a)*d)}' r='{f1(cr)}' fill='#504296' fill-opacity='.38'/>"
    s += ball(cx, cy, r, P["c"], sh=0.34, sha=0.55, rima=0.35, inner=inner)
    if R: s += ring_svg(cx, cy, R, "front")
    return s

def sky(seed=77, extra=""):
    r = random.Random(seed); s = ("<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 1366 768' preserveAspectRatio='xMidYMid slice'><defs>"
         "<linearGradient id='sk' x1='0' y1='0' x2='.3' y2='1'><stop offset='0' stop-color='#090b2c'/><stop offset='.5' stop-color='#18134f'/><stop offset='1' stop-color='#3a1a6c'/></linearGradient>"
         "<filter id='gr' x='0' y='0' width='100%' height='100%'><feTurbulence type='fractalNoise' baseFrequency='.85' numOctaves='2' seed='4'/><feColorMatrix type='saturate' values='0'/></filter></defs>"
         "<rect width='1366' height='768' fill='url(#sk)'/>")
    s += glow(1175, 92, 700, "#7b34c6", 0.34) + glow(68, 768, 620, "#2448b4", 0.4) + glow(615, 460, 520, "#4a2a9c", 0.16)
    cols = ["#ffffff", "#cfe4ff", "#ffe9c7", "#dccbff"]
    for _ in range(140):
        x, y, d = r.uniform(0, 1366), r.uniform(0, 768), r.choice([0.3, 0.55, 1]); s += f"<circle cx='{f1(x)}' cy='{f1(y)}' r='{r.uniform(0.6, 2.0)*(0.7+0.35*d):.1f}' fill='{r.choice(cols)}' opacity='{0.3+0.6*d*r.random():.1f}'/>"
    for _ in range(9):
        x, y, sz = r.uniform(0, 1366), r.uniform(0, 768), r.uniform(6, 12); s += glow(x, y, sz * 2.2, "#bfa8ff", 0.25) + spark(x, y, sz)
    s += extra
    s += "<rect width='1366' height='768' filter='url(#gr)' opacity='.09' style='mix-blend-mode:overlay'/></svg>"
    return s

# ---------- the lab-buddy robot (teal ball, glass dome brain) ----------
def robot(cx, cy, R, look=(-0.4, -0.3), happy=True):
    s = glow(cx, cy + R * 1.25, R * 0.95, "#ff9a3d", 0.4)
    s += (f"<path fill='#ff8a3d' d='M{f1(cx-R*.25)},{f1(cy+R*.9)}Q{f1(cx-R*.2)},{f1(cy+R*1.47)} {f1(cx)},{f1(cy+R*1.8)}Q{f1(cx+R*.2)},{f1(cy+R*1.47)} {f1(cx+R*.25)},{f1(cy+R*.9)}z'/>"
          f"<path fill='#ffd94a' d='M{f1(cx-R*.13)},{f1(cy+R*.92)}Q{f1(cx-R*.1)},{f1(cy+R*1.27)} {f1(cx)},{f1(cy+R*1.44)}Q{f1(cx+R*.1)},{f1(cy+R*1.27)} {f1(cx+R*.13)},{f1(cy+R*.92)}z'/>"
          f"<rect x='{f1(cx-R*.32)}' y='{f1(cy+R*.78)}' width='{f1(R*.64)}' height='{f1(R*.22)}' rx='{f1(R*.08)}' fill='#16307a'/>")
    for sd, ang in ((-1, -0.55), (1, 2.3)):
        sx, sy = cx + sd * R * 0.86, cy + R * 0.12; ex, ey = sx + math.sin(ang) * R * 0.55 * (1 if sd < 0 else -1) * -1, sy + math.cos(ang) * R * 0.55
        if sd > 0: ex, ey = sx + R * 0.45, sy - R * 0.38
        s += f"<line x1='{f1(sx)}' y1='{f1(sy)}' x2='{f1(ex)}' y2='{f1(ey)}' stroke='#1d5aa6' stroke-width='{f1(R*.24)}' stroke-linecap='round'/>"
        s += ball(ex, ey, R * 0.17, ("#a4fbef", "#3ccbdc", "#1d64b0"), sha=0.4)
    dr, dx, dy = R * 0.76, cx, cy - R * 1.02
    s += glow(dx, dy, dr * 2.0, "#58e6ff", 0.42)
    di, dc = uid("d"), uid("dc")
    s += (f"<radialGradient id='{di}' gradientUnits='userSpaceOnUse' cx='{f1(dx-dr*.3)}' cy='{f1(dy-dr*.3)}' r='{f1(dr*1.4)}'><stop offset='0' stop-color='#2a3a9c'/>"
          f"<stop offset='.6' stop-color='#18206a'/><stop offset='1' stop-color='#0d1146'/></radialGradient><clipPath id='{dc}'><circle cx='{f1(dx)}' cy='{f1(dy)}' r='{f1(dr)}'/></clipPath>"
          f"<circle cx='{f1(dx)}' cy='{f1(dy)}' r='{f1(dr)}' fill='url(#{di})'/><g clip-path='url(#{dc})'>")
    nodes = [(-0.6, y) for y in (-0.42, 0.02, 0.44)] + [(0, y) for y in (-0.58, -0.2, 0.2, 0.58)] + [(0.6, y) for y in (-0.4, 0.04, 0.44)]
    P = lambda n: (dx + n[0] * dr * 0.78, dy - dr * 0.1 + n[1] * dr * 0.78)
    q = random.Random(31)
    for a in nodes[:3]:
        for b in nodes[3:7]:
            if q.random() < 0.6: (ax, ay), (bx, by) = P(a), P(b); w = q.random(); s += f"<path d='M{f1(ax)},{f1(ay)}Q{f1((ax+bx)/2)},{f1((ay+by)/2-dr*.08)} {f1(bx)},{f1(by)}' fill='none' stroke='{mix('#7a5cff', '#ffd23f', w)}' stroke-opacity='{0.55+0.45*w:.2f}' stroke-width='{f1(dr*(0.025+0.05*w))}' stroke-linecap='round'/>"
    for a in nodes[3:7]:
        for b in nodes[7:]:
            if q.random() < 0.6: (ax, ay), (bx, by) = P(a), P(b); w = q.random(); s += f"<path d='M{f1(ax)},{f1(ay)}Q{f1((ax+bx)/2)},{f1((ay+by)/2-dr*.08)} {f1(bx)},{f1(by)}' fill='none' stroke='{mix('#7a5cff', '#ffd23f', w)}' stroke-opacity='{0.55+0.45*w:.2f}' stroke-width='{f1(dr*(0.025+0.05*w))}' stroke-linecap='round'/>"
    for n in nodes:
        nx, ny = P(n); s += glow(nx, ny, dr * 0.32, "#ffe066", 0.55) + f"<circle cx='{f1(nx)}' cy='{f1(ny)}' r='{f1(dr*.1)}' fill='#ffe066'/><circle cx='{f1(nx-dr*.025)}' cy='{f1(ny-dr*.025)}' r='{f1(dr*.035)}' fill='#fff' fill-opacity='.75'/>"
    s += "</g>"
    box = f"M{f1(dx-dr-2)},{f1(dy-dr-2)}h{f1(2*dr+4)}v{f1(2*dr+4)}h{f1(-2*dr-4)}z"
    s += f"<path clip-path='url(#{dc})' fill-rule='evenodd' fill='#bef' fill-opacity='.5' d='{box}{circ(dx+dr*.1, dy+dr*.12, dr*1.02)}'/>"
    s += f"<path clip-path='url(#{dc})' fill-rule='evenodd' fill='#080a32' fill-opacity='.28' d='{box}{circ(dx-dr*.22, dy-dr*.2, dr*1.02)}'/>"
    a0, a1 = math.pi * 1.08, math.pi * 1.36
    s += f"<path d='M{f1(dx+dr*.74*math.cos(a0))},{f1(dy+dr*.74*math.sin(a0))}A{f1(dr*.74)},{f1(dr*.74)} 0 0,1 {f1(dx+dr*.74*math.cos(a1))},{f1(dy+dr*.74*math.sin(a1))}' fill='none' stroke='#fff' stroke-opacity='.6' stroke-width='{f1(dr*.09)}' stroke-linecap='round'/>"
    s += f"<rect x='{f1(cx-R*.6)}' y='{f1(cy-R*.84)}' width='{f1(R*1.2)}' height='{f1(R*.26)}' rx='{f1(R*.13)}' fill='#1b4c9c'/>"
    s += ball(cx, cy, R, ("#a4fbef", "#3ccbdc", "#1d64b0"), sha=0.5)
    vw, vh = R * 1.36, R * 0.78; vx, vy = cx - vw / 2 + R * 0.02, cy - R * 0.42; vg = uid("v")
    s += (f"<rect x='{f1(vx)}' y='{f1(vy+R*.05)}' width='{f1(vw)}' height='{f1(vh)}' rx='{f1(R*.34)}' fill='#0c1145'/>"
          f"<linearGradient id='{vg}' x1='0' y1='0' x2='1' y2='1'><stop offset='0' stop-color='#26338e'/><stop offset='.5' stop-color='#151c5c'/><stop offset='1' stop-color='#0d1246'/></linearGradient>"
          f"<rect x='{f1(vx)}' y='{f1(vy)}' width='{f1(vw)}' height='{f1(vh)}' rx='{f1(R*.34)}' fill='url(#{vg})'/>"
          f"<rect x='{f1(vx+R*.16)}' y='{f1(vy+R*.07)}' width='{f1(vw*.45)}' height='{f1(R*.07)}' rx='{f1(R*.035)}' fill='#a0f0ff' fill-opacity='.22'/>")
    ey, er = vy + vh * 0.48, R * 0.19
    for sd in (-1, 1):
        ex = cx + sd * R * 0.3
        if happy:
            s += f"<path d='M{f1(ex-er*.6)},{f1(ey+er*.2)}Q{f1(ex)},{f1(ey-er*.7)} {f1(ex+er*.6)},{f1(ey+er*.2)}' fill='none' stroke='#fff' stroke-width='{f1(er*.42)}' stroke-linecap='round'/>"
        else:
            px, py, pr = ex + look[0] * er * .36, ey + look[1] * er * .36, er * .56
            s += f"<circle cx='{f1(ex)}' cy='{f1(ey)}' r='{f1(er)}' fill='#fff'/><circle cx='{f1(px)}' cy='{f1(py)}' r='{f1(pr)}' fill='#141638'/><circle cx='{f1(px-pr*.35)}' cy='{f1(py-pr*.4)}' r='{f1(pr*.32)}' fill='#fff'/>"
    my = vy + vh * 0.86
    s += f"<path d='M{f1(cx-R*.12)},{f1(my-R*.05)}Q{f1(cx)},{f1(my+R*.08)} {f1(cx+R*.12)},{f1(my-R*.05)}' fill='none' stroke='#9ff7ff' stroke-width='{f1(R*.06)}' stroke-linecap='round'/>"
    for i, c in enumerate(("#ffd23f", "#ff5d8f", "#56e8ff")):
        bx, by = cx + (i - 1) * R * 0.2, cy + R * 0.58; s += glow(bx, by, R * 0.12, c, 0.5) + f"<circle cx='{f1(bx)}' cy='{f1(by)}' r='{f1(R*.055)}' fill='{c}'/>"
    return s

def text_sh(x, y, s, px, colr, anchor="start", w=900):
    return (f"<text x='{f1(x+px*.03)}' y='{f1(y+px*.07)}' font-family='{FF}' font-weight='{w}' font-size='{px}' fill='#0a082e' fill-opacity='.55' text-anchor='{anchor}'>{s}</text>"
            f"<text x='{f1(x)}' y='{f1(y)}' font-family='{FF}' font-weight='{w}' font-size='{px}' fill='{colr}' text-anchor='{anchor}'>{s}</text>")
def dotted(d, colr="#7ff0ff", lw=9, head=None, op=0.8):
    s = f"<path d='{d}' fill='none' stroke='{colr}' stroke-opacity='{op}' stroke-width='{lw}' stroke-linecap='round' stroke-dasharray='0.01 {f1(lw*1.9)}'/>"
    if head:
        (x, y), a = head; hs = lw * 1.5; c, sn = math.cos(a), math.sin(a)
        pts = [(x + c * hs * 1.1, y + sn * hs * 1.1), (x - c * hs * .8 - sn * hs, y - sn * hs * .8 + c * hs), (x - c * hs * .8 + sn * hs, y - sn * hs * .8 - c * hs)]
        s += f"<polygon points='{poly(pts)}' fill='{colr}' fill-opacity='{op}' stroke='{colr}' stroke-opacity='{op}' stroke-width='{f1(lw*.7)}' stroke-linejoin='round'/>"
    return s
def SVG(vb, body, par="xMidYMid meet"):
    return f"<svg xmlns='http://www.w3.org/2000/svg' viewBox='{vb}' preserveAspectRatio='{par}'>{body}</svg>"

# ---------- kit art (200x200) ----------
def art_rocket():
    b = glow(100, 100, 95, "#ff8d3f", 0.35) + spark(40, 40, 7) + spark(165, 60, 5)
    b += glow(100, 168, 40, "#ff9a3d", 0.6) + "<path fill='#ff8a3d' d='M84,150Q86,180 100,194Q114,180 116,150z'/><path fill='#ffd94a' d='M91,150Q92,172 100,182Q108,172 109,150z'/>"
    b += "<path fill='#d24a2a' d='M78,118L56,150L58,160L82,142z'/><path fill='#ff8d3f' d='M122,118L144,150L142,160L118,142z'/>"
    gi = uid("r"); b += (f"<linearGradient id='{gi}' x1='0' y1='0' x2='1' y2='0'><stop offset='0' stop-color='#ffffff'/><stop offset='.55' stop-color='#e2dcff'/><stop offset='1' stop-color='#8f86d8'/></linearGradient>"
                         f"<path fill='url(#{gi})' d='M100,26C124,46 128,90 122,150H78C72,90 76,46 100,26z'/>")
    b += "<path fill='#ff5d8f' d='M100,26C112,36 118,48 121,60H79C82,48 88,36 100,26z'/><rect x='92' y='146' width='16' height='10' rx='3' fill='#16307a'/>"
    b += ball(100, 92, 16, ("#a4fbef", "#3ccbdc", "#1d64b0"), sha=0.5) + "<circle cx='100' cy='92' r='19' fill='none' stroke='#5b52a8' stroke-width='4'/>"
    return SVG("0 0 200 200", b)
def art_rover():
    b = glow(100, 110, 95, "#ff7a4a", 0.32) + spark(160, 36, 6)
    b += "<path d='M10,176Q100,150 190,176V200H10z' fill='#c43c46'/><path d='M10,176Q100,154 190,176' stroke='#ffb27a' stroke-width='4' fill='none' stroke-opacity='.6'/>"
    b += "<line x1='130' y1='96' x2='136' y2='44' stroke='#d8d4ff' stroke-width='6' stroke-linecap='round'/><rect x='122' y='30' width='30' height='18' rx='7' fill='#e8e6ff'/>"
    b += ball(144, 39, 6, ("#a4fbef", "#3ccbdc", "#1d64b0"))
    b += "<polygon points='38,82 112,74 118,92 44,100' fill='#2f74c9'/><path d='M50,84L54,98M66,82L70,96M82,80L86,94M98,78L102,92' stroke='#7fdcff' stroke-width='2'/>"
    gi = uid("rv"); b += (f"<linearGradient id='{gi}' x1='0' y1='0' x2='0' y2='1'><stop offset='0' stop-color='#ffcc7a'/><stop offset='.5' stop-color='#ff8d3f'/><stop offset='1' stop-color='#b84a2a'/></linearGradient>"
                          f"<rect x='40' y='100' width='120' height='42' rx='14' fill='url(#{gi})'/><rect x='48' y='106' width='60' height='8' rx='4' fill='#fff' fill-opacity='.35'/>")
    for x in (56, 100, 144):
        b += f"<line x1='{x}' y1='140' x2='{x}' y2='154' stroke='#4a3f8c' stroke-width='6'/>" + ball(x, 162, 15, ("#5a5f8c", "#2a2d55", "#0d0f2a"), sha=0.4) + f"<circle cx='{x}' cy='162' r='5' fill='#c3c8ff'/>"
    return SVG("0 0 200 200", b)
def art_projector():
    b = glow(100, 100, 98, "#8b5cff", 0.4)
    for a in (-60, -30, 0, 30, 60):
        r_ = math.radians(a - 90); b += f"<polygon points='100,96 {f1(100+math.cos(r_-0.12)*110)},{f1(96+math.sin(r_-0.12)*110)} {f1(100+math.cos(r_+0.12)*110)},{f1(96+math.sin(r_+0.12)*110)}' fill='#fff3b0' fill-opacity='.14'/>"
    b += "<rect x='58' y='140' width='84' height='30' rx='12' fill='#3a2a8c'/><rect x='66' y='146' width='40' height='6' rx='3' fill='#fff' fill-opacity='.25'/>"
    b += ball(100, 112, 40, ("#c9b5ff", "#8b5cff", "#2c1670"), inner=spark(88, 100, 7, "#ffd23f") + spark(112, 92, 5, "#ffd23f") + spark(104, 122, 6, "#ffd23f") + spark(82, 124, 4, "#fff"))
    for (x, y, s_) in ((40, 40, 8), (160, 34, 10), (150, 74, 6), (52, 76, 5), (100, 22, 7)): b += spark(x, y, s_, "#ffe28a")
    return SVG("0 0 200 200", b)
def art_moon():
    b = glow(100, 92, 98, "#e8e6ff", 0.38)
    b += "<path d='M66,166H134L126,184H74z' fill='#b4723c'/><rect x='62' y='160' width='76' height='10' rx='5' fill='#ecb676'/>"
    inner = "".join(f"<circle cx='{x}' cy='{y}' r='{r}' fill='#504296' fill-opacity='.35'/>" for x, y, r in ((82, 80, 10), (116, 70, 7), (108, 110, 13), (78, 118, 6), (128, 96, 5)))
    b += ball(100, 92, 58, ("#f4f2ff", "#b9b4e6", "#4a3f8c"), sha=0.45, inner=inner) + spark(162, 40, 8) + spark(36, 52, 6)
    return SVG("0 0 200 200", b)
def art_telescope():
    b = glow(100, 96, 96, "#3ccbdc", 0.36) + spark(156, 34, 9, "#ffe28a") + spark(178, 70, 5)
    b += "<path d='M100,118L64,184M100,118L136,184M100,118L100,188' stroke='#8f86d8' stroke-width='7' stroke-linecap='round'/>"
    gi = uid("t"); b += (f"<linearGradient id='{gi}' x1='0' y1='0' x2='0' y2='1'><stop offset='0' stop-color='#a4fbef'/><stop offset='.5' stop-color='#3ccbdc'/><stop offset='1' stop-color='#1d64b0'/></linearGradient>"
                         f"<g transform='rotate(-32 100 110)'><rect x='38' y='94' width='128' height='34' rx='12' fill='url(#{gi})'/><rect x='150' y='88' width='26' height='46' rx='9' fill='#ff5d8f'/>"
                         f"<rect x='22' y='102' width='22' height='18' rx='5' fill='#16307a'/><rect x='50' y='100' width='70' height='7' rx='3.5' fill='#fff' fill-opacity='.4'/></g>")
    b += "<circle cx='100' cy='118' r='9' fill='#ffd23f'/>"
    return SVG("0 0 200 200", b)
def art_mobile():
    b = glow(100, 100, 98, "#ffd23f", 0.4)
    for rx, ry in ((44, 16), (70, 26), (92, 36)): b += f"<ellipse cx='100' cy='104' rx='{rx}' ry='{ry}' fill='none' stroke='#fff' stroke-opacity='.45' stroke-width='2.5' stroke-dasharray='0.01 7' stroke-linecap='round'/>"
    b += glow(100, 104, 50, "#ffcf5a", 0.7) + ball(100, 104, 24, ("#fff6c8", "#ffd23f", "#d24a2a"), sha=0.35)
    b += ball(144, 108, 9, ("#9ff3ff", "#3a9be0", "#1d2f86")) + ball(40, 116, 12, ("#ffd29a", "#ff7a4a", "#7a1f4f"))
    R = dict(rx=24, ry=7, tilt=-0.2, bands=[(1.18, 1.5, "#ffd27a", 0.95)]); b += ring_svg(150, 72, R, "back") + ball(150, 72, 12, ("#ffa0c4", "#de4b93", "#4e1670")) + ring_svg(150, 72, R, "front")
    b += "<line x1='100' y1='4' x2='100' y2='78' stroke='#fff' stroke-opacity='.5' stroke-width='2'/>"
    return SVG("0 0 200 200", b)

KITS = [  # id, name, cat, hex, price, age, num, fact, artfn
    (101, "Rocket Lab Kit", "Rockets", "ff8d3f", 1299, "8+", "11.2 km/s", "The speed a rocket needs to escape Earth's gravity.", art_rocket),
    (102, "Mars Rover Builder", "Rockets", "ff7a4a", 1899, "10+", "2021", "The year NASA's Perseverance rover landed on Mars.", art_rover),
    (103, "Star Projector", "Night Sky", "8b5cff", 999, "4+", "2,500", "About how many stars you can see with your eyes on a clear, dark night.", art_projector),
    (104, "Moon Lamp", "Night Sky", "a7a2d8", 799, "3+", "384,400 km", "The average distance from Earth to the Moon.", art_moon),
    (105, "Junior Telescope", "Telescopes", "3ccbdc", 2499, "8+", "1609", "The year Galileo first turned a telescope to the night sky.", art_telescope),
    (106, "Solar System Mobile", "Planets", "ffd23f", 699, "5+", "8 planets", "Mercury to Neptune: the planets that orbit our Sun.", art_mobile),
]
ARTS = {k[0]: k[8]() for k in KITS}
CATS = [("Rockets", "coral"), ("Planets", "magenta"), ("Night Sky", "moon"), ("Telescopes", "teal")]
YEL, INKC, PINK, CYAN = "ffd23f", "141846", "ff5d8f", "56e8ff"

def cat_ball(pl):
    return SVG("0 0 200 200", planet(100, 100, 52 if PL[pl].get("ring") else 62, pl, 0.4))

# ================= SCREENS =================
def home():
    bg = sky(77, planet(1150, 650, 200, "magenta", 0.3) + planet(1230, 110, 30, "moon") + planet(660, 70, 30, "coral", 0.25)
             + dotted("M300,700C420,700 470,560 610,520", "#7ff0ff", 9, ((610, 520), -0.25), 0.75))
    title = SVG("0 0 640 240", text_sh(4, 100, "Cosmo", 104, "#ffffff") + text_sh(360, 100, "Kits", 104, "#" + YEL) + text_sh(6, 190, "space science toys", 44, "#bfe9ff", w=800))
    bot = SVG("0 0 380 460", robot(190, 300, 100, happy=True))
    bub = SVG("0 0 260 130", "<rect x='4' y='12' width='240' height='92' rx='46' fill='#0a082e' fill-opacity='.4'/><path d='M60,90L20,128L96,96z' fill='#fff'/>"
              "<rect x='0' y='0' width='240' height='92' rx='46' fill='#fff'/>" + f"<text x='120' y='60' text-anchor='middle' font-family='{FF}' font-weight='900' font-size='38' fill='#141846'>Let's launch!</text>")
    cs = []
    cs.append(I("SpBg", (0, 0, ("Parent.Width", 1366), ("Parent.Height", 768)), svgfx(bg), bg, "Fill"))
    cs.append(B("SpTopPill", (60, 36, 270, 44), '"MISSION: LOOK UP"', "MISSION: LOOK UP", PINK, "ffffff", "false", 15, hover_fx=col(PINK)))
    cs.append(I("SpTitle", (52, 96, 640, 240), svgfx(title), title))
    cs.append(L("SpSub", (64, 340, 560, 70), '"Build it, launch it, look up. Science kits for curious kids, from rockets to telescopes."',
                "Build it, launch it, look up. Science kits for curious kids, from rockets to telescopes.", 18, color="bfe9ff", align="Left", valign="Top", wrap=True))
    cs.append(I("SpBot", (690, 150, 380, 460), svgfx(bot), bot))
    cs.append(I("SpBubble", (960, 120, 260, 130), svgfx(bub), bub))
    cs.append(B("SpBotTag", (780, 610, 200, 46), '"Cosmo, lab buddy"', "Cosmo, lab buddy", YEL, INKC, "false", 16, hover_fx=col(YEL)))
    for i, (cat, pl) in enumerate(CATS):
        x = 60 + i * 150; s = cat_ball(pl)
        on = f'Set(gSpaceCat, "{cat}");\nNavigate(SpaceShopScreen, ScreenTransition.Cover)'
        cs.append(I(f"SpCat{i}", (x, 430, 130, 130), svgfx(s), s))
        cs.append(HIT(f"SpCatHit{i}", (x, 430, 130, 130), on, f"Browse {cat}"))
        cs.append(B(f"SpCatPill{i}", (x - 6, 560, 142, 40), f'"{cat}"', cat, "ffffff", INKC, on, 15, fill_fx="RGBA(255, 255, 255, 0.95)", pvfill="#fff"))
    cs.append(B("SpCta", (60, 650, 300, 62), '"Explore all kits  →"', "Explore all kits  →", YEL, INKC,
                'Set(gSpaceCat, "All");\nNavigate(SpaceShopScreen, ScreenTransition.Cover)', 22))
    cs.append(B("SpBack", (1140, 36, 180, 44), '"←  Workbench"', "←  Workbench", "ffffff", "ffffff", "Navigate(HomeScreen, ScreenTransition.UnCover)", 15,
                fill_fx="RGBA(255, 255, 255, 0.14)", pvfill="rgba(255,255,255,.14)"))
    cs.append(B("SpCart", (940, 36, 186, 44), '"Kit box: " & Sum(colCart, Qty)', "Kit box: 3", "ffffff", "ffffff", "Navigate(CartScreen, ScreenTransition.Cover)", 15,
                fill_fx="RGBA(255, 255, 255, 0.14)", pvfill="rgba(255,255,255,.14)"))
    return cs

CARD = SVG("0 0 240 250", "<defs><linearGradient id='cg' x1='0' y1='0' x2='.4' y2='1'><stop offset='0' stop-color='#2a1f72'/><stop offset='1' stop-color='#120d3f'/></linearGradient>"
           "<radialGradient id='cr' cx='.3' cy='.25' r='.7'><stop offset='0' stop-color='#HEX' stop-opacity='.45'/><stop offset='1' stop-color='#HEX' stop-opacity='0'/></radialGradient></defs>"
           "<rect x='6' y='10' width='228' height='236' rx='30' fill='#05041c' fill-opacity='.45'/><rect x='2' y='2' width='228' height='236' rx='30' fill='url(#cg)'/>"
           "<rect x='2' y='2' width='228' height='236' rx='30' fill='url(#cr)'/><rect x='22' y='10' width='120' height='8' rx='4' fill='#fff' fill-opacity='.18'/>"
           "<circle cx='196' cy='40' r='2' fill='#fff' fill-opacity='.7'/><circle cx='210' cy='90' r='1.5' fill='#fff' fill-opacity='.5'/><circle cx='30' cy='140' r='1.6' fill='#fff' fill-opacity='.5'/>", "none")
SEL = SVG("0 0 240 250", "<rect x='3' y='3' width='226' height='234' rx='29' fill='none' stroke='#ffd23f' stroke-width='5'/>", "none")
PANEL = SVG("0 0 480 640", "<defs><linearGradient id='pg' x1='0' y1='0' x2='.3' y2='1'><stop offset='0' stop-color='#241a62' stop-opacity='.92'/><stop offset='1' stop-color='#0d0a33' stop-opacity='.95'/></linearGradient></defs>"
            "<rect x='8' y='12' width='468' height='624' rx='40' fill='#05041c' fill-opacity='.5'/><rect x='2' y='2' width='468' height='624' rx='40' fill='url(#pg)'/>"
            "<rect x='40' y='12' width='200' height='10' rx='5' fill='#fff' fill-opacity='.14'/>" + glow(420, 60, 160, "#7b34c6", 0.35), "none")

def shop():
    bg = sky(91, planet(-40, 760, 260, "teal", 0.28) + planet(1300, 70, 26, "moon"))
    rows = ",\n        ".join(
        f'{{Id: {k[0]}, Name: "{k[1]}", Cat: "{k[2]}", HexA: "{k[3]}", Price: {k[4]}, Age: "{k[5]}", Num: "{k[6]}", Fact: "{k[7]}", Part: "S-0{k[0]-100}", '
        f'Art: {svgfx(ARTS[k[0]])}}}' for k in KITS)
    onvis = ('ClearCollect(\n    colSpaceKits,\n    Table(\n        ' + rows + '\n    )\n);\nIf(IsBlank(gSpaceCat), Set(gSpaceCat, "All"));\n'
             'If(IsBlank(gSpace) || IsBlank(LookUp(colSpaceKits, Id = gSpace.Id)), Set(gSpace, First(colSpaceKits)), Set(gSpace, LookUp(colSpaceKits, Id = gSpace.Id)))')
    ADD = lambda X: (f"If(\n    IsBlank(LookUp(colCart, Id = {X}.Id)),\n    Collect(colCart, {{Id: {X}.Id, Name: {X}.Name, Part: {X}.Part, HexA: {X}.HexA, Art: {X}.Art, Price: {X}.Price, Qty: 1}}),\n"
                     f"    Patch(colCart, LookUp(colCart, Id = {X}.Id), {{Qty: LookUp(colCart, Id = {X}.Id).Qty + 1}})\n);\nSet(gOrdered, false)")
    cs = [I("SsBg", (0, 0, ("Parent.Width", 1366), ("Parent.Height", 768)), svgfx(bg), bg, "Fill")]
    hdr = SVG("0 0 520 90", text_sh(2, 64, "The Launch Pad", 60, "#ffffff"))
    cs.append(I("SsTitle", (40, 22, 520, 90), svgfx(hdr), hdr))
    cs.append(B("SsBack", (1140, 36, 180, 44), '"←  Mission control"', "←  Mission control", "ffffff", "ffffff", "Navigate(SpaceHomeScreen, ScreenTransition.UnCover)", 14,
                fill_fx="RGBA(255, 255, 255, 0.14)", pvfill="rgba(255,255,255,.14)"))
    cs.append(B("SsCart", (940, 36, 186, 44), '"Kit box: " & Sum(colCart, Qty)', "Kit box: 3", "ffffff", "ffffff", "Navigate(CartScreen, ScreenTransition.Cover)", 15,
                fill_fx="RGBA(255, 255, 255, 0.14)", pvfill="rgba(255,255,255,.14)"))
    x = 44
    for cat in ["All"] + [c for c, _ in CATS]:
        w = 70 + len(cat) * 11
        cs.append(B(f"SsF{cat.replace(' ', '')}", (x, 118, w, 42), f'"{cat}"', cat, YEL, INKC, f'Set(gSpaceCat, "{cat}")', 15,
                    fill_fx=f'If(gSpaceCat = "{cat}", {col(YEL)}, RGBA(255, 255, 255, 0.14))', color_fx=f'If(gSpaceCat = "{cat}", {col(INKC)}, {col("ffffff")})',
                    pvfill="#ffd23f" if cat == "All" else "rgba(255,255,255,.14)", pvcolor="#141846" if cat == "All" else "#fff"))
        x += w + 12
    TW, TH = 244, 250
    def item(k):
        twf = lambda d: (f"Parent.TemplateWidth - {d}", TW - d)
        return [
            I("SkCard", (0, 0, ("Parent.TemplateWidth", TW), ("Parent.TemplateHeight", TH)), svgfx(CARD).replace('EncodeUrl("', 'EncodeUrl(Substitute("').replace('")', '", "HEX", ThisItem.HexA))', 1) if False else
              f'"data:image/svg+xml;utf8," & EncodeUrl(Substitute("{CARD}", "HEX", ThisItem.HexA))', CARD.replace("HEX", k[3]), "Stretch"),
            I("SkSel", (0, 0, ("Parent.TemplateWidth", TW), ("Parent.TemplateHeight", TH)), svgfx(SEL), SEL, "Stretch", visible="ThisItem.Id = gSpace.Id", pvhide=k[0] != 101),
            I("SkArt", (32, 8, twf(64), 150), "ThisItem.Art", ARTS[k[0]]),
            L("SkName", (12, 156, twf(24), 34), "ThisItem.Name", k[1], 17),
            L("SkPrice", (20, 196, 110, 40), '"₹" & Text(ThisItem.Price, "#,##0")', f"₹{k[4]:,}", 20, color=YEL, align="Left"),
            HIT("SkHit", (0, 0, ("Parent.TemplateWidth", TW), 190), "Set(gSpace, ThisItem)", "Show kit"),
            B("SkAdd", (twf(118), 196, 100, 40), '"+ Add"', "+ Add", YEL, INKC, ADD("ThisItem") + ";\nSet(gSpace, ThisItem)", 15),
        ]
    shown = KITS
    cs.append(GALC("SsGallery", (32, 172, 790, 586), 'Filter(colSpaceKits, gSpaceCat = "All" || Cat = gSpaceCat)', item(KITS[0]),
                   dict(kind="gal", items=shown, tw=TW, th=TH, wrap=3, pad=12, build=item), TH, 3, 12))
    k = KITS[0]
    cs += [I("SdPanel", (850, 112, 480, 640), svgfx(PANEL), PANEL, "Stretch"),
           I("SdArt", (866, 128, 230, 210), "gSpace.Art", ARTS[101]),
           L("SdName", (1100, 150, 210, 100), "gSpace.Name", "Rocket Lab\nKit", 26, wrap=True, align="Left"),
           B("SdCat", (1100, 262, 170, 38), "gSpace.Cat", k[2], CYAN, INKC, "false", 14, hover_fx=col(CYAN)),
           L("SdDyk", (884, 350, 420, 30), '"Did you know?"', "Did you know?", 18, color="bfe9ff", align="Left"),
           L("SdNum", (884, 382, 430, 90), "gSpace.Num", k[6], 60, color=YEL, align="Left"),
           L("SdFact", (884, 474, 420, 90), "gSpace.Fact", k[7], 18, wrap=True, align="Left", valign="Top"),
           B("SdAge", (884, 590, 140, 40), '"Ages " & gSpace.Age', "Ages 8+", PINK, "ffffff", "false", 15, hover_fx=col(PINK)),
           L("SdPrice", (1050, 580, 254, 56), '"₹" & Text(gSpace.Price, "#,##0")', "₹1,299", 34, align="Right"),
           B("SdAdd", (884, 660, 420, 66), '"Add to kit box  ✦"', "Add to kit box  ✦", YEL, INKC, ADD("gSpace"), 22),
           L("SdIn", (884, 728, 420, 22), '"In your kit box: " & Coalesce(LookUp(colCart, Id = gSpace.Id).Qty, 0)', "In your kit box: 0", 13, color="bfe9ff")]
    return cs, onvis
