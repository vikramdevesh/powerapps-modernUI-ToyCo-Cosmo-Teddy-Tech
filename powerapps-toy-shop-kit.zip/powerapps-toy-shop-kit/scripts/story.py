# Editorial Essay Collage style: "Toy Stories" - an illustrated history of play, 2 screens
import math, random
from kit import *

COND = "Anton, Impact, Haettenschweiler, Arial Narrow, sans-serif"
SERIF = "Libre Baskerville, Georgia, Times New Roman, serif"
OSW = "Oswald, Arial Narrow, Impact, sans-serif"
PAPER, INK, RED, CARD, NEWS, KRAFT = "#f0e9d9", "#1a1816", "#b8483a", "#f5f1e7", "#e9e1cb", "#c9a878"
U = [0]
def uid(p): U[0] += 1; return f"{p}{U[0]}"
def SVG(vb, body, par="xMidYMid meet"): return f"<svg xmlns='http://www.w3.org/2000/svg' viewBox='{vb}' preserveAspectRatio='{par}'>{body}</svg>"

FIB = ("<filter id='fib' x='0' y='0' width='100%' height='100%'><feTurbulence type='fractalNoise' baseFrequency='.9 .35' numOctaves='3' seed='7'/>"
       "<feColorMatrix values='0 0 0 0 .45  0 0 0 0 .38  0 0 0 0 .28  -1.3 0 0 0 .75'/></filter>"
       "<filter id='sh' x='-10%' y='-10%' width='130%' height='130%'><feGaussianBlur in='SourceAlpha' stdDeviation='6'/><feOffset dx='4' dy='8'/>"
       "<feComponentTransfer><feFuncA type='linear' slope='.4'/></feComponentTransfer><feMerge><feMergeNode/><feMergeNode in='SourceGraphic'/></feMerge></filter>")
def torn_rect(x, y, w, h, seed, torn=(1, 1, 1, 1), amp=4):
    cs = [(x, y), (x + w, y), (x + w, y + h), (x, y + h)]; out = []
    r = random.Random(seed)
    for e in range(4):
        a, b = cs[e], cs[(e + 1) % 4]
        if torn[e]: out += jag([a, b], seed + e, amp, 5)[:-1] if False else _edge(a, b, r, amp)
        else: out.append(a)
    return out
def _edge(a, b, r, amp):
    L_ = math.hypot(b[0] - a[0], b[1] - a[1]); n = max(2, int(L_ / 5)); nx, ny = -(b[1] - a[1]) / L_, (b[0] - a[0]) / L_; o = 0; pts = []
    for k in range(n):
        u = k / n; fade = min(1, k / 3, (n - k) / 3); o = o * 0.5 + (r.random() - 0.5) * amp * 1.6
        pts.append((a[0] + (b[0] - a[0]) * u + nx * o * fade, a[1] + (b[1] - a[1]) * u + ny * o * fade))
    return pts
def paperpoly(pts, fill, fib=0.5, shadow=True):
    i = uid("pp")
    s = f"<clipPath id='{i}'><polygon points='{poly(pts)}'/></clipPath>"
    s += f"<polygon points='{poly(pts)}' fill='{fill}'" + (" filter='url(#sh)'" if shadow else "") + "/>"
    xs = [p[0] for p in pts]; ys = [p[1] for p in pts]
    s += f"<rect clip-path='url(#{i})' x='{f1(min(xs))}' y='{f1(min(ys))}' width='{f1(max(xs)-min(xs))}' height='{f1(max(ys)-min(ys))}' filter='url(#fib)' opacity='{fib}'/>"
    return s
def tape(x, y, w, h, rot, seed):
    r = random.Random(seed); pts = [(-w / 2, -h / 2), (w / 2, -h / 2)]
    for i in range(1, 6): pts.append((w / 2 + (3 if i % 2 else -2) + r.uniform(-1.5, 1.5), -h / 2 + h * i / 6))
    pts += [(w / 2, h / 2), (-w / 2, h / 2)]
    for i in range(5, 0, -1): pts.append((-w / 2 + (-3 if i % 2 else 2) + r.uniform(-1.5, 1.5), -h / 2 + h * i / 6))
    return (f"<g transform='translate({f1(x)} {f1(y)}) rotate({f1(rot)})'><polygon points='{poly(pts)}' fill='#e4d8ba' fill-opacity='.82'/>"
            f"<rect x='{f1(-w/2)}' y='{f1(-h/2)}' width='{f1(w)}' height='2' fill='#968257' fill-opacity='.15'/><line x1='{f1(-w/2)}' y1='{f1(-h/6)}' x2='{f1(w/2)}' y2='{f1(-h/7)}' stroke='#fff' stroke-opacity='.25'/></g>")
def hilite(x, y, w, h, seed):
    r = random.Random(seed); top = [(x + d, y + r.uniform(-1, 1) * h * .07) for d in range(0, int(w) + 1, 8)]; bot = [(x + d, y + h + r.uniform(-1, 1) * h * .08) for d in range(int(w), -1, -8)]
    return (f"<g style='mix-blend-mode:multiply'><polygon points='{poly([(x - h * .06, y + h * .05)] + top + [(x + w + h * .08, y)] + [(x + w - h * .08, y + h)] + bot)}' fill='#ffe226' fill-opacity='.8'/>"
            f"<rect x='{f1(x)}' y='{f1(y+h*.3)}' width='{f1(w)}' height='{f1(h*.07)}' fill='#ebbe14' fill-opacity='.25'/><ellipse cx='{f1(x+h*.08)}' cy='{f1(y+h*.5)}' rx='{f1(h*.18)}' ry='{f1(h*.55)}' fill='#e6b40a' fill-opacity='.3'/></g>")
def marker_ring(cx, cy, rx, ry, seed, col=RED, lw=6):
    r = random.Random(seed); pts = []
    for i in range(61):
        u = i / 60; a = -2.3 + u * 6.283 * 1.12; k = 1 + (r.random() - .5) * .05 + u * .07; pts.append((cx + math.cos(a) * rx * k, cy + math.sin(a) * ry * k))
    d = "M" + " L".join(f"{f1(a)},{f1(b)}" for a, b in pts)
    return (f"<path d='{d}' fill='none' stroke='{col}' stroke-opacity='.9' stroke-width='{lw}' stroke-linecap='round' stroke-linejoin='round'/>"
            f"<path d='{d}' transform='translate({lw*.18:.1f} {-lw*.15:.1f})' fill='none' stroke='{col}' stroke-opacity='.35' stroke-width='{lw*.4:.1f}' stroke-linecap='round'/>")
def finish(w, h):
    i = uid("vg")
    return (f"<radialGradient id='{i}' cx='.5' cy='.5' r='.7'><stop offset='.45' stop-color='#fff'/><stop offset='1' stop-color='#d6c9b0'/></radialGradient>"
            f"<rect width='{w}' height='{h}' fill='url(#{i})' style='mix-blend-mode:multiply'/>"
            f"<filter id='gn' x='0' y='0' width='100%' height='100%'><feTurbulence type='fractalNoise' baseFrequency='1.1' numOctaves='2' seed='9'/><feColorMatrix type='saturate' values='0'/></filter>"
            f"<rect width='{w}' height='{h}' filter='url(#gn)' opacity='.22' style='mix-blend-mode:overlay'/>")

# ---------- archival halftone prints (grey scene -> dot-screen masked by darkness) ----------
def room(w, h, bg):
    return (f"<linearGradient id='rmg' x1='0' y1='0' x2='.4' y2='1'><stop offset='0' stop-color='{bg[0]}'/><stop offset='1' stop-color='{bg[1]}'/></linearGradient>"
            f"<rect width='{w}' height='{h}' fill='url(#rmg)'/><rect y='{int(h*.8)}' width='{w}' height='{int(h*.2)}' fill='#8a8a8a'/>"
            f"<radialGradient id='rml' cx='.2' cy='.1' r='.8'><stop offset='0' stop-color='#fff' stop-opacity='.4'/><stop offset='1' stop-color='#fff' stop-opacity='0'/></radialGradient><rect width='{w}' height='{h}' fill='url(#rml)'/>")
def g_(v): k = int(v * 255); return f"#{k:02x}{k:02x}{k:02x}"
def subj_bear(w, h):
    cx, cy, s = w * .5, h * .5, min(w, h)
    s_ = room(w, h, ("#e6e6e6", "#a8a8a8"))
    s_ += f"<ellipse cx='{f1(cx)}' cy='{f1(cy+s*.22)}' rx='{f1(s*.24)}' ry='{f1(s*.26)}' fill='{g_(.42)}'/>"
    for sd in (-1, 1):
        s_ += f"<ellipse cx='{f1(cx+sd*s*.24)}' cy='{f1(cy+s*.16)}' rx='{f1(s*.07)}' ry='{f1(s*.15)}' transform='rotate({-sd*25} {f1(cx+sd*s*.24)} {f1(cy+s*.16)})' fill='{g_(.36)}'/>"
        s_ += f"<ellipse cx='{f1(cx+sd*s*.16)}' cy='{f1(cy+s*.44)}' rx='{f1(s*.09)}' ry='{f1(s*.07)}' fill='{g_(.38)}'/><ellipse cx='{f1(cx+sd*s*.16)}' cy='{f1(cy+s*.45)}' rx='{f1(s*.05)}' ry='{f1(s*.04)}' fill='{g_(.7)}'/>"
        s_ += f"<circle cx='{f1(cx+sd*s*.15)}' cy='{f1(cy-s*.25)}' r='{f1(s*.08)}' fill='{g_(.36)}'/><circle cx='{f1(cx+sd*s*.15)}' cy='{f1(cy-s*.25)}' r='{f1(s*.04)}' fill='{g_(.62)}'/>"
    s_ += f"<ellipse cx='{f1(cx)}' cy='{f1(cy+s*.24)}' rx='{f1(s*.13)}' ry='{f1(s*.15)}' fill='{g_(.62)}'/>"
    s_ += f"<circle cx='{f1(cx)}' cy='{f1(cy-s*.12)}' r='{f1(s*.19)}' fill='{g_(.46)}'/><ellipse cx='{f1(cx)}' cy='{f1(cy-s*.05)}' rx='{f1(s*.08)}' ry='{f1(s*.06)}' fill='{g_(.72)}'/>"
    s_ += f"<ellipse cx='{f1(cx)}' cy='{f1(cy-s*.08)}' rx='{f1(s*.03)}' ry='{f1(s*.022)}' fill='{g_(.05)}'/>"
    for sd in (-1, 1): s_ += f"<circle cx='{f1(cx+sd*s*.07)}' cy='{f1(cy-s*.16)}' r='{f1(s*.02)}' fill='{g_(.04)}'/>"
    s_ += f"<path d='M{f1(cx-s*.03)},{f1(cy-s*.02)}Q{f1(cx)},{f1(cy+s*.01)} {f1(cx+s*.03)},{f1(cy-s*.02)}' stroke='{g_(.1)}' stroke-width='2' fill='none'/>"
    s_ += f"<path d='M{f1(cx-s*.09)},{f1(cy+s*.03)}L{f1(cx)},{f1(cy+s*.08)}L{f1(cx+s*.09)},{f1(cy+s*.03)}L{f1(cx+s*.05)},{f1(cy+s*.12)}L{f1(cx)},{f1(cy+s*.08)}L{f1(cx-s*.05)},{f1(cy+s*.12)}z' fill='{g_(.2)}'/>"
    return s_
def subj_slinky(w, h):
    s_ = room(w, h, ("#e4e4e4", "#a4a4a4"))
    for i in range(3): s_ += f"<rect x='{f1(w*(.08+i*.3))}' y='{f1(h*(.38+i*.16))}' width='{f1(w*.92-w*(.08+i*.3))}' height='{f1(h)}' fill='{g_(.55-i*.08)}'/><rect x='{f1(w*(.08+i*.3))}' y='{f1(h*(.38+i*.16))}' width='{f1(w)}' height='5' fill='{g_(.85)}'/>"
    for k in range(26):
        u = k / 25; x = w * (.16 + .55 * u); y = h * (.34 + .2 * u) - math.sin(u * math.pi) * h * .2
        s_ += f"<ellipse cx='{f1(x)}' cy='{f1(y)}' rx='{f1(w*.06)}' ry='{f1(h*.07)}' fill='none' stroke='{g_(.15 if k % 2 else .85)}' stroke-width='3'/>"
    return s_
def subj_bricks(w, h):
    s_ = room(w, h, ("#e8e8e8", "#aaaaaa"))
    def brick(x, y, bw, bh, tone):
        t = f"<rect x='{f1(x)}' y='{f1(y)}' width='{f1(bw)}' height='{f1(bh)}' rx='3' fill='{g_(tone)}'/><rect x='{f1(x)}' y='{f1(y)}' width='{f1(bw)}' height='6' fill='{g_(tone+.2)}'/>"
        for i in range(4): t += f"<rect x='{f1(x+bw*(.06+i*.24))}' y='{f1(y-bh*.22)}' width='{f1(bw*.16)}' height='{f1(bh*.24)}' rx='2' fill='{g_(tone-.08)}'/><rect x='{f1(x+bw*(.06+i*.24))}' y='{f1(y-bh*.22)}' width='{f1(bw*.16)}' height='4' fill='{g_(tone+.25)}'/>"
        return t
    return s_ + brick(w * .2, h * .58, w * .5, h * .2, .3) + brick(w * .32, h * .38, w * .5, h * .2, .6) + brick(w * .5, h * .66, w * .32, h * .14, .45)
def subj_doll(w, h):
    cx = w * .5; s_ = room(w, h, ("#e8e8e8", "#a6a6a6"))
    s_ += f"<rect x='{f1(cx-w*.03)}' y='{f1(h*.72)}' width='{f1(w*.025)}' height='{f1(h*.16)}' fill='{g_(.6)}'/><rect x='{f1(cx+w*.008)}' y='{f1(h*.72)}' width='{f1(w*.025)}' height='{f1(h*.16)}' fill='{g_(.6)}'/>"
    s_ += f"<path d='M{f1(cx-w*.06)},{f1(h*.36)}L{f1(cx+w*.06)},{f1(h*.36)}L{f1(cx+w*.14)},{f1(h*.74)}L{f1(cx-w*.14)},{f1(h*.74)}z' fill='{g_(.22)}'/>"
    for k in range(5): s_ += f"<line x1='{f1(cx-w*.12+k*w*.06)}' y1='{f1(h*.5)}' x2='{f1(cx-w*.13+k*w*.065)}' y2='{f1(h*.73)}' stroke='{g_(.75)}' stroke-width='2'/>"
    s_ += f"<rect x='{f1(cx-w*.014)}' y='{f1(h*.3)}' width='{f1(w*.028)}' height='{f1(h*.06)}' fill='{g_(.7)}'/><ellipse cx='{f1(cx)}' cy='{f1(h*.24)}' rx='{f1(w*.06)}' ry='{f1(h*.08)}' fill='{g_(.72)}'/>"
    s_ += f"<path d='M{f1(cx-w*.07)},{f1(h*.24)}Q{f1(cx-w*.06)},{f1(h*.12)} {f1(cx)},{f1(h*.13)}Q{f1(cx+w*.07)},{f1(h*.13)} {f1(cx+w*.07)},{f1(h*.22)}L{f1(cx+w*.12)},{f1(h*.4)}L{f1(cx+w*.06)},{f1(h*.24)}z' fill='{g_(.85)}'/>"
    for sd in (-1, 1): s_ += f"<line x1='{f1(cx+sd*w*.06)}' y1='{f1(h*.38)}' x2='{f1(cx+sd*w*.1)}' y2='{f1(h*.56)}' stroke='{g_(.7)}' stroke-width='{f1(w*.02)}' stroke-linecap='round'/>"
    return s_
def subj_cube(w, h):
    s_ = room(w, h, ("#e6e6e6", "#a2a2a2")); cx, cy, a = w * .5, h * .55, min(w, h) * .2
    r = random.Random(3)
    def face(o, ex, ey, base):
        t = ""
        for i in range(3):
            for j in range(3):
                p0 = (o[0] + ex[0] * i + ey[0] * j, o[1] + ex[1] * i + ey[1] * j)
                pts = [p0, (p0[0] + ex[0], p0[1] + ex[1]), (p0[0] + ex[0] + ey[0], p0[1] + ex[1] + ey[1]), (p0[0] + ey[0], p0[1] + ey[1])]
                t += f"<polygon points='{poly(pts)}' fill='{g_(base + r.choice([-.25, -.1, 0, .12, .25]))}' stroke='{g_(.06)}' stroke-width='3'/>"
        return t
    c, s = math.cos(math.radians(30)) * a, math.sin(math.radians(30)) * a
    s_ += face((cx - 3 * c, cy - 3 * s), (c, s), (c, -s), .62)
    s_ += face((cx - 3 * c, cy - 3 * s), (c, s), (0, a), .45)
    s_ += face((cx, cy), (c, -s), (0, a), .3)
    return s_
def subj_handheld(w, h):
    cx = w * .5; s_ = room(w, h, ("#e6e6e6", "#a4a4a4"))
    s_ += f"<rect x='{f1(cx-w*.17)}' y='{f1(h*.12)}' width='{f1(w*.34)}' height='{f1(h*.78)}' rx='10' fill='{g_(.78)}'/><rect x='{f1(cx-w*.13)}' y='{f1(h*.18)}' width='{f1(w*.26)}' height='{f1(h*.3)}' rx='6' fill='{g_(.35)}'/>"
    s_ += f"<rect x='{f1(cx-w*.09)}' y='{f1(h*.22)}' width='{f1(w*.18)}' height='{f1(h*.22)}' fill='{g_(.62)}'/>"
    for i in range(3): s_ += f"<rect x='{f1(cx-w*.06+i*w*.04)}' y='{f1(h*(.3+.035*i))}' width='{f1(w*.04)}' height='{f1(h*.035)}' fill='{g_(.25)}'/>"
    s_ += f"<rect x='{f1(cx-w*.12)}' y='{f1(h*.6)}' width='{f1(w*.08)}' height='{f1(h*.03)}' fill='{g_(.15)}'/><rect x='{f1(cx-w*.095)}' y='{f1(h*.56)}' width='{f1(w*.03)}' height='{f1(h*.11)}' fill='{g_(.15)}'/>"
    s_ += f"<circle cx='{f1(cx+w*.06)}' cy='{f1(h*.62)}' r='{f1(w*.025)}' fill='{g_(.2)}'/><circle cx='{f1(cx+w*.11)}' cy='{f1(h*.58)}' r='{f1(w*.025)}' fill='{g_(.2)}'/>"
    for i in range(4): s_ += f"<line x1='{f1(cx+w*.04+i*w*.025)}' y1='{f1(h*.84)}' x2='{f1(cx+w*.07+i*w*.025)}' y2='{f1(h*.78)}' stroke='{g_(.45)}' stroke-width='3'/>"
    return s_
def print_svg(subject, seed, w=330, h=250, border=14, tapes=True, rot=0, ring=None):
    W_, H_ = w + border * 2 + 60, h + border * 2 + 60; ox, oy = 30, 30
    hid, mid, sid = uid("ht"), uid("hm"), uid("hs")
    body = subject(w, h)
    s = (f"<defs>{FIB}<pattern id='{hid}' width='4.6' height='4.6' patternUnits='userSpaceOnUse' patternTransform='rotate(45)'><circle cx='2.3' cy='2.3' r='1.9' fill='#1e1b19'/></pattern>"
         f"<g id='{sid}'>{body}</g><filter id='iv'><feColorMatrix values='-1 0 0 0 1  -1 0 0 0 1  -1 0 0 0 1  0 0 0 1 0'/></filter>"
         f"<mask id='{mid}'><g filter='url(#iv)'><use href='#{sid}'/></g></mask></defs>")
    outer = torn_rect(ox, oy, w + border * 2, h + border * 2, seed, (0, 1, 1, 0), 5)
    s += f"<g transform='rotate({rot} {W_/2} {H_/2})'>" + paperpoly(outer, "#f8f5ee", 0.35)
    s += f"<g transform='translate({ox+border} {oy+border})'><rect width='{w}' height='{h}' fill='#eee7d6'/><use href='#{sid}' opacity='.4'/>"
    s += f"<rect width='{w}' height='{h}' fill='url(#{hid})' mask='url(#{mid})'/>"
    r = random.Random(seed)
    for _ in range(14): s += f"<circle cx='{r.randint(0,w)}' cy='{r.randint(0,h)}' r='{r.uniform(.5,1.4):.1f}' fill='{'#f5f0e4' if r.random()<.6 else '#141210'}' opacity='.7'/>"
    sx = r.randint(20, w - 20); s += f"<path d='M{sx},0C{sx+20},{h*.3:.0f} {sx-15},{h*.6:.0f} {sx+12},{h}' stroke='#f5f0e4' stroke-opacity='.45' fill='none'/>"
    s += f"<rect width='{w}' height='{h}' fill='none' stroke='#000' stroke-opacity='.12'/>"
    if ring: s += marker_ring(*ring)
    s += "</g>"
    if tapes: s += tape(ox + 40, oy + 6, 100, 30, -32, seed + 1) + tape(ox + w + border * 2 - 40, oy + 4, 96, 28, 26, seed + 2)
    s += "</g>"
    return SVG(f"0 0 {W_} {H_}", s)

def strip(text, w, h, bg, fg, seed, hl=False, size=None, font=COND, torn=(0, 0, 0, 0), anchor="middle"):
    size = size or int(h * .78); W_, H_ = w + 40, h + 40
    s = f"<defs>{FIB}</defs>" + paperpoly(torn_rect(20, 20, w, h, seed, torn, 4), bg, 0.12 if bg == INK else 0.45)
    if hl: s += hilite(20 + w * .05, 20 + h * .14, w * .9, h * .72, seed)
    x = 20 + w / 2 if anchor == "middle" else 20 + h * .25
    s += f"<text x='{f1(x)}' y='{f1(20+h*.5+size*.36)}' font-family='{font}' font-size='{size}' fill='{fg}' text-anchor='{anchor}' textLength='{f1(w-h*.5)}' lengthAdjust='spacingAndGlyphs'>{text}</text>"
    return SVG(f"0 0 {W_} {H_}", s)

def greek(x, y, w, lines, lh, seed):
    r = random.Random(seed); s = ""
    for l in range(lines):
        cx = x + (10 if l == 0 else 0); end = x + w * (r.uniform(.3, .8) if l == lines - 1 else 1)
        while cx < end - 12:
            ww = r.randint(8, 46)
            if cx + ww > end: break
            s += f"<rect x='{cx}' y='{y+l*lh}' width='{ww}' height='4' fill='#342f29' fill-opacity='.55'/>"; cx += ww + 5
    return s
def clipping(w, h, seed, kicker, head, deck, hlline, cols=2, ring=None):
    W_, H_ = w + 60, h + 60; ox = oy = 30
    s = f"<defs>{FIB}</defs>" + paperpoly(torn_rect(ox, oy, w, h, seed, (0, 1, 1, 1), 5), NEWS, 0.8)
    L_, R_ = ox + 22, ox + w - 22; y = oy + 34
    s += f"<text x='{L_}' y='{y}' font-family='{OSW}' font-size='14' fill='{INK}' letter-spacing='1'>{kicker}</text><rect x='{L_}' y='{y+7}' width='{R_-L_}' height='2' fill='{INK}'/><rect x='{L_}' y='{y+11}' width='{R_-L_}' height='.8' fill='{INK}'/>"
    y += 16
    for line in head: y += 40; s += f"<text x='{L_}' y='{y}' font-family='{SERIF}' font-weight='700' font-size='33' fill='{INK}'>{line}</text>"
    y += 14
    for line in deck: y += 27; s += f"<text x='{L_}' y='{y}' font-family='{SERIF}' font-style='italic' font-size='19' fill='#2a2622'>{line}</text>"
    y += 27; tw = (R_ - L_) * .86
    s += hilite(L_ - 4, y - 19, tw + 8, 25, seed) + f"<text x='{L_}' y='{y}' font-family='{SERIF}' font-style='italic' font-size='19' fill='#2a2622' textLength='{f1(tw)}' lengthAdjust='spacingAndGlyphs'>{hlline}</text>"
    if ring: s += marker_ring(*ring)
    y += 18; s += f"<rect x='{L_}' y='{y}' width='{R_-L_}' height='.8' fill='{INK}'/>"
    cw = (R_ - L_ - 14 * (cols - 1)) / cols
    for k in range(cols): s += greek(L_ + k * (cw + 14), y + 18, cw, int((oy + h - y - 24) / 13), 13, seed + k)
    return SVG(f"0 0 {W_} {H_}", s)

def paper_bg(extra="", seed=1):
    r = random.Random(seed)
    s = f"<defs>{FIB}</defs><rect width='1366' height='768' fill='{PAPER}'/><rect width='1366' height='768' filter='url(#fib)' opacity='.55'/>"
    for _ in range(160):
        x, y, a, l = r.uniform(0, 1366), r.uniform(0, 768), r.uniform(0, 6.28), r.uniform(4, 16)
        s += f"<line x1='{x:.0f}' y1='{y:.0f}' x2='{x+math.cos(a)*l:.0f}' y2='{y+math.sin(a)*l:.0f}' stroke='{'#78644a' if r.random()<.55 else '#fff'}' stroke-opacity='{r.uniform(.06,.2):.2f}'/>"
    s += extra + finish(1366, 768)
    return SVG("0 0 1366 768", s, "xMidYMid slice")

STORIES = [
    (1, "1902", "NOVEMBER 1902", "A cartoon bear becomes a toy", "After a newspaper cartoon showed President Theodore Roosevelt sparing a bear, Brooklyn shopkeepers Morris and Rose Michtom sold a plush ‘Teddy’s bear’.", "Named after Theodore Roosevelt", subj_bear),
    (2, "1945", "PHILADELPHIA, 1945", "A spring that walks downstairs", "Engineer Richard James saw a spring tumble off a shelf. His Slinky made its debut at Gimbels department store in 1945.", "It sold out in about 90 minutes", subj_slinky),
    (3, "1949", "BILLUND, DENMARK", "Bricks that click together", "The LEGO Group began making its plastic ‘Automatic Binding Bricks’ in 1949, the ancestors of today’s building bricks.", "First plastic bricks: 1949", subj_bricks),
    (4, "1959", "NEW YORK TOY FAIR", "A doll who grew up", "Mattel introduced Barbie at the American International Toy Fair in New York in March 1959.", "Created by Ruth Handler", subj_doll),
    (5, "1974", "BUDAPEST, 1974", "The puzzle in a cube", "Hungarian architecture professor Ernő Rubik built the first prototype of his cube in 1974.", "43 quintillion possible positions", subj_cube),
    (6, "1989", "KYOTO, APRIL 1989", "Games in your pocket", "Nintendo launched the Game Boy in Japan in April 1989; in North America it came with Tetris in the box.", "Tetris came in the box", subj_handheld),
]
YEARSTRIP = strip("YEAR", 300, 120, INK, "#f3efe5", 51, size=110)

# ================= SCREENS =================
def home():
    redblock = paperpoly(torn_rect(880, -20, 520, 640, 12, (0, 0, 0, 1), 7), RED, 0.55)
    tl = torn_rect(-20, 586, 1420, 210, 21, (1, 0, 0, 0), 6)
    tline = paperpoly(tl, CARD, 0.45)
    xs = [110, 320, 530, 740, 950, 1160]
    d = "M60,650 C300,628 560,672 800,648 S1180,628 1320,652"
    tline += f"<path d='{d}' stroke='{INK}' stroke-width='2.6' fill='none' stroke-dasharray='10 7'/>"
    for i, (x, st) in enumerate(zip(xs, STORIES)):
        y = 650 + (-10 if i % 2 else 8)
        tline += (f"<ellipse cx='{x+5}' cy='{y+2}' rx='7' ry='3' fill='#1e140a' fill-opacity='.25'/><line x1='{x}' y1='{y}' x2='{x}' y2='{y-16}' stroke='#555' stroke-width='1.6'/>"
                  f"<circle cx='{x}' cy='{y-22}' r='8' fill='{RED}'/><circle cx='{x-2.5}' cy='{y-24.5}' r='2.5' fill='#fff' fill-opacity='.6'/>"
                  f"<text x='{x}' y='{y+38}' text-anchor='middle' font-family='{COND}' font-size='34' fill='{INK}'>{st[1]}</text>"
                  f"<text x='{x}' y='{y+60}' text-anchor='middle' font-family='{OSW}' font-size='14' fill='{INK}' letter-spacing='1'>{st[3].split()[-1].upper().replace('TOY','TEDDY BEAR') if i==0 else ['','SLINKY','BRICKS','FASHION DOLL','PUZZLE CUBE','HANDHELD'][i]}</text>")
    softclip = f"<g opacity='.55' style='filter:blur(2px)'><polygon points='{poly(torn_rect(-30,-40,300,200,33,(1,1,1,1),5))}' fill='{NEWS}'/>{greek(10,20,230,10,14,4)}</g>"
    bg = paper_bg(softclip + redblock + tline, 3)
    pr = print_svg(subj_bear, 7, 360, 270, ring=(180, 100, 84, 92, 3.3, RED, 6), rot=-2)
    cl = clipping(360, 300, 41, "THE MORNING RECORD · NOV. 1902", ["Roosevelt Spares", "a Bear; a Toy", "Is Born"], ["A Brooklyn shop names its", "new plush bear after him:"], "the ‘Teddy’s bear’ goes on sale", 2)
    h1 = strip("THE TOYS THAT", 600, 104, INK, "#f3efe5", 5); h2 = strip("MADE US", 360, 104, CARD, INK, 6, hl=True)
    cta = strip("READ THE ARCHIVE  →", 340, 62, CARD, INK, 9, font=OSW, size=34)
    back = strip("←  WORKBENCH", 200, 46, INK, "#f3efe5", 15, font=OSW, size=24)
    cs = [I("StBg", (0, 0, ("Parent.Width", 1366), ("Parent.Height", 768)), svgfx(bg), bg, "Fill"),
          I("StPrint", (640, 40, 470, 380), svgfx(pr), pr),
          I("StClip", (930, 214, 420, 360), svgfx(cl), cl),
          I("StH1", (20, 90, 640, 144), svgfx(h1), h1),
          I("StH2", (60, 200, 400, 144), svgfx(h2), h2),
          L("StSub", (64, 360, 560, 40), '"An illustrated history of play, 1902 – 1989"', "An illustrated history of play, 1902 – 1989", 20, "serif", color="1a1816", align="Left", italic=True),
          I("StCta", (44, 420, 380, 102), svgfx(cta), cta),
          HIT("StCtaHit", (64, 440, 340, 62), "Set(gStoryIdx, 1);\nNavigate(StoryArchiveScreen, ScreenTransition.Cover)", "Read the archive", "RGBA(26, 24, 22, 0.08)"),
          I("StBack", (1130, 6, 240, 86), svgfx(back), back),
          HIT("StBackHit", (1150, 26, 200, 46), "Navigate(HomeScreen, ScreenTransition.UnCover)", "Back to the workbench", "RGBA(255, 255, 255, 0.12)")]
    for i, x in enumerate(xs):
        y = 650 + (-10 if i % 2 else 8)
        cs.append(HIT(f"StPin{i+1}", (x - 60, y - 40, 120, 110), f"Set(gStoryIdx, {i+1});\nNavigate(StoryArchiveScreen, ScreenTransition.Cover)", f"Read {STORIES[i][1]}", "RGBA(26, 24, 22, 0.08)"))
    return cs

def archive():
    kraft = paperpoly(torn_rect(14, 90, 450, 690, 22, (1, 1, 1, 1), 7), KRAFT, 0.5) + tape(420, 104, 90, 26, 34, 25) + tape(40, 760, 90, 26, -20, 26)
    red = paperpoly(torn_rect(1180, 520, 260, 300, 33, (1, 0, 0, 1), 7), RED, 0.55)
    bg = paper_bg(kraft + red, 5)
    rowbg = SVG("0 0 440 110", f"<defs>{FIB}</defs>" + paperpoly(torn_rect(8, 6, 420, 94, 61, (0, 1, 0, 1), 4), NEWS, 0.7), "none")
    ystrip = strip("YEAR", 180, 70, INK, "#f3efe5", 71, size=64)
    ring_s = SVG("0 0 200 110", marker_ring(100, 55, 92, 46, 5.5, RED, 6), "none")
    ring_b = SVG("0 0 440 190", marker_ring(220, 95, 205, 82, 2.2, RED, 7), "none")
    big = strip("YEAR", 340, 150, INK, "#f3efe5", 81, size=150)
    cpanel = SVG("0 0 900 330", f"<defs>{FIB}</defs>" + paperpoly(torn_rect(20, 16, 850, 290, 91, (1, 0, 1, 1), 5), NEWS, 0.8)
                 + f"<rect x='44' y='66' width='800' height='2' fill='{INK}'/><rect x='44' y='71' width='800' height='.8' fill='{INK}'/>" + tape(450, 18, 120, 30, -3, 92), "none")
    title = strip("THE ARCHIVE", 330, 70, CARD, INK, 101, hl=True)
    prevs, nexts = strip("←  PREV", 130, 46, INK, "#f3efe5", 111, font=OSW, size=24), strip("NEXT  →", 130, 46, INK, "#f3efe5", 112, font=OSW, size=24)
    back = strip("←  THE TOYS THAT MADE US", 330, 46, CARD, INK, 113, font=OSW, size=24)
    rows = ",\n        ".join(f'{{Idx: {s[0]}, Year: "{s[1]}", Kicker: "{s[2]}", Title: "{s[3]}", Deck: "{s[4]}", Key: "{s[5]}", Art: {svgfx(print_svg(s[6], 200 + s[0], 330, 250, rot=(s[0] % 2) * 2 - 1))}}}' for s in STORIES)
    onvis = ('ClearCollect(\n    colStories,\n    Table(\n        ' + rows + '\n    )\n);\nIf(IsBlank(gStoryIdx) || gStoryIdx < 1, Set(gStoryIdx, 1))')
    cur = "LookUp(colStories, Idx = gStoryIdx)"
    TW, TH = 432, 100
    def item(st):
        return [I("SaRow", (0, 0, ("Parent.TemplateWidth", TW), ("Parent.TemplateHeight", TH)), svgfx(rowbg), rowbg, "Stretch"),
                I("SaYear", (6, 6, 150, 88), f'"data:image/svg+xml;utf8," & EncodeUrl(Substitute("{ystrip}", "YEAR", ThisItem.Year))', ystrip.replace("YEAR", st[1])),
                I("SaRing", (0, 0, 162, 100), svgfx(ring_s), ring_s, "Stretch", visible="ThisItem.Idx = gStoryIdx", pvhide=st[0] != 1),
                L("SaTitle", (166, 14, ("Parent.TemplateWidth - 186", TW - 186), 48), "ThisItem.Title", st[3], 15, "serif", "bold", "1a1816", "Left", "Top", wrap=True),
                L("SaKick", (166, 66, ("Parent.TemplateWidth - 186", TW - 186), 22), "ThisItem.Kicker", st[2], 10, "segoe", "semi", "5a5248", "Left"),
                HIT("SaHit", (0, 0, ("Parent.TemplateWidth", TW), ("Parent.TemplateHeight", TH)), "Set(gStoryIdx, ThisItem.Idx)", "Open this story", "RGBA(26, 24, 22, 0.06)")]
    s0 = STORIES[0]
    cs = [I("SaBg", (0, 0, ("Parent.Width", 1366), ("Parent.Height", 768)), svgfx(bg), bg, "Fill"),
          I("SaBack", (10, 4, 370, 86), svgfx(back), back),
          HIT("SaBackHit", (30, 24, 330, 46), "Navigate(StoryHomeScreen, ScreenTransition.UnCover)", "Back to the cover", "RGBA(26, 24, 22, 0.08)"),
          GALC("SaList", (22, 110, 440, 650), "colStories", item(s0), dict(kind="gal", items=STORIES, tw=TW, th=TH, wrap=1, pad=6, build=item), TH, 1, 6),
          I("SaTitleStrip", (490, 8, 370, 110), svgfx(title), title),
          I("SaArt", (480, 96, 470, 370), f"{cur}.Art", print_svg(s0[6], 201, 330, 250, rot=-1)),
          I("SaBig", (930, 110, 380, 190), f'"data:image/svg+xml;utf8," & EncodeUrl(Substitute("{big}", "YEAR", {cur}.Year))', big.replace("YEAR", s0[1])),
          I("SaBigRing", (900, 100, 440, 210), svgfx(ring_b), ring_b, "Stretch"),
          I("SaPanel", (470, 440, 900, 330), svgfx(cpanel), cpanel, "Stretch"),
          L("SaKicker", (514, 470, 600, 24), f"{cur}.Kicker", s0[2], 12, "segoe", "bold", "1a1816", "Left"),
          L("SaHead", (514, 518, 800, 50), f"{cur}.Title", s0[3], 30, "serif", "bold", "1a1816", "Left"),
          L("SaDeck", (514, 570, 800, 78), f"{cur}.Deck", s0[4], 16, "serif", color="2a2622", align="Left", valign="Top", wrap=True, italic=True),
          L("SaKey", (514, 664, 470, 40), f"{cur}.Key", s0[5], 17, "serif", "bold", "1a1816", "Left", fill_fx="RGBA(255, 226, 38, 0.78)", pad=10),
          I("SaPrev", (1000, 640, 170, 86), svgfx(prevs), prevs),
          HIT("SaPrevHit", (1020, 660, 130, 46), "Set(gStoryIdx, Max(1, gStoryIdx - 1))", "Previous story", "RGBA(255, 255, 255, 0.12)"),
          I("SaNext", (1170, 640, 170, 86), svgfx(nexts), nexts),
          HIT("SaNextHit", (1190, 660, 130, 46), "Set(gStoryIdx, Min(CountRows(colStories), gStoryIdx + 1))", "Next story", "RGBA(255, 255, 255, 0.12)")]
    return cs, onvis
