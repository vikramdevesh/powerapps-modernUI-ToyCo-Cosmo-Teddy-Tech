# Cosmo Kits

*Style: Flat-Vector Science*

**App idea:** A space-science toy store with a friendly robot guide. Every product carries a “Did you know?” fact with a big number, so shopping doubles as a mini science lesson.

**Good for:** STEM toy shops, science museum gift shops, school fundraisers

![SpaceHomeScreen](../../assets/previews/SpaceHomeScreen.jpg) ![SpaceShopScreen](../../assets/previews/SpaceShopScreen.jpg) ![SpaceCartScreen](../../assets/previews/SpaceCartScreen.jpg)

## Screens

| File | What it does |
|---|---|
| `SpaceHomeScreen.pa.yaml` | Hero page: planet buttons for Rockets, Planets, Night Sky and Telescopes, plus “Explore all kits”. |
| `SpaceShopScreen.pa.yaml` | The Launch Pad: filter pills, a kit grid and a fact panel with the key number and Add to cargo bay. |
| `SpaceCartScreen.pa.yaml` | Cargo Bay: quantity steppers, a mission summary with free shipping over ₹1,999 and “Launch order”. |

## Set it up

1. In Power Apps, create a **blank canvas app** in **Tablet** format.
2. For each `.pa.yaml` file in this folder, copy the whole file, right-click any screen in the Tree view and choose **Paste**.
3. Drag **SpaceHomeScreen** to the top of the Tree view so the app opens there, delete the empty Screen1, then save and press Play.

This app is self-contained: it doesn't need any other app in this repo, connectors or data sources.

## Data and variables

Kits load on SpaceShopScreen’s OnVisible (`colSpaceKits`, 6 kits). Cart: `colCosmoCart`.
