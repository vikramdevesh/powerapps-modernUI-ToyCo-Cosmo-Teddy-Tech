# Paper Toy Co.

*Style: Papercraft Models*

**App idea:** A kit shop for fold-it-yourself paper toys. Browse robots, critters, vehicles and blocks on a green cutting mat, then pack them into a kit box and place an order.

**Good for:** Craft shops, toy stores, classroom maker kits

![HomeScreen](../../assets/previews/HomeScreen.jpg) ![CatalogScreen](../../assets/previews/CatalogScreen.jpg) ![CartScreen](../../assets/previews/CartScreen.jpg)

## Screens

| File | What it does |
|---|---|
| `HomeScreen.pa.yaml` | Landing page: four kit-box categories, a featured robot and “Open the kit shelf”. |
| `CatalogScreen.pa.yaml` | The Kit Shelf: search, category tabs, a 3-column kit grid and a detail panel with Add to box. |
| `CartScreen.pa.yaml` | Your Kit Box: quantity steppers, a receipt-style total and Place order. |
| `App.Formulas.txt` | Paste into the App **Formulas** property first. |

## Set it up

1. In Power Apps, create a **blank canvas app** in **Tablet** format.
2. Select **App** in the Tree view, choose the **Formulas** property and paste all of `App.Formulas.txt`.
3. For each `.pa.yaml` file in this folder, copy the whole file, right-click any screen in the Tree view and choose **Paste**.
4. Drag **HomeScreen** to the top of the Tree view so the app opens there, delete the empty Screen1, then save and press Play.

This app is self-contained: it doesn't need any other app in this repo, connectors or data sources.

## Data and variables

App.Formulas holds all papercraft art and the `Toys` catalogue (12 kits). Cart: `colCart`.
