# The Toys That Made Us

*Style: Editorial Essay Collage*

**App idea:** An interactive history-of-play guide: six toys that changed childhood, told as newspaper clippings and halftone prints, with a quick quiz to test what you learned.

**Good for:** Museums and exhibitions, libraries, classrooms, brand storytelling

![StoryHomeScreen](../../assets/previews/StoryHomeScreen.jpg) ![StoryArchiveScreen](../../assets/previews/StoryArchiveScreen.jpg) ![StoryQuizScreen](../../assets/previews/StoryQuizScreen.jpg)

## Screens

| File | What it does |
|---|---|
| `StoryHomeScreen.pa.yaml` | Cover: cut-out headline, teddy-bear print, a clipping, a 1902–1989 timeline and a Pop Quiz button. |
| `StoryArchiveScreen.pa.yaml` | Six toy histories with a year strip, clipping, highlighted key fact and PREV / NEXT. |
| `StoryQuizScreen.pa.yaml` | Pop Quiz: guess the year from three options. Red marker cross for wrong, ring on the right answer, score card at the end. |
| `App.Formulas.txt` | Paste into the App **Formulas** property first. |

## Set it up

1. In Power Apps, create a **blank canvas app** in **Tablet** format.
2. Select **App** in the Tree view, choose the **Formulas** property and paste all of `App.Formulas.txt`.
3. For each `.pa.yaml` file in this folder, copy the whole file, right-click any screen in the Tree view and choose **Paste**.
4. Drag **StoryHomeScreen** to the top of the Tree view so the app opens there, delete the empty Screen1, then save and press Play.

This app is self-contained: it doesn't need any other app in this repo, connectors or data sources.

## Data and variables

App.Formulas holds the `Stories` table (6 entries with print art). The quiz shuffles them each round.
