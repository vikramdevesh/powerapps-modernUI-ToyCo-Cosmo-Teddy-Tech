# All-in-one toy shop

The original combined app: the Paper Toy Co. shop with the Cosmo Kits, Toys That Made Us and Spark Cube screens linked from three tents on HomeScreen, all sharing one kit box (`colCart`, shown on CartScreen). 9 screens.

## Set it up

1. Create a blank canvas app in **Tablet** format.
2. Select **App**, choose the **Formulas** property and paste `App.Formulas.txt`.
3. Paste every `.pa.yaml` file (right-click a screen in the Tree view → **Paste**), starting with HomeScreen, CatalogScreen and CartScreen.
4. Drag HomeScreen to the top, then save and press Play.

The standalone versions in the other folders are usually the better starting point.
