# Spark Cube

*Style: Product Launch Reveal*

**App idea:** A keynote-style launch and pre-order flow for one hero product: a dark stage reveal with spec callouts, a clean white specs page with finish picker, and a bag with checkout.

**Good for:** Product launches, pre-order campaigns, hardware or gadget brands

![LaunchScreen](../../assets/previews/LaunchScreen.jpg) ![LaunchSpecsScreen](../../assets/previews/LaunchSpecsScreen.jpg) ![LaunchBagScreen](../../assets/previews/LaunchBagScreen.jpg)

## Screens

| File | What it does |
|---|---|
| `LaunchScreen.pa.yaml` | Dark stage reveal with three spec callouts, the price line, Pre-order and See the specs. |
| `LaunchSpecsScreen.pa.yaml` | White stage: “Play. Code. Glow.”, the 8-hour number, spec tiles, finish swatches and Pre-order. |
| `LaunchBagScreen.pa.yaml` | Review your bag: quantity steppers, an order summary and Check out, then a “You’re in.” confirmation. |

## Set it up

1. In Power Apps, create a **blank canvas app** in **Tablet** format.
2. For each `.pa.yaml` file in this folder, copy the whole file, right-click any screen in the Tree view and choose **Paste**.
3. Drag **LaunchScreen** to the top of the Tree view so the app opens there, delete the empty Screen1, then save and press Play.

This app is self-contained: it doesn't need any other app in this repo, connectors or data sources.

## Data and variables

Everything is inline. Bag: `colSparkBag`; chosen finish: `gFinish`. Spark Cube is an invented product.
