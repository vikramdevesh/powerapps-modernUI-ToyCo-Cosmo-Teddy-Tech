# Power Apps Toy Shop App Kit

Four **standalone Power Apps canvas apps**, each in its own visual style, as copy-and-paste YAML. Every app is self-contained: paste its files into a blank tablet app and it works. No images, connectors or data sources are needed, because all the art is inline SVG.

The repo also works as a **Claude skill**: Claude can hand out the apps, walk you through pasting them, or rebuild them with your own products and text.

| App | Style | Idea | Screens |
|---|---|---|---|
| [**Paper Toy Co.**](apps/paper-toy-co) | Papercraft models | A shop for fold-it-yourself paper toy kits | Home · Kit Shelf · Kit Box |
| [**Cosmo Kits**](apps/cosmo-kits) | Flat-vector science | A space-science toy store with a fact on every product | Home · Launch Pad · Cargo Bay |
| [**The Toys That Made Us**](apps/toys-that-made-us) | Editorial essay collage | An interactive history of six famous toys, with a quiz | Cover · Archive · Pop Quiz |
| [**Spark Cube**](apps/spark-cube) | Product launch reveal | A keynote-style launch and pre-order flow for one product | Reveal · Specs · Bag |

| | | |
|---|---|---|
| ![HomeScreen](assets/previews/HomeScreen.jpg) | ![CatalogScreen](assets/previews/CatalogScreen.jpg) | ![CartScreen](assets/previews/CartScreen.jpg) |
| ![SpaceHomeScreen](assets/previews/SpaceHomeScreen.jpg) | ![SpaceShopScreen](assets/previews/SpaceShopScreen.jpg) | ![SpaceCartScreen](assets/previews/SpaceCartScreen.jpg) |
| ![StoryHomeScreen](assets/previews/StoryHomeScreen.jpg) | ![StoryArchiveScreen](assets/previews/StoryArchiveScreen.jpg) | ![StoryQuizScreen](assets/previews/StoryQuizScreen.jpg) |
| ![LaunchScreen](assets/previews/LaunchScreen.jpg) | ![LaunchSpecsScreen](assets/previews/LaunchSpecsScreen.jpg) | ![LaunchBagScreen](assets/previews/LaunchBagScreen.jpg) |

```
apps/<app>/        one folder per app: its .pa.yaml screens, App.Formulas.txt if it needs one, and a README
apps/all-in-one/   the original combined toy shop (all four styles in one app, 9 screens)
assets/previews/   screen previews
scripts/           Python generators (edit the data, rebuild every app)
reference/         Power Apps YAML notes and gotchas
SKILL.md           instructions Claude follows when this is installed as a skill
```

## Use an app in Power Apps

1. Create a **blank canvas app** in **Tablet** format.
2. If the app folder has an `App.Formulas.txt` (Paper Toy Co. and The Toys That Made Us), select **App** in the Tree view, choose the **Formulas** property and paste the whole file.
3. Copy each `.pa.yaml` file in the folder, right-click any screen in the Tree view and choose **Paste**. Large screens can take Studio a minute or two to finish.
4. Drag the app's first screen to the top of the Tree view, then save and press **Play**.

Each app folder's README lists its screens, setup steps and the collections and variables it uses.

## Install as a Claude skill

- **Claude Code:** clone the repo into your skills folder:
  ```bash
  git clone https://github.com/<your-username>/powerapps-toy-shop-kit ~/.claude/skills/powerapps-toy-shop-kit
  ```
- **Claude apps (claude.ai / desktop):** download the repo as a ZIP (keep the `powerapps-toy-shop-kit` folder at the top level), then upload it under **Settings → Capabilities → Skills**.

Then ask something like *"Give me the Cosmo Kits Power App"* or *"Rebuild Paper Toy Co. with my own eight products."*

## Customise and rebuild

Edit the data tables, then regenerate everything (Python 3; `pyyaml` is optional and used for validation):

| File | What to edit | Apps |
|---|---|---|
| `scripts/gen.py` | `TOYS`: catalogue names, categories, colours, prices, descriptions | Paper Toy Co. |
| `scripts/space.py` | `KITS`: products and their "Did you know?" facts | Cosmo Kits |
| `scripts/story.py` | `STORIES`: toy-history entries (also used by the quiz) | The Toys That Made Us |
| `scripts/launch.py` | `launch()`, `specs()`, `FIN`: copy, price and finishes | Spark Cube |
| `scripts/standalone.py` | the third screen of each style app and the standalone wiring | Cosmo Kits, Toys, Spark Cube |

```bash
pip install pyyaml
python scripts/build_all.py build --mocks
```

This writes one folder per app to `build/`, each with its `.pa.yaml` files, any `App.Formulas.txt`, and `mock_*.html` layout previews.

## Notes

- Spark Cube is an invented product, used for the launch-style demo.
- If you edit the stories in *The Toys That Made Us*, double-check the dates and facts before publishing.
- See [`reference/powerapps-yaml-notes.md`](reference/powerapps-yaml-notes.md) for paste rules and gotchas (rejected properties, `Rept()`, SVG quoting and more).

## License

MIT. See [LICENSE](LICENSE).
