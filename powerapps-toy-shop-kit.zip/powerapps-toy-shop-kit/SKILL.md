---
name: powerapps-toy-shop-kit
description: Paste-ready Power Apps canvas YAML for four standalone styled apps (papercraft toy shop, space-science store, toy-history guide with quiz, product-launch pre-order). Use when someone wants these apps, a styled shop/catalogue/launch canvas app, or to customise or rebuild them with their own products, text or prices.
---

# Power Apps Toy Shop App Kit

Four standalone canvas apps (tablet, 1366 x 768), each in its own visual style. All art is inline SVG built in Power Fx, so no app needs images, connectors or data sources.

| Folder | App idea | Style | Screens (first = start screen) | App.Formulas |
|---|---|---|---|---|
| `apps/paper-toy-co` | Paper toy kit shop | Papercraft models | `HomeScreen`, `CatalogScreen`, `CartScreen` | yes |
| `apps/cosmo-kits` | Space-science toy store | Flat-vector science | `SpaceHomeScreen`, `SpaceShopScreen`, `SpaceCartScreen` | no |
| `apps/toys-that-made-us` | Toy-history guide with a quiz | Editorial essay collage | `StoryHomeScreen`, `StoryArchiveScreen`, `StoryQuizScreen` | yes (`Stories`) |
| `apps/spark-cube` | Product launch and pre-order | Product launch reveal | `LaunchScreen`, `LaunchSpecsScreen`, `LaunchBagScreen` | no |
| `apps/all-in-one` | The original combined toy shop: all four styles linked from HomeScreen, one shared cart | mixed | 9 screens | yes |

Each app folder has a `README.md` with its setup steps, collections and variables. Previews are in `assets/previews/<ScreenName>.jpg`. Read `reference/powerapps-yaml-notes.md` before writing or editing any Power Apps YAML.

## Giving someone an app as-is

Hand over that app's folder and these steps:

1. Create a blank canvas app in **Tablet** format.
2. If the folder has `App.Formulas.txt`, select **App** in the Tree view, choose the **Formulas** property and paste all of it.
3. For each `.pa.yaml` file, copy the whole contents, right-click any screen in the Tree view and choose **Paste**.
4. Drag the start screen (first in the table above) to the top of the Tree view, delete the empty Screen1, then save and press Play.

The four standalone apps don't depend on each other. Each uses its own collections (`colCart`, `colCosmoCart`, `colStories` and `colQuiz`, `colSparkBag`), so two apps can share one Power Apps app if someone wants them together. The large screens (100 KB+) can take Studio a minute or two to finish pasting.

## Customising

When the user wants their own products, text, prices or facts, edit the generators rather than hand-editing the YAML. The SVG art is long URL-encoded strings that are easy to break by hand.

1. Copy `scripts/` to a working folder and edit the data:
   - `gen.py` `TOYS` (Paper Toy Co.): id, name, kind (`Robot`/`Critter`/`Vehicle`/`Blocks`, which picks the art), category, two hex colours, price, age, part code, piece count, rating 1-5, description.
   - `space.py` `KITS` (Cosmo Kits): id, name, category, hex, price, age, big number, fact, art function. Categories must be ones in `CATS`.
   - `story.py` `STORIES` (The Toys That Made Us): index, year, kicker, title, deck, highlighted key fact, subject art function. The quiz uses the same table. Check facts for accuracy before shipping.
   - `launch.py` (Spark Cube): copy in `launch()` and `specs()`, finishes in `FIN`, and the price, which appears as `₹4,999` in labels and `Price: 4999` in the Pre-order formula. Change all of them together.
   - `standalone.py`: the third screen of each style app (`cosmo_cart`, `story_quiz`, `spark_bag`) and the per-app renames (collections, navigation targets, wording).
2. Run `python scripts/build_all.py out --mocks` (Python 3; `pip install pyyaml` to validate). It writes one folder per app with its `.pa.yaml` files, any `App.Formulas.txt`, and `mock_*.html` previews.
3. Open the mocks in a browser (or screenshot them with Playwright at 1366 x 768) to check layout before handing the YAML over. Mock fonts are approximations, so small text can look tighter than it does in Studio.

For new screens in one of these styles, reuse the helpers in `kit.py` (`L` label, `I` image, `B` pill button, `HIT` transparent hit area, `GALC` gallery, `screen_yaml`, `mock`), `standalone.py` (`tweak` to copy a screen with renames, `svgsub` for SVGs with placeholders) and the art helpers in the matching style module (`space.py`: `planet`, `ball`, `glow`, `robot`, `sky`; `story.py`: `torn_rect`, `tape`, `hilite`, `marker_ring`, `print_svg`, `clipping`, `strip`, `paper_bg`; `launch.py`: `slab`, `stage_dark`, `callout`, `bg_white`, `hero_white`).

## Putting an app into Power Apps for the user

If you have browser control of Power Apps Studio, follow the paste steps above. Typing large YAML through a formula bar is too slow. Get the text onto the clipboard instead, for example by copying it from a page with a textarea using select-all and copy, then right-click a screen in the Tree view and choose Paste. Wait for Studio to finish (it is unresponsive while parsing), save with Ctrl+S, and open the App checker to confirm there are no formula errors.
